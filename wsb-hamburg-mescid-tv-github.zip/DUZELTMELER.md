# Bu sürümde yapılan kontrol ve düzeltmeler

## Hadis listesi (200 → 200, 23 hadis değiştirildi)
Kaldırılanlar (zayıf/tartışmalı, mükerrer, ayet olup hadis diye yazılmış ya da kaynağı güvenilmez olanlar):
Cennet annelerin ayakları altındadır (zayıf rivayet) · İlim talep etmek farzdır · "Hasbiyallâhu" duası (Ebû Dâvûd 5081) ·
"Beş şeyden önce beş şey" (kaynağı yanlış) · "Tutumlu davranan darlık çekmez" · "Allah tövbe edenleri sever" (ayet) ·
Âyetel Kürsî sonrası cennet · "Kazayı ancak dua çevirir" · "Doğrularla beraber olun" (ayet, hadis değil) ·
"Sünnetimi seven beni sevmiş olur" · "Kardeşinin musibetine sevinme" · "Abdest sonrası salavat" ·
"Dua kabulü için bolluk günlerinde dua" (kaynak hatalı) · "Sadakanın en faziletlisi su" ·
"Ezanı duyup cemaate gelmeyen" · ve tekrar eden 8 hadis (öfke/güç, merhamet, ilim yolu, evleri kabir yapma, zafer sabırla beraberdir,
ahlak, Allah'a yaklaşma, mümin cana yakındır).
Yerlerine Buhârî ve Müslim'de geçen, sahihliği tartışılmayan hadisler eklendi.
Üç hadisin kaynak numarası düzeltildi.

## Ayet listesi
200 ayet, tekrar yok, Arapça metinler bağımsız bir kontrolle (harf iskeleti) karşılaştırıldı: kelime hatası bulunmadı.
Bir tercüme düzeltildi (Alak 96:1).

## Namaz vakitleri
- İnternet yokken kullanılan "aylık tablo" 30-60 dakika kayıyordu. Yerine astronomik hesap eklendi
  (Diyanet açıları + Diyanet düzeltmeleri). 28.10.2026 Hamburg değerleriyle birebir uyuşuyor.
- Eski gün önbelleği artık başka bir günün vakitlerini göstermiyor.

## Android
- Boş ekran riski giderildi (WebViewAssetLoader).
- Eksik `gradle.properties` ve Gradle sürüm dosyası eklendi (derleme hatası veriyordu).
- Elektrik kesintisinden sonra açılış için izin eklendi; WebView çökerse otomatik toparlanır.
- `www/` içindeki 40'tan fazla eski paket dosyası, iç içe zip'ler ve ekran görüntüleri silindi.
- Servis çalışanı (PWA önbelleği) APK içinde kapatıldı: eski sürümü önbellekten gösterme riski vardı.

## Son eklenenler (7/24 çalışma ve GitHub)
- Bekçi servisi: uygulama kapanırsa/çökerse 30 saniye içinde geri açılır; bilerek kapatma: Geri tuşu 3 sn.
- Elektrik gelince ve güncellemeden sonra otomatik başlama.
- Namaz vakitleri: bulunulan ay + sonraki 2 ay indirilip TV belleğine kaydedilir (internet kesilse de doğru vakit).
  Ayar (yöntem/şehir) değişirse eski kayıtlar silinip yeniden indirilir.
- GitHub Actions ile APK üretimi, sabit imza (güncellemeler eskinin üstüne kurulur), sabit indirme linki.

## Bayram / kandil güncellemesi ve Cuma
- Hicri tarih (bayram, kandil, Ramazan geri sayımı) artık internetten Diyanet takvimiyle güncelleniyor,
  3 ay cihazda saklanıyor. Önceki sürümde tarayıcının Suudi (Ümmü'l-Kurâ) takvimi kullanılıyor ve 1-2 gün fark çıkabiliyordu.
- Cuma bilgisi/saati ekranda gösterilmiyor (varsayılan kapalı).
