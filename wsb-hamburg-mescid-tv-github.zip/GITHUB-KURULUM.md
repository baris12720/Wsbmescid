# GitHub ile APK üretme (bilgisayar gerekmez, Android Studio gerekmez)

## Bir kerelik kurulum
1. github.com'da ücretsiz hesap açın → **New repository** → ad: `mescid-tv` → **Create repository**.
   (Public yapmanız Fire TV'de indirmeyi kolaylaştırır. Uygulamada gizli bilgi yok.)
2. Bu zip'i bilgisayarda açın. Açılan klasörün **içindekileri** (android-tv-project, src, .github, ...) repoya yükleyin:
   - Repo sayfasında **uploading an existing file** → klasörleri/dosyaları sürükleyip bırakın → **Commit changes**.
   - Toplam 86 dosya var; GitHub tek seferde 100'e kadar kabul eder, hepsini birlikte yükleyebilirsiniz.
   - `.github` klasörü mutlaka yüklenmeli (APK'yı üreten talimat orada).
3. Üstteki **Actions** sekmesine gidin. İlk seferde "I understand my workflows" düğmesine basın.
4. Yükleme (commit) yapıldığı anda APK kendiliğinden derlenmeye başlar (yaklaşık 5-8 dakika).
   Elle başlatmak için: Actions → **APK üret** → **Run workflow**.

## APK'yı alma
- Yeşil tik çıkınca: **Actions → son çalışma → Artifacts → mescid-tv-apk** (zip içinde `mescid-tv.apk`), **veya**
- Repo ana sayfası → sağdaki **Releases → Mescid TV – son sürüm → mescid-tv.apk**.
- Sabit indirme linki (Fire TV'de Downloader'a yazılır):
  `https://github.com/KULLANICIADINIZ/mescid-tv/releases/latest/download/mescid-tv.apk`

## Güncelleme
Repodaki herhangi bir dosyayı değiştirip kaydetmeniz yeterli; APK yeniden derlenir. Yeni APK'yı Fire TV'ye aynı
yöntemle kurarsanız eski sürümün üstüne yüklenir (imza ve sürüm numarası otomatik uyumlu).

## Hata olursa
Actions'ta kırmızı ✗ çıkarsa çalışmaya tıklayıp hata satırını (kırmızı) kopyalayıp bana gönderin.
