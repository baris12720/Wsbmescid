// Generator script for exactly 200 authentic Quranic verses
// Each verse includes unique ID, Surah name (TR, AR, DE, EN), Surah number, Ayah number,
// Arabic text, Translations (TR, AR, DE, EN), and Reference.

const fs = require('fs');
const path = require('path');

const ayahs = [
  // 1-10: Fatiha & Baqarah
  {
    id: "ayah-1",
    surahNumber: 1,
    ayahNumber: 2,
    surahName: { tr: "Fâtiha Sûresi", ar: "سورة الفاتحة", de: "Sure Al-Fatiha", en: "Surah Al-Fatihah" },
    arabic: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
    translations: {
      tr: "Hamd, âlemlerin Rabbi olan Allah'a mahsustur.",
      ar: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
      de: "Alles Lob gebührt Allah, dem Herrn der Welten.",
      en: "All praise is due to Allah, Lord of the worlds."
    },
    reference: "Fâtiha 1:2"
  },
  {
    id: "ayah-2",
    surahNumber: 1,
    ayahNumber: 5,
    surahName: { tr: "Fâtiha Sûresi", ar: "سورة الفاتحة", de: "Sure Al-Fatiha", en: "Surah Al-Fatihah" },
    arabic: "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ",
    translations: {
      tr: "Yalnız sana kulluk eder ve yalnız senden yardım dileriz.",
      ar: "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ",
      de: "Dir allein dienen wir, und Dich allein bitten wir um Hilfe.",
      en: "You alone we worship, and You alone we ask for help."
    },
    reference: "Fâtiha 1:5"
  },
  {
    id: "ayah-3",
    surahNumber: 1,
    ayahNumber: 6,
    surahName: { tr: "Fâtiha Sûresi", ar: "سورة الفاتحة", de: "Sure Al-Fatiha", en: "Surah Al-Fatihah" },
    arabic: "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ",
    translations: {
      tr: "Bizi doğru yola ilet.",
      ar: "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ",
      de: "Leite uns den geraden Weg.",
      en: "Guide us to the straight path."
    },
    reference: "Fâtiha 1:6"
  },
  {
    id: "ayah-4",
    surahNumber: 2,
    ayahNumber: 2,
    surahName: { tr: "Bakara Sûresi", ar: "سورة البقرة", de: "Sure Al-Baqarah", en: "Surah Al-Baqarah" },
    arabic: "ذَٰلِكَ الْكِتَابُ لَا رَيْبَ ۛ فِيهِ ۛ هُدًى لِّلْمُتَّقِينَ",
    translations: {
      tr: "Bu, kendisinde şüphe olmayan kitaptır; takva sahipleri için bir hidayettir.",
      ar: "ذَٰلِكَ الْكِتَابُ لَا رَيْبَ ۛ فِيهِ ۛ هُدًى لِّلْمُتَّقِينَ",
      de: "Dies ist das Buch, an dem kein Zweifel ist, eine Rechtleitung für die Gottesfürchtigen.",
      en: "This is the Book about which there is no doubt, a guidance for those conscious of Allah."
    },
    reference: "Bakara 2:2"
  },
  {
    id: "ayah-5",
    surahNumber: 2,
    ayahNumber: 45,
    surahName: { tr: "Bakara Sûresi", ar: "سورة البقرة", de: "Sure Al-Baqarah", en: "Surah Al-Baqarah" },
    arabic: "وَاسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ ۚ وَإِنَّهَا لَكَبِيرَةٌ إِلَّا عَلَى الْخَاشِعِينَ",
    translations: {
      tr: "Sabır ve namazla Allah'tan yardım dileyin. Şüphesiz bu, huşû duyanlardan başkasına ağır gelir.",
      ar: "وَاسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ ۚ وَإِنَّهَا لَكَبِيرَةٌ إِلَّا عَلَى الْخَاشِعِينَ",
      de: "Und sucht Hilfe in der Geduld und im Gebet; dies ist freilich schwer, außer für Demütige.",
      en: "And seek help through patience and prayer, and indeed, it is difficult except for the humbly submissive."
    },
    reference: "Bakara 2:45"
  },
  {
    id: "ayah-6",
    surahNumber: 2,
    ayahNumber: 152,
    surahName: { tr: "Bakara Sûresi", ar: "سورة البقرة", de: "Sure Al-Baqarah", en: "Surah Al-Baqarah" },
    arabic: "فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ",
    translations: {
      tr: "Öyleyse beni anın ki ben de sizi anayım; bana şükredin ve nankörlük etmeyin.",
      ar: "فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ",
      de: "Gedenkt Meiner, so gedenke Ich eurer; dankt Mir und seid nicht undankbar.",
      en: "So remember Me; I will remember you. And be grateful to Me and do not deny Me."
    },
    reference: "Bakara 2:152"
  },
  {
    id: "ayah-7",
    surahNumber: 2,
    ayahNumber: 153,
    surahName: { tr: "Bakara Sûresi", ar: "سورة البقرة", de: "Sure Al-Baqarah", en: "Surah Al-Baqarah" },
    arabic: "يَا أَيُّهَا الَّذِينَ آمَنُوا اسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ ۚ إِنَّ اللَّهَ مَعَ الصَّابِرِينَ",
    translations: {
      tr: "Ey iman edenler! Sabır ve namazla yardım dileyin. Şüphesiz Allah sabredenlerle beraberdir.",
      ar: "يَا أَيُّهَا الَّذِينَ آمَنُوا اسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ ۚ إِنَّ اللَّهَ مَعَ الصَّابِرِينَ",
      de: "O die ihr glaubt, sucht Hilfe in der Geduld und im Gebet. Gewiss, Allah ist mit den Geduldigen.",
      en: "O you who have believed, seek help through patience and prayer. Indeed, Allah is with the patient."
    },
    reference: "Bakara 2:153"
  },
  {
    id: "ayah-8",
    surahNumber: 2,
    ayahNumber: 186,
    surahName: { tr: "Bakara Sûresi", ar: "سورة البقرة", de: "Sure Al-Baqarah", en: "Surah Al-Baqarah" },
    arabic: "وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ ۖ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ",
    translations: {
      tr: "Kullarım sana beni sorduklarında bilsinler ki şüphesiz ben onlara çok yakınım. Bana dua edenin duasına icabet ederim.",
      ar: "وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ ۖ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ",
      de: "Und wenn Meine Diener dich nach Mir fragen: Ich bin gewiss nahe; Ich erhöre den Ruf des Bittenden.",
      en: "And when My servants ask you concerning Me, indeed I am near. I respond to the invocation of the supplicant."
    },
    reference: "Bakara 2:186"
  },
  {
    id: "ayah-9",
    surahNumber: 2,
    ayahNumber: 201,
    surahName: { tr: "Bakara Sûresi", ar: "سورة البقرة", de: "Sure Al-Baqarah", en: "Surah Al-Baqarah" },
    arabic: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
    translations: {
      tr: "Rabbimiz! Bize dünyada da iyilik ver, ahirette de iyilik ver ve bizi ateş azabından koru.",
      ar: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
      de: "Unser Herr, gib uns im Diesseits Gutes und im Jenseits Gutes, und bewahre uns vor der Strafe des Feuers.",
      en: "Our Lord, give us in this world that which is good and in the Hereafter that which is good and protect us from the punishment of the Fire."
    },
    reference: "Bakara 2:201"
  },
  {
    id: "ayah-10",
    surahNumber: 2,
    ayahNumber: 255,
    surahName: { tr: "Bakara Sûresi (Âyetel Kürsî)", ar: "سورة البقرة (آية الكرسي)", de: "Sure Al-Baqarah (Thronvers)", en: "Surah Al-Baqarah (Ayat al-Kursi)" },
    arabic: "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ",
    translations: {
      tr: "Allah, O'ndan başka ilah yoktur; O Hayy'dır, Kayyûm'dur. O'nu ne bir uyuklama tutar ne de bir uyku.",
      ar: "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ",
      de: "Allah – es gibt keinen Gott außer Ihm, dem Lebendigen, dem Beständigen. Weder Schlummer ergreift Ihn noch Schlaf.",
      en: "Allah - there is no deity except Him, the Ever-Living, the Sustainer of existence. Neither drowsiness overtakes Him nor sleep."
    },
    reference: "Bakara 2:255"
  }
];

// Let's write the rest of the 200 verses programmatically from verified canonical surah & ayah list
const remainingAyahsData = [
  // 11-20
  [2, 256, "لَا إِكْرَاهَ فِي الدِّينِ ۖ قَد تَّبَيَّنَ الرُّشْدُ مِنَ الْغَيِّ", "Dinde zorlama yoktur. Doğruluk sapıklıktan kesin olarak ayrılmıştır.", "Es gibt keinen Zwang im Glauben. Der richtige Weg ist nunmehr klar.", "There is no compulsion in religion. The right course has become distinct from the wrong."],
  [2, 286, "لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا", "Allah hiç kimseye gücünün yettiğinden fazlasını yüklemez.", "Allah erlegt keiner Seele mehr auf, als sie zu leisten vermag.", "Allah does not burden a soul beyond that it can bear."],
  [3, 8, "رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِن لَّدُنكَ رَحْمَةً", "Rabbimiz! Bizi hidayete erdirdikten sonra kalplerimizi eğriltme ve katından bize bir rahmet bağışla.", "Unser Herr, lass unsere Herzen nicht abschweifen, nachdem Du uns rechtgeleitet hast, und schenke uns Barmherzigkeit.", "Our Lord, let not our hearts deviate after You have guided us and grant us from Yourself mercy."],
  [3, 26, "قُلِ اللَّهُمَّ مَالِكَ الْمُلْكِ تُؤْتِي الْمُلْكَ مَن تَشَاءُ وَتَنزِعُ الْمُلْكَ مِمَّن تَشَاءُ", "De ki: Ey mülkün sahibi olan Allah'ım! Mülkü dilediğine verirsin, dilediğinden çekip alırsın.", "Sprich: O Allah, Herrscher der Herrschaft, Du gibst die Herrschaft, wem Du willst, und nimmst sie, wem Du willst.", "Say, 'O Allah, Owner of Sovereignty, You give sovereignty to whom You will and You take sovereignty from whom You will.'"],
  [3, 31, "قُلْ إِن كُنتُمْ تُحِبُّونَ اللَّهَ فَاتَّبِعُونِي يُحْبِبْكُمُ اللَّهُ وَيَغْفِرْ لَكُمْ ذُنُوبَكُمْ", "De ki: Eğer Allah'ı seviyorsanız bana uyun ki Allah da sizi sevsin ve günahlarınızı bağışlasın.", "Sprich: Wenn ihr Allah liebt, dann folgt mir, so liebt euch Allah und vergibt euch eure Sünden.", "Say, 'If you should love Allah, then follow me, Allah will love you and forgive you your sins.'"],
  [3, 103, "وَاعْتَصِمُوا بِحَبْلِ اللَّهِ جَمِيعًا وَلَا تَفَرَّقُوا", "Hep birlikte Allah'ın ipine sımsıkı sarılın, fırkalara bölünüp ayrılmayın.", "Und haltet alle fest am Seil Allahs und spaltet euch nicht.", "And hold firmly to the rope of Allah all together and do not become divided."],
  [3, 134, "الَّذِينَ يُنفِقُونَ فِي السَّرَّاءِ وَالضَّرَّاءِ وَالْكَاظِمِينَ الْغَيْظَ وَالْعَافِينَ عَنِ النَّاسِ", "Onlar bollukta da darlıkta da infak edenler, öfkelerini yenenler ve insanları affedenlerdir.", "Diejenigen, die in Freude und Leid ausgeben und den Zorn unterdrücken und den Menschen vergeben.", "Who spend [in the cause of Allah] during ease and hardship and who restrain anger and who pardon the people."],
  [3, 139, "وَلَا تَهِنُوا وَلَا تَحْزَنُوا وَأَنتُمُ الْأَعْلَوْنَ إِن كُنتُم مُّؤْمِنِينَ", "Gevşemeyin, hüzne kapılmayın; eğer inanıyorsanız en üstün olan sizlersiniz.", "Und werdet nicht schwach und trauert nicht; ihr werdet die Oberhand haben, wenn ihr gläubig seid.", "So do not weaken and do not grieve, and you will be superior if you are believers."],
  [3, 159, "فَبِمَا رَحْمَةٍ مِّنَ اللَّهِ لِنتَ لَهُمْ ۖ وَلَوْ كُنتَ فَظًّا غَلِيظَ الْقَلْبِ لَانفَضُّوا مِنْ حَوْلِكَ", "Allah'ın rahmeti sayesindedir ki sen onlara yumuşak davrandın. Kaba ve katı yürekli olsaydın çevrenden dağılırlardı.", "Durch die Barmherzigkeit Allahs warst du sanft zu ihnen. Wärest du grob und hartherzig gewesen, wären sie davongelaufen.", "So by mercy from Allah, you were lenient with them. And if you had been rude and harsh, they would have disbanded."],
  [3, 191, "الَّذِينَ يَذْكُرُونَ اللَّهَ قِيَامًا وَقُعُودًا وَعَلَىٰ جُنُوبِهِمْ وَيَتَفَكَّرُونَ فِي خَلْقِ السَّمَاوَاتِ وَالْأَرْضِ", "Onlar ayaktayken, otururken ve yanları üzerine yatarken Allah'ı anarlar; göklerin ve yerin yaratılışını tefekkür ederler.", "Die Allahs gedenken im Stehen, Sitzen und auf ihren Seiten und über die Erschaffung der Himmel und der Erde nachdenken.", "Who remember Allah while standing or sitting or [lying] on their sides and give thought to the creation of the heavens and earth."],

  // 21-30
  [4, 28, "يُرِيدُ اللَّهُ أَن يُخَفِّفَ عَنكُمْ ۚ وَخُلِقَ الْإِنسَانُ ضَعِيفًا", "Allah sizden yükü hafifletmek ister; çünkü insan zayıf yaratılmıştır.", "Allah will es euch leicht machen; denn der Mensch ist schwach erschaffen.", "Allah wishes to lighten for you [your difficulties]; and mankind was created weak."],
  [4, 36, "وَاعْبُدُوا اللَّهَ وَلَا تُشْرِكُوا بِهِ شَيْئًا ۖ وَبِالْوَالِدَيْنِ إِحْسَانًا", "Allah'a kulluk edin ve O'na hiçbir şeyi ortak koşmayın; ana-babaya iyilik edin.", "Dient Allah und gesellt Ihm nichts bei, und zu den Eltern sollt ihr gütig sein.", "Worship Allah and associate nothing with Him, and to parents do good."],
  [4, 58, "إِنَّ اللَّهَ يَأْمُرُكُمْ أَن تُؤَدُّوا الْأَمَانَاتِ إِلَىٰ أَهْلِهَا", "Şüphesiz Allah emanetleri ehline vermenizi emreder.", "Gewiss, Allah gebietet euch, die Treuhandgüter ihren Eigentümern zurückzugeben.", "Indeed, Allah commands you to render trusts to whom they are due."],
  [4, 135, "يَا أَيُّهَا الَّذِينَ آمَنُوا كُونُوا قَوَّامِينَ بِالْقِسْطِ شُهَدَاءَ لِلَّهِ", "Ey iman edenler! Adaleti titizlikle ayakta tutan ve Allah için şahitlik eden kimseler olun.", "O die ihr glaubt, seid standhaft in Gerechtigkeit, Zeugen für Allah.", "O you who have believed, be persistently standing firm in justice, witnesses for Allah."],
  [5, 2, "وَتَعَاوَنُوا عَلَى الْبِرِّ وَالتَّقْوَىٰ ۖ وَلَا تَعَاوَنُوا عَلَى الْإِثْمِ وَالْعُدْوَانِ", "İyilik ve takva üzerinde yardımlaşın; günah ve düşmanlık üzerinde yardımlaşmayın.", "Helft einander zur Güte und Gottesfurcht, aber helft einander nicht zur Sünde und Übertretung.", "And cooperate in righteousness and piety, but do not cooperate in sin and aggression."],
  [5, 8, "يَا أَيُّهَا الَّذِينَ آمَنُوا كُونُوا قَوَّامِينَ لِلَّهِ شُهَدَاءَ بِالْقِسْطِ ۖ وَلَا يَجْرِمَنَّكُمْ شَنَآنُ قَوْمٍ عَلَىٰ أَلَّا تَعْدِلُوا", "Ey iman edenler! Allah için hakkı ayakta tutan adil şahitler olun. Bir topluluğa olan öfkeniz sizi adaletsizliğe sürüklemesin.", "O die ihr glaubt, seid standhaft für Allah als Zeugen der Gerechtigkeit. Der Hass gegen andere soll euch nicht verleiten, ungerecht zu sein.", "O you who have believed, be persistently standing firm for Allah, witnesses in justice, and do not let hatred prevent you from being just."],
  [5, 32, "مَن قَتَلَ نَفْسًا بِغَيْرِ نَفْسٍ أَوْ فَسَادٍ فِي الْأَرْضِ فَكَأَنَّمَا قَتَلَ النَّاسَ جَمِيعًا", "Kim bir canı haksız yere öldürürse bütün insanları öldürmüş gibi olur; kim de bir canı kurtarırsa bütün insanları kurtarmış gibidir.", "Wer eine Seele rettet, so ist es, als hätte er die ganze Menschheit gerettet.", "Whoever saves one - it is as if he had saved mankind entirely."],
  [6, 17, "وَإِن يَمْسَسْكَ اللَّهُ بِضُرٍّ فَلَا كَاشِفَ لَهُ إِلَّا هُوَ", "Eğer Allah sana bir zarar dokundurursa, O'ndan başka onu giderecek yoktur.", "Und wenn dir Allah ein Unheil widerfahren lässt, kann es niemand abwenden außer Er.", "And if Allah should touch you with adversity, there is no remover of it except Him."],
  [6, 54, "كَتَبَ رَبُّكُمْ عَلَىٰ نَفْسِهِ الرَّحْمَةَ", "Rabbiniz rahmeti kendi üzerine yazmıştır.", "Euer Herr hat Sich Selbst die Barmherzigkeit vorgeschrieben.", "Your Lord has decreed upon Himself mercy."],
  [6, 162, "قُلْ إِنَّ صَلَاتِي وَنُسُكِي وَمَحْيَايَ وَمَمَاتِي لِلَّهِ رَبِّ الْعَالَمِينَ", "De ki: Şüphesiz benim namazım, kurbanım, hayatım ve ölümüm âlemlerin Rabbi olan Allah içindir.", "Sprich: Gewiss, mein Gebet, mein Gottesdienst, mein Leben und mein Sterben gehören Allah, dem Herrn der Welten.", "Say, 'Indeed, my prayer, my rites of sacrifice, my living and my dying are for Allah, Lord of the worlds.'"],

  // 31-40
  [7, 23, "رَبَّنَا ظَلَمْنَا أَنفُسَنَا وَإِن لَّمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ", "Dediler ki: Rabbimiz! Biz kendimize zulmettik. Eğer bizi bağışlamaz ve bize merhamet etmezsen elbette hüsrana uğrayanlardan oluruz.", "Sie sagten: Unser Herr, wir haben uns selbst Unrecht getan. Wenn Du uns nicht vergibst, gehören wir zu den Verlierern.", "They said, 'Our Lord, we have wronged ourselves, and if You do not forgive us and have mercy upon us, we will be losers.'"],
  [7, 56, "إِنَّ رَحْمَتَ اللَّهِ قَرِيبٌ مِّنَ الْمُحْسِنِينَ", "Şüphesiz Allah'ın rahmeti iyilik edenlere çok yakındır.", "Gewiss, Allahs Barmherzigkeit ist den Gutes Tuenden nahe.", "Indeed, the mercy of Allah is near to the doers of good."],
  [7, 180, "وَلِلَّهِ الْأَسْمَاءُ الْحُسْنَىٰ فَادْعُوهُ بِهَا", "En güzel isimler Allah'ındır; O'na bu güzel isimlerle dua edin.", "Und Allahs sind die schönsten Namen, so ruft Ihn damit an.", "And to Allah belong the best names, so invoke Him by them."],
  [7, 199, "خُذِ الْعَفْوَ وَأْمُرْ بِالْعُرْفِ وَأَعْرِضْ عَنِ الْجَاهِلِينَ", "Sen af yolunu tut, iyiliği emret ve cahillerden yüz çevir.", "Übe Nachsicht, gebiete das Gute und wende dich von den Unwissenden ab.", "Take what is given freely, enjoin what is good, and turn away from the ignorant."],
  [7, 205, "وَاذْكُر رَّبَّكَ فِي نَفْسِكَ تَضَرُّعًا وَخِيفَةً", "Rabbini içinden yalvararak ve ürpererek sabah akşam an.", "Und gedenke deines Herrn in deiner Seele in Demut und Furcht morgens und abends.", "And remember your Lord within yourself in humility and in fear without being loud."],
  [8, 2, "إِنَّمَا الْمُؤْمِنُونَ الَّذِينَ إِذَا ذُكِرَ اللَّهُ وَجِلَتْ قُلُوبُهُمْ", "Müminler ancak o kimselerdir ki Allah anıldığı zaman kalpleri ürperir.", "Die Gläubigen sind nur diejenigen, deren Herzen erbeben, wenn Allahs gedacht wird.", "The believers are only those who, when Allah is mentioned, their hearts become fearful."],
  [8, 46, "وَأَطِيعُوا اللَّهَ وَرَسُولَهُ وَلَا تَنَازَعُوا فَتَفْشَلُوا وَتَذْهَبَ رِيحُكُمْ ۖ وَاصْبِرُوا", "Allah'a ve Resûlüne itaat edin, birbirinizle çekişmeyin; sonra içinize korku düşer ve gücünüz elden gider.", "Und gehorcht Allah und Seinem Gesandten und streitet nicht, sonst verliert ihr den Mut. Seid geduldig.", "And obey Allah and His Messenger, and do not dispute and lose courage. And be patient."],
  [9, 40, "لَا تَحْزَنْ إِنَّ اللَّهَ مَعَنَا", "Üzülme, çünkü Allah bizimle beraberdir.", "Sei nicht traurig; gewiss, Allah ist mit uns.", "Do not grieve; indeed Allah is with us."],
  [9, 51, "قُل لَّن يُصِيبَنَا إِلَّا مَا كَتَبَ اللَّهُ لَنَا هُوَ مَوْلَانَا ۚ وَعَلَى اللَّهِ فَلْيَتَوَكَّلِ الْمُؤْمِنُونَ", "De ki: Bizim başımıza ancak Allah'ın bizim için yazdığı gelir. O bizim mevlâmızdır; müminler Allah'a tevekkül etsinler.", "Sprich: Nichts trifft uns außer dem, was Allah für uns bestimmt hat. Er ist unser Beschützer.", "Say, 'Never will we be struck except by what Allah has decreed for us; He is our protector.'"],
  [9, 128, "لَقَدْ جَاءَكُمْ رَسُولٌ مِّنْ أَنفُسِكُمْ عَزِيزٌ عَلَيْهِ مَا عَنِتُّمْ حَرِيصٌ عَلَيْكُم بِالْمُؤْمِنِينَ رَءُوفٌ رَّحِيمٌ", "Andolsun size içinizden öyle bir peygamber gelmiştir ki zahmet çekmeniz ona ağır gelir; o size çok düşkündür, müminlere şefkatli ve merhametlidir.", "Zu euch ist ein Gesandter aus euren Reihen gekommen; schwer lastet auf ihm, was ihr leidet; er sorgt sich um euch.", "There has certainly come to you a Messenger from among yourselves. Grievous to him is what you suffer; he is caring and merciful."],

  // 41-50
  [9, 129, "فَإِن تَوَلَّوْا فَقُلْ حَسْبِيَ اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ ۖ عَلَيْهِ تَوَكَّلْتُ ۖ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ", "Yüz çevirirlerse de ki: Allah bana yeter! O'ndan başka ilah yoktur. Ben O'na tevekkül ettim ve O, yüce Arş'ın Rabbidir.", "Wenn sie sich abkehren, so sprich: Allah genügt mir. Es gibt keinen Gott außer Ihm. Auf Ihn vertraue ich.", "If they turn away, say: Sufficient for me is Allah; there is no deity except Him. On Him I have relied, Lord of the Great Throne."],
  [10, 57, "يَا أَيُّهَا النَّاسُ قَدْ جَاءَتْكُم مَّوْعِظَةٌ مِّن رَّبِّكُمْ وَشِفَاءٌ لِّمَا فِي الصُّدُورِ وَهُدًى وَرَحْمَةٌ لِّلْمُؤْمِنِينَ", "Ey insanlar! Size Rabbinizden bir öğüt, gönüllerdeki dertlere bir şifa, müminler için bir hidayet ve rahmet gelmiştir.", "O Menschen, zu euch ist eine Ermahnung von eurem Herrn gekommen und Heilung für die Herzen.", "O mankind, there has to come to you instruction from your Lord and healing for what is in the breasts."],
  [10, 62, "أَلَا إِنَّ أَوْلِيَاءَ اللَّهِ لَا خَوْفٌ عَلَيْهِمْ وَلَا هُمْ يَحْزَنُونَ", "Bilesiniz ki Allah'ın dostlarına hiçbir korku yoktur ve onlar üzülmeyeceklerdir de.", "Wahrhaftig, Allahs Freunde – keine Furcht soll über sie kommen, noch sollen sie trauern.", "Unquestionably, for the allies of Allah there will be no fear concerning them, nor will they grieve."],
  [11, 88, "إِنْ أُرِيدُ إِلَّا الْإِصْلَاحَ مَا اسْتَطَعْتُ ۚ وَمَا تَوْفِيقِي إِلَّا بِاللَّهِ ۚ عَلَيْهِ تَوَكَّلْتُ وَإِلَيْهِ أُنِيبُ", "Ben sadece gücümün yettiği kadar ıslah etmek istiyorum. Başarım ancak Allah'ın yardımıyladır. O'na tevekkül ettim.", "Ich will nur Besserung, soviel ich kann. Mein Erfolg liegt nur bei Allah. Auf Ihn vertraue ich.", "I only intend reform as much as I am able. And my success is not but through Allah. Upon Him I have relied."],
  [11, 114, "وَأَقِمِ الصَّلَاةَ طَرَفَيِ النَّهَارِ وَزُلَفًا مِّنَ اللَّيْلِ ۚ إِنَّ الْحَسَنَاتِ يُذْهِبْنَ السَّيِّئَاتِ", "Gündüzün iki tarafında ve gecenin gündüze yakın vakitlerinde namaz kıl. Şüphesiz iyilikler kötülükleri giderir.", "Und verrichte das Gebet an beiden Enden des Tages und in der Nacht. Gewiss, die guten Taten tilgen die bösen.", "And establish prayer at the two ends of the day and at the approach of the night. Indeed, good deeds do away with misdeeds."],
  [11, 115, "وَاصْبِرْ فَإِنَّ اللَّهَ لَا يُضِيعُ أَجْرَ الْمُحْسِنِينَ", "Sabret; zira Allah iyilik yapanların mükâfatını zayi etmez.", "Und sei geduldig; denn Allah lässt den Lohn der Rechtschaffenen nicht verloren gehen.", "And be patient, for indeed, Allah does not allow to be lost the reward of those who do good."],
  [12, 86, "قَالَ إِنَّمَا أَشْكُو بَثِّي وَحُزْنِي إِلَى اللَّهِ وَأَعْلَمُ مِنَ اللَّهِ مَا لَا تَعْلَمُونَ", "Dedi ki: Ben kederimi ve hüznümü sadece Allah'a arz ederim; ve Allah katından sizin bilmediklerinizi bilirim.", "Er sagte: Ich klage meinen Kummer und mein Leid nur Allah, und ich weiß von Allah, was ihr nicht wisst.", "He said, 'I only complain of my suffering and my grief to Allah, and I know from Allah that which you do not know.'"],
  [12, 87, "وَلَا تَيْأَسُوا مِن رَّوْحِ اللَّهِ ۖ إِنَّهُ لَا يَيْأَسُ مِن رَّوْحِ اللَّهِ إِلَّا الْقَوْمُ الْكَافِرُونَ", "Allah'ın rahmetinden ümidinizi kesmeyin; çünkü kâfirler topluluğundan başkası Allah'ın rahmetinden ümit kesmez.", "Verzweifelt nicht an Allahs Barmherzigkeit; denn nur das ungläubige Volk verzweifelt an Seiner Barmherzigkeit.", "And despair not of relief from Allah. Indeed, no one despairs of relief from Allah except the disbelieving people."],
  [13, 11, "إِنَّ اللَّهَ لَا يُغَيِّرُ مَا بِقَوْمٍ حَتَّىٰ يُغَيِّرُوا مَا بِأَنفُسِهِمْ", "Şüphesiz bir topluluk kendi durumunu değiştirmedikçe Allah onların durumunu değiştirmez.", "Gewiss, Allah ändert die Lage eines Volkes nicht, bis sie das ändern, was in ihnen selbst ist.", "Indeed, Allah will not change the condition of a people until they change what is in themselves."],
  [13, 28, "الَّذِينَ آمَنُوا وَتَطْمَئِنُّ قُلُوبُهُم بِذِكْرِ اللَّهِ ۗ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ", "Onlar, iman eden ve kalpleri Allah'ın zikriyle huzura kavuşanlardır. Bilesiniz ki kalpler ancak Allah'ı anmakla huzur bulur.", "Diejenigen, die glauben und deren Herzen im Gedenken Allahs Ruhe finden. Im Gedenken Allahs finden die Herzen Ruhe.", "Those who have believed and whose hearts are assured by the remembrance of Allah. Unquestionably, by the remembrance of Allah hearts are assured."],

  // 51-60
  [14, 7, "وَإِذْ تَأَذَّنَ رَبُّكُمْ لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ ۖ وَلَئِن كَفَرْتُمْ إِنَّ عَذَابِي لَشَدِيدٌ", "Hani Rabbiniz şöyle buyurmuştu: Andolsun eğer şükrederseniz size nimetimi artırırım; nankörlük ederseniz azabım pek şiddetlidir.", "Und als euer Herr ankündigte: Wenn ihr dankbar seid, werde Ich euch wahrlich mehr geben.", "And when your Lord proclaimed, 'If you are grateful, I will surely increase you [in favor]; but if you deny, indeed, My punishment is severe.'"],
  [14, 40, "رَبِّ اجْعَلْنِي مُقِيمَ الصَّلَاةِ وَمِن ذُرِّيَّتِي ۚ رَبَّنَا وَتَقَبَّلْ دُعَاءِ", "Rabbim! Beni ve zürriyetimi namazı dosdoğru kılanlardan eyle. Rabbimiz! Duamı kabul buyur.", "Mein Herr, lass mich das Gebet verrichten und auch einen Teil meiner Nachkommen; unser Herr, nimm mein Gebet an.", "My Lord, make me an establisher of prayer, and [many] from my descendants. Our Lord, and accept my supplication."],
  [14, 41, "رَبَّنَا اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ", "Rabbimiz! Hesabın görüleceği gün beni, anamı-babamı ve bütün müminleri bağışla.", "Unser Herr, vergib mir und meinen Eltern und den Gläubigen an dem Tag, da die Abrechnung stattfindet.", "Our Lord, forgive me and my parents and the believers the Day the account is established."],
  [15, 9, "إِنَّا نَحْنُ نَزَّلْنَا الذِّكْرَ وَإِنَّا لَهُ لَحَافِظُونَ", "Şüphesiz o Zikr'i (Kur'an'ı) biz indirdik ve onu koruyacak olan da kesinlikle biziz.", "Gewiss, Wir Selbst haben die Ermahnung herabgesandt, und Wir werden sie gewiss hüten.", "Indeed, it is We who sent down the Qur'an and indeed, We will be its guardian."],
  [15, 98, "فَسَبِّحْ بِحَمْدِ رَبِّكَ وَكُن مِّنَ السَّاجِدِينَ", "Sen Rabbini hamd ile tesbih et ve secde edenlerden ol.", "So lobpreise deinen Herrn und gehöre zu denen, die sich niederwerfen.", "So exalt [Allah] with praise of your Lord and be of those who prostrate."],
  [16, 90, "إِنَّ اللَّهَ يَأْمُرُ بِالْعَدْلِ وَالْإِحْسَانِ وَإِيتَاءِ ذِي الْقُرْبَىٰ وَيَنْهَىٰ عَنِ الْفَحْشَاءِ وَالْمُنكَرِ وَالْبَغْيِ", "Şüphesiz Allah adaleti, iyiliği ve akrabaya vermeyi emreder; hayasızlığı, kötülüğü ve azgınlığı yasaklar.", "Gewiss, Allah gebietet Gerechtigkeit, gütig zu sein und den Verwandten zu geben; und Er verbietet das Schändliche und das Verwerfliche.", "Indeed, Allah orders justice and good conduct and giving to relatives and forbids immorality and bad conduct and oppression."],
  [16, 96, "مَا عِندَكُمْ يَنفَدُ ۖ وَمَا عِندَ اللَّهِ بَاقٍ ۗ وَلَنَجْزِيَنَّ الَّذِينَ صَبَرُوا أَجْرَهُم بِأَحْسَنِ مَا كَانُوا يَعْمَلُونَ", "Sizin yanınızdaki tükenir, Allah'ın katındaki ise bakidir. Sabredenlerin mükâfatını en güzeliyle vereceğiz.", "Was bei euch ist, vergeht; was aber bei Allah ist, bleibt bestehen. Wir werden den Geduldigen ihren Lohn vergelten.", "Whatever you have will end, but what Allah has is lasting. And We will surely give those who were patient their reward."],
  [16, 97, "مَنْ عَمِلَ صَالِحًا مِّن ذَكَرٍ أَوْ أُنثَىٰ وَهُوَ مُؤْمِنٌ فَلَنُحْيِيَنَّهُ حَيَاةً طَيِّبَةً", "Erkek veya kadın, her kim inanarak salih amel işlerse, ona mutlaka güzel bir hayat yaşatırız.", "Wer rechtschaffen handelt, ob Mann oder Frau, und dabei gläubig ist, den werden Wir gewiss ein gutes Leben leben lassen.", "Whoever does righteousness, whether male or female, while he is a believer - We will surely cause him to live a good life."],
  [16, 125, "ادْعُ إِلَىٰ سَبِيلِ رَبِّكَ بِالْحِكْمَةِ وَالْمَوْعِظَةِ الْحَسَنَةِ ۖ وَجَادِلْهُم بِالَّتِي هِيَ أَحْسَنُ", "Rabbinin yoluna hikmetle ve güzel öğütle çağır ve onlarla en güzel şekilde mücadele et.", "Rufe zum Weg deines Herrn mit Weisheit und schöner Ermahnung, und streite mit ihnen auf die beste Art.", "Invite to the way of your Lord with wisdom and good instruction, and argue with them in a way that is best."],
  [16, 128, "إِنَّ اللَّهَ مَعَ الَّذِينَ اتَّقَوا وَّالَّذِينَ هُم مُّحْسِنُونَ", "Şüphesiz Allah, takva sahipleriyle ve iyilik edenlerle beraberdir.", "Gewiss, Allah ist mit denen, die gottesfürchtig sind und Gutes tun.", "Indeed, Allah is with those who fear Him and those who are doers of good."],

  // 61-70
  [17, 23, "وَقَضَىٰ رَبُّكَ أَلَّا تَعْبُدُوا إِلَّا إِيَّاهُ وَبِالْوَالِدَيْنِ إِحْسَانًا ۚ إِمَّا يَبْلُغَنَّ عِندَكَ الْكِبَرَ أَحَدُهُمَا أَوْ كِلَاهُمَا فَلَا تَقُل لَّهُمَا أُفٍّ", "Rabbin, yalnız O'na kulluk etmenizi ve ana-babaya iyi davranmanızı emretti. Onlardan biri veya her ikisi yanında yaşlanırsa onlara 'öf' bile deme.", "Und dein Herr hat bestimmt, dass ihr nur Ihm dienen und zu den Eltern gütig sein sollt. Wenn einer von ihnen alt wird, sag nicht 'Pfui' zu ihnen.", "And your Lord has decreed that you not worship except Him, and to parents, good treatment. If one or both reach old age, say not to them 'uff'."],
  [17, 24, "وَاخْفِضْ لَهُمَا جَنَاحَ الذُّلِّ مِنَ الرَّحْمَةِ وَقُل رَّبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا", "Onlara merhametle tevazu kanadını indir ve de ki: Rabbim! Küçüklüğümde beni terbiye ettikleri gibi sen de onlara merhamet et.", "Und senke für sie den Flügel der Demut aus Barmherzigkeit und sprich: Mein Herr, erbarme Dich ihrer, wie sie mich aufzogen.", "And lower to them the wing of humility out of mercy and say, 'My Lord, have mercy upon them as they brought me up when I was small.'"],
  [17, 78, "أَقِمِ الصَّلَاةَ لِدُلُوكِ الشَّمْسِ إِلَىٰ غَسَقِ اللَّيْلِ وَقُرْآنَ الْفَجْرِ ۖ إِنَّ قُرْآنَ الْفَجْرِ كَانَ مَشْهُودًا", "Güneşin zevalinden gecenin karanlığına kadar namaz kıl; sabah Kur'an'ını da kıl. Şüphesiz sabah Kur'an'ı şahitlidir.", "Verrichte das Gebet beim Neigen der Sonne bis zum Dunkel der Nacht, und das Lesen des Morgens; das Lesen des Morgens wird bezeugt.", "Establish prayer at the decline of the sun until the darkness of the night and [also] the Qur'an of dawn. Indeed, the recitation of dawn is ever witnessed."],
  [17, 80, "وَقُل رَّبِّ أَدْخِلْنِي مُدْخَلَ صِدْقٍ وَأَخْرِجْنِي مُخْرَجَ صِدْقٍ وَاجْعَل لِّي مِن لَّدُنكَ سُلْطَانًا نَّصِيرًا", "De ki: Rabbim! Gireceğim yere doğrulukla girmemi sağla, çıkacağım yerden de doğrulukla çıkmamı nasip eyle; katından bana yardımcı bir güç ver.", "Sprich: Mein Herr, lass mich einen wahrhaftigen Eingang finden und einen wahrhaftigen Ausgang nehmen, und gib mir eine helfende Macht.", "And say, 'My Lord, cause me to enter a sound entrance and to exit a sound exit and grant me from Yourself a supporting authority.'"],
  [17, 82, "وَنُنَزِّلُ مِنَ الْقُرْآنِ مَا هُوَ شِفَاءٌ وَرَحْمَةٌ لِّلْمُؤْمِنِينَ", "Biz Kur'an'dan, müminler için şifa ve rahmet olan şeyleri indiriyoruz.", "Und Wir offenbaren vom Koran, was Heilung und Barmherzigkeit für die Gläubigen ist.", "And We send down of the Qur'an that which is healing and mercy for the believers."],
  [18, 10, "إِذْ أَوَى الْفِتْيَةُ إِلَى الْكَهْفِ فَقَالُوا رَبَّنَا آتِنَا مِن لَّدُنكَ رَحْمَةً وَهَيِّئْ لَنَا مِنْ أَمْرِنَا رَشَدًا", "O gençler mağaraya sığındıklarında: Rabbimiz! Bize katından bir rahmet ver ve işimizde bize bir kurtuluş yolu hazırla, demişlerdi.", "Als die Jünglinge in der Höhle Zuflucht suchten und sagten: Unser Herr, schenke uns Barmherzigkeit von Dir und bereite uns einen rechten Weg.", "When the youths retreated to the cave and said, 'Our Lord, grant us from Yourself mercy and prepare for us from our affair right guidance.'"],
  [18, 46, "الْمَالُ وَالْبَنُونَ زِينَةُ الْحَيَاةِ الدُّنْيَا ۖ وَالْبَاقِيَاتُ الصَّالِحَاتُ خَيْرٌ عِندَ رَبِّكَ ثَوَابًا وَخَيْرٌ أَمَلًا", "Mal ve çocuklar dünya hayatının süsüdür. Kalıcı olan salih ameller ise Rabbinin katında sevapça daha hayırlı, ümit bağlamaya daha layıktır.", "Besitz und Kinder sind der Schmuck des irdischen Lebens. Das Bleibende aber, die rechtschaffenen Werke, sind besser bei deinem Herrn.", "Wealth and children are [but] adornment of the worldly life. But the enduring good deeds are better to your Lord for reward and better for hope."],
  [18, 110, "فَمَن كَانَ يَرْجُو لِقَاءَ رَبِّهِ فَلْيَعْمَلْ عَمَلًا صَالِحًا وَلَا يُشْرِكْ بِعِبَادَةِ رَبِّهِ أَحَدًا", "Artık her kim Rabbine kavuşmayı umuyorsa salih bir amel işlesin ve Rabbine ibadette hiçbir şeyi ortak koşmasın.", "Wer auf die Begegnung mit seinem Herrn hofft, der soll rechtschaffen handeln und Seinem Herrn niemanden beigesellen.", "So whoever would hope for the meeting with his Lord - let him do righteous work and not associate in the worship of his Lord anyone."],
  [19, 96, "إِنَّ الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ سَيَجْعَلُ لَهُمُ الرَّحْمَٰنُ وُدًّا", "İman edip salih amel işleyenler var ya, Rahmân onlar için bir sevgi kılacaktır.", "Denen, die glauben und gute Werke tun, wird der Allerbarmer Liebe bereiten.", "Indeed, those who have believed and done righteous deeds - the Most Merciful will appoint for them affection."],
  [20, 14, "إِنَّنِي أَنَا اللَّهُ لَا إِلَٰهَ إِلَّا أَنَا فَاعْبُدْنِي وَأَقِمِ الصَّلَاةَ لِذِكْرِي", "Şüphesiz ben, evet ben Allah'ım! Benden başka ilah yoktur. Bana kulluk et ve beni anmak için namaz kıl.", "Ich bin Allah; es gibt keinen Gott außer Mir. Diene Mir und verrichte das Gebet zu Meinem Gedenken.", "Indeed, I am Allah. There is no deity except Me, so worship Me and establish prayer for My remembrance."],

  // 71-80
  [20, 25, "قَالَ رَبِّ اشْرَحْ لِي صَدْرِي ۝ وَيَسِّرْ لِي أَمْرِي", "Dedi ki: Rabbim! Gönlüme ferahlık ver ve işimi bana kolaylaştır.", "Er sagte: Mein Herr, weite mir meine Brust und erleichtere mir meine Aufgabe.", "He said, 'My Lord, expand for me my breast and ease for me my task.'"],
  [20, 114, "وَقُل رَّبِّ زِدْنِي عِلْمًا", "Ve de ki: Rabbim, ilmimi artır!", "Und sprich: Mein Herr, mehre mein Wissen!", "And say, 'My Lord, increase me in knowledge.'"],
  [20, 130, "فَاصْبِرْ عَلَىٰ مَا يَقُولُونَ وَسَبِّحْ بِحَمْدِ رَبِّكَ قَبْلَ طُلُوعِ الشَّمْسِ وَقَبْلَ غُرُوبِهَا", "Onların dediklerine sabret; güneşin doğmasından önce ve batmasından önce Rabbini hamd ile tesbih et.", "Ertrage geduldig, was sie sagen, und preise deinen Herrn vor dem Aufgang der Sonne und vor ihrem Untergang.", "So be patient over what they say and exalt [Allah] with praise of your Lord before the rising of the sun and before its setting."],
  [21, 87, "لَّا إِلَٰهَ إِلَّا أَنتَ سُبْحَانَكَ إِنِّي كُنتُ مِنَ الظَّالِمِينَ", "Senden başka hiçbir ilah yoktur. Seni tenzih ederim. Şüphesiz ben haksızlık edenlerden oldum.", "Es gibt keinen Gott außer Dir! Preis sei Dir! Gewiss, ich gehörte zu den Ungerechten.", "There is no deity except You; exalted are You. Indeed, I have been of the wrongdoers."],
  [21, 107, "وَمَا أَرْسَلْنَاكَ إِلَّا رَحْمَةً لِّلْعَالَمِينَ", "Biz seni ancak âlemlere rahmet olarak gönderdik.", "Und Wir haben dich nur als Barmherzigkeit für die Welten gesandt.", "And We have not sent you except as a mercy to the worlds."],
  [22, 77, "يَا أَيُّهَا الَّذِينَ آمَنُوا ارْكَعُوا وَاسْجُدُوا وَاعْبُدُوا رَبَّكُمْ وَافْعَلُوا الْخَيْرَ لَعَلَّكُمْ تُفْلِحُونَ", "Ey iman edenler! Rükû edin, secdeye varın, Rabbinize kulluk edin ve iyilik yapın ki kurtuluşa eresiniz.", "O die ihr glaubt, verneigt euch und werft euch nieder und dient eurem Herrn und tut das Gute, auf dass es euch wohl ergehe.", "O you who have believed, bow and prostrate and worship your Lord and do good - that you may succeed."],
  [23, 1, "قَدْ أَفْلَحَ الْمُؤْمِنُونَ ۝ الَّذِينَ هُمْ فِي صَلَاتِهِمْ خَاشِعُونَ", "Müminler kesinlikle kurtuluşa ermiştir; onlar ki namazlarında huşû içindedirler.", "Den Gläubigen wird es gewiss wohl ergehen, die in ihren Gebeten demütig sind.", "Certainly will the believers have succeeded: They who are during their prayer humbly submissive."],
  [23, 118, "وَقُل رَّبِّ اغْفِرْ وَارْحَمْ وَأَنتَ خَيْرُ الرَّاحِمِينَ", "Ve de ki: Rabbim! Bağışla ve merhamet et; sen merhamet edenlerin en hayırlısısın.", "Und sprich: Mein Herr, vergib und erbarme Dich, denn Du bist der Beste der Barmherzigen.", "And say, 'My Lord, forgive and have mercy, and You are the best of the merciful.'"],
  [24, 35, "اللَّهُ نُورُ السَّمَاوَاتِ وَالْأَرْضِ", "Allah göklerin ve yerin nurudur.", "Allah ist das Licht der Himmel und der Erde.", "Allah is the Light of the heavens and the earth."],
  [24, 37, "رِجَالٌ لَّا تُلْهِيهِمْ تِجَارَةٌ وَلَا بَيْعٌ عَن ذِكْرِ اللَّهِ وَإِقَامِ الصَّلَاةِ وَإِيتَاءِ الزَّكَاةِ", "Öyle erler vardır ki onları ne bir ticaret ne de bir alışveriş Allah'ı anmaktan, namazı kılmaktan ve zekâtı vermekten alıkoyamaz.", "Männer, die weder Ware noch Handel vom Gedenken Allahs, der Verrichtung des Gebets und der Zakat-Gabe ablenken.", "Men whom neither commerce nor sale distracts from the remembrance of Allah and performance of prayer and giving of zakah."],

  // 81-90
  [25, 63, "وَعِبَادُ الرَّحْمَٰنِ الَّذِينَ يَمْشُونَ عَلَى الْأَرْضِ هَوْنًا وَإِذَا خَاطَبَهُمُ الْجَاهِلُونَ قَالُوا سَلَامًا", "Rahmân'ın kulları yeryüzünde tevazuyla yürüyenlerdir; cahiller onlara laf attığında 'Selam!' deyip geçerler.", "Und die Diener des Allerbarmers sind diejenigen, die bescheiden auf der Erde wandeln, und wenn Unwissende sie anreden, 'Frieden!' sagen.", "And the servants of the Most Merciful are those who walk upon the earth easily, and when the ignorant address them, say 'peace'."],
  [25, 74, "رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا وَذُرِّيَّاتِنَا قُرَّةَ أَعْيُنٍ وَاجْعَلْنَا لِلْمُتَّقِينَ إِمَامًا", "Rabbimiz! Bize gözümüzü aydınlatacak eşler ve zürriyetler bağışla ve bizi takva sahiplerine önder kıl.", "Unser Herr, schenke uns an unseren Gattinnen und Nachkommen Grund zur Freude, und mache uns zum Vorbild für die Gottesfürchtigen.", "Our Lord, grant us from among our wives and offspring comfort to our eyes and make us a leader for the righteous."],
  [26, 80, "وَإِذَا مَرِضْتُ فَهُوَ يَشْفِينِ", "Hastalandığım zaman bana şifa veren O'dur.", "Und wenn ich krank bin, heilt Er mich.", "And when I am ill, it is He who cures me."],
  [26, 88, "يَوْمَ لَا يَنفَعُ مَالٌ وَلَا بَنُونَ ۝ إِلَّا مَنْ أَتَى اللَّهَ بِقَلْبٍ سَلِيمٍ", "O gün ne mal fayda verir ne de oğullar. Ancak Allah'a arınmış selim bir kalp ile gelen müstesna.", "An dem Tag, da weder Besitz noch Söhne nützen, außer wer zu Allah mit heilem Herzen kommt.", "The Day when there will not benefit [anyone] wealth or children, but only one who comes to Allah with a sound heart."],
  [27, 19, "رَبِّ أَوْزِعْنِي أَنْ أَشْكُرَ نِعْمَتَكَ الَّتِي أَنْعَمْتَ عَلَيَّ وَعَلَىٰ وَالِدَيَّ وَأَنْ أَعْمَلَ صَالِحًا تَرْضَاهُ", "Rabbim! Bana ve ana-babama lütfettiğin nimete şükretmemi ve razı olacağın salih amel işlememi bana ilham eyle.", "Mein Herr, gib mir ein, dass ich für Deine Gnade danke, die Du mir und meinen Eltern erwiesen hast, und Gutes tue.", "My Lord, enable me to be grateful for Your favor which You have bestowed upon me and upon my parents and to do good deeds that please You."],
  [27, 62, "أَمَّن يُجِيبُ الْمُضْطَرَّ إِذَا دَعَاهُ وَيَكْشِفُ السُّوءَ", "Darda kalana, dua ettiği zaman icabet eden ve kötülüğü gideren kimdir?", "Wer erhört denn den Bedrängten, wenn er Ihn anruft, und nimmt das Übel hinweg?", "Is not He [best] who responds to the desperate one when he calls upon Him and removes evil?"],
  [28, 77, "وَأَحْسِن كَمَا أَحْسَنَ اللَّهُ إِلَيْكَ ۖ وَلَا تَبْغِ الْفَسَادَ فِي الْأَرْضِ", "Allah'ın sana ihsan ettiği gibi sen de iyilik et; yeryüzünde bozgunculuk isteme.", "Und tue Gutes, wie Allah dir Gutes getan hat, und trachte nicht nach Unheil auf der Erde.", "And do good as Allah has done good to you. And desire not corruption in the land."],
  [29, 45, "اتْلُ مَا أُوحِيَ إِلَيْكَ مِنَ الْكِتَابِ وَأَقِمِ الصَّلَاةَ ۖ إِنَّ الصَّلَاةَ تَنْهَىٰ عَنِ الْفَحْشَاءِ وَالْمُنكَرِ ۗ وَلَذِكْرُ اللَّهِ أَكْبَرُ", "Kitaptan sana vahyolunanı oku ve namazı dosdoğru kıl. Şüphesiz namaz hayasızlıktan ve kötülükten alıkoyar. Allah'ı anmak ise en büyüktür.", "Verlies, was dir vom Buch offenbart wurde, und verrichte das Gebet. Gewiss, das Gebet hält vom Schändlichen und Verwerflichen ab.", "Recite what has been revealed to you of the Book and establish prayer. Indeed, prayer prohibits immorality and wrongdoing."],
  [29, 69, "وَالَّذِينَ جَاهَدُوا فِينَا لَنَهْدِيَنَّهُمْ سُبُلَنَا ۚ وَإِنَّ اللَّهَ لَمَعَ الْمُحْسِنِينَ", "Bizim uğrumuzda cihat edenleri elbette kendi yollarımıza eriştiririz. Şüphesiz Allah iyilik edenlerle beraberdir.", "Und diejenigen, die sich um Unsertwillen abmühen, werden Wir gewiss auf Unseren Wegen leiten.", "And those who strive for Us - We will surely guide them to Our ways. And indeed, Allah is with the doers of good."],
  [30, 21, "وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ أَزْوَاجًا لِّتَسْكُنُوا إِلَيْهَا وَجَعَلَ بَيْنَكُم مَّوَدَّةً وَرَحْمَةً", "O'nun ayetlerinden biri de kendileriyle huzur bulasınız diye sizin için nefislerinizden eşler yaratması ve aranıza sevgi ve merhamet koymasıdır.", "Und es gehört zu Seinen Zeichen, dass Er euch aus euch selbst Gattinnen erschaffen hat, damit ihr bei ihnen Ruhe findet.", "And of His signs is that He created for you from yourselves mates that you may find tranquility in them, and He placed affection and mercy."],

  // 91-100
  [31, 17, "يَا بُنَيَّ أَقِمِ الصَّلَاةَ وَأْمُرْ بِالْمَعْرُوفِ وَانْهَ عَنِ الْمُنكَرِ وَاصْبِرْ عَلَىٰ مَا أَصَابَكَ", "Yavrucuğum! Namazı dosdoğru kıl, iyiliği emret, kötülükten vazgeçirmeye çalış ve başına gelenlere sabret.", "O mein lieber Sohn, verrichte das Gebet, gebiete das Gute, verbiete das Verwerfliche und ertrage geduldig, was dich trifft.", "O my son, establish prayer, enjoin what is right, forbid what is wrong, and be patient over what befalls you."],
  [31, 18, "وَلَا تُصَعِّرْ خَدَّكَ لِلنَّاسِ وَلَا تَمْشِ فِي الْأَرْضِ مَرَحًا ۖ إِنَّ اللَّهَ لَا يُحِبُّ كُلَّ مُخْتَالٍ فَخُورٍ", "Küçümseyerek insanlardan yüz çevirme ve yeryüzünde böbürlenerek yürüme. Zira Allah büyüklük taslayan ve övünen kimseyi sevmez.", "Und wende deine Wange nicht hochmütig von den Menschen ab und wandle nicht übermütig auf der Erde.", "And do not turn your cheek [in contempt] toward people and do not walk through the earth exultantly. Indeed, Allah does not like any arrogant boaster."],
  [33, 21, "لَّقَدْ كَانَ لَكُمْ فِي رَسُولِ اللَّهِ أُسْوَةٌ حَسَنَةٌ لِّمَن كَانَ يَرْجُو اللَّهَ وَالْيَوْمَ الْآخِرَ وَذَكَرَ اللَّهَ كَثِيرًا", "Andolsun Allah'ın Resûlünde sizin için, Allah'a ve ahiret gününe kavuşmayı uman ve Allah'ı çok anan kimseler için güzel bir örnek vardır.", "Ihr habt im Gesandten Allahs ein schönes Vorbild für den, der auf Allah und den Jüngsten Tag hofft.", "There has certainly been for you in the Messenger of Allah an excellent pattern for anyone whose hope is in Allah and the Last Day."],
  [33, 41, "يَا أَيُّهَا الَّذِينَ آمَنُوا اذْكُرُوا اللَّهَ ذِكْرًا كَثِيرًا ۝ وَسَبِّحُوهُ بُكْرَةً وَأَصِيلًا", "Ey iman edenler! Allah'ı çokça zikredin ve O'nu sabah akşam tesbih edin.", "O die ihr glaubt, gedenkt Allahs mit häufigem Gedenken und preist Ihn morgens und abends.", "O you who have believed, remember Allah with much remembrance and exalt Him morning and afternoon."],
  [33, 56, "إِنَّ اللَّهَ وَمَلَائِكَتَهُ يُصَلُّونَ عَلَى النَّبِيِّ ۚ يَا أَيُّهَا الَّذِينَ آمَنُوا صَلُّوا عَلَيْهِ وَسَلِّمُوا تَسْلِيمًا", "Şüphesiz Allah ve melekleri Peygamber'e salât ederler. Ey iman edenler! Siz de ona salât ve selam getirin.", "Gewiss, Allah und Seine Engel sprechen Segnungen über den Propheten. O die ihr glaubt, sprecht Segnungen über ihn und grüßt ihn mit Frieden.", "Indeed, Allah and His angels confer blessings upon the Prophet. O you who have believed, ask [Allah to confer] blessing upon him and ask [Allah to grant him] peace."],
  [34, 39, "وَمَا أَنفَقْتُم مِّن شَيْءٍ فَهُوَ يُخْلِفُهُ ۖ وَهُوَ خَيْرُ الرَّازِقِينَ", "Siz hayır için ne harcarsanız, Allah onun yerine yenisini verir; O, rızık verenlerin en hayırlısıdır.", "Und was immer ihr an Gutem ausgebt, Er wird es ersetzen, und Er ist der beste Versorger.", "And whatever you spend of anything - He will compensate it; and He is the best of providers."],
  [35, 15, "يَا أَيُّهَا النَّاسُ أَنتُمُ الْفُقَرَاءُ إِلَى اللَّهِ ۖ وَاللَّهُ هُوَ الْغَنِيُّ الْحَمِيدُ", "Ey insanlar! Siz Allah'a muhtaçsınız; Allah ise hiçbir şeye muhtaç olmayan, her türlü övgüye layık olandır.", "O ihr Menschen, ihr seid diejenigen, die Allahs bedürfen; Allah aber ist der Reiche, der Lobenswürdige.", "O mankind, you are those in need of Allah, while Allah is the Free of need, the Praiseworthy."],
  [36, 58, "سَلَامٌ قَوْلًا مِّن رَّبٍّ رَّحِيمٍ", "Çok merhametli olan Rablerinden bir söz olarak onlara 'Selam' vardır.", "'Frieden!' – ein Wort von einem barmherzigen Herrn.", "'Peace,' a word from a Merciful Lord."],
  [36, 82, "إِنَّمَا أَمْرُهُ إِذَا أَرَادَ شَيْئًا أَن يَقُولَ لَهُ كُن فَيَكُونُ", "Bir şeyi dilediği zaman O'nun emri sadece ona 'Ol!' demektir; o da hemen oluverir.", "Sein Befehl, wenn Er ein Ding will, ist nur, dass Er dazu spricht: 'Sei!', und es ist.", "His command is only when He intends a thing that He says to it, 'Be,' and it is."],
  [37, 180, "سُبْحَانَ رَبِّكَ رَبِّ الْعِزَّةِ عَمَّا يَصِفُونَ ۝ وَسَلَامٌ عَلَى الْمُرْسَلِينَ ۝ وَالْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", "Senin izzet sahibi Rabbin, onların isnat ettikleri vasıflardan münezzehtir. Gönderilen bütün peygamberlere selam olsun. Hamd âlemlerin Rabbi Allah'a mahsustur.", "Preis sei deinem Herrn, dem Herrn der Macht, erhaben über das, was sie beschreiben! Und Friede sei auf den Gesandten! Und alles Lob gebührt Allah.", "Exalted is your Lord, the Lord of might, above what they describe. And peace upon the messengers. And praise to Allah, Lord of the worlds."],

  // 101-110
  [39, 9, "قُلْ هَلْ يَسْتَوِي الَّذِينَ يَعْلَمُونَ وَالَّذِينَ لَا يَعْلَمُونَ ۗ إِنَّمَا يَتَذَكَّرُ أُولُو الْأَلْبَابِ", "De ki: Hiç bilenlerle bilmeyenler bir olur mu? Doğrusu ancak akıl sahipleri bunu idrak eder.", "Sprich: Sind etwa diejenigen, die wissen, und diejenigen, die nicht wissen, einander gleich?", "Say, 'Are those who know equal to those who do not know?' Only they will remember [who are] people of understanding."],
  [39, 10, "إِنَّمَا يُوَفَّى الصَّابِرُونَ أَجْرَهُم بِغَيْرِ حِسَابٍ", "Yalnızca sabredenlere mükâfatları hesapsız olarak ödenecektir.", "Den Geduldigen wird ihr Lohn gewiss ohne Abrechnung voll erstattet werden.", "Only the patient will be paid their reward without account."],
  [39, 53, "قُلْ يَا عِبَادِيَ الَّذِينَ أَسْرَفُوا عَلَىٰ أَنفُسِهِمْ لَا تَقْنَطُوا مِن رَّحْمَةِ اللَّهِ ۚ إِنَّ اللَّهَ يَغْفِرُ الذُّنُوبَ جَمِيعًا", "De ki: Ey kendilerine kötülük edip aşırı giden kullarım! Allah'ın rahmetinden ümidinizi kesmeyin. Muhakkak ki Allah bütün günahları bağışlar.", "Sprich: O Meine Diener, die ihr maßlos gegen euch selbst gewesen seid, verzweifelt nicht an Allahs Barmherzigkeit! Gewiss, Allah vergibt alle Sünden.", "Say, 'O My servants who have transgressed against themselves, despair not of the mercy of Allah. Indeed, Allah forgives all sins.'"],
  [40, 44, "وَأُفَوِّضُ أَمْرِي إِلَى اللَّهِ ۚ إِنَّ اللَّهَ بَصِيرٌ بِالْعِبَادِ", "Ben işimi Allah'a havale ediyorum. Şüphesiz Allah kullarını hakkıyla görendir.", "Und ich überlasse meine Angelegenheit Allah; gewiss, Allah sieht die Diener wohl.", "And I entrust my affair to Allah. Indeed, Allah is Seeing of His servants."],
  [40, 60, "وَقَالَ رَبُّكُمُ ادْعُونِي أَسْتَجِبْ لَكُمْ", "Rabbiniz buyurdu ki: Bana dua edin, size icabet edeyim.", "Und euer Herr sprach: Bittet Mich, so erhöre Ich euch.", "And your Lord says, 'Call upon Me; I will respond to you.'"],
  [41, 30, "إِنَّ الَّذِينَ قَالُوا رَبُّنَا اللَّهُ ثُمَّ اسْتَقَامُوا تَتَنَزَّلُ عَلَيْهِمُ الْمَلَائِكَةُ أَلَّا تَخَافُوا وَلَا تَحْزَنُوا", "Rabbimiz Allah'tır deyip sonra dosdoğru olanların üzerine melekler iner: Korkmayın, üzülmeyin, size vadedilen cennetle sevinin!", "Gewiss, diejenigen, die sagen: 'Unser Herr ist Allah', und sich hierauf recht verhalten, auf sie kommen die Engel herab: Fürchtet euch nicht und trauert nicht.", "Indeed, those who have said, 'Our Lord is Allah' and then remained on a right course - the angels will descend upon them, [saying], 'Do not fear and do not grieve.'"],
  [41, 34, "ادْفَعْ بِالَّتِي هِيَ أَحْسَنُ فَإِذَا الَّذِي بَيْنَكَ وَبَيْنَهُ عَدَاوَةٌ كَأَنَّهُ وَلِيٌّ حَمِيمٌ", "Kötülüğü en güzel olanla sav; o zaman göreceksin ki seninle arasında düşmanlık bulunan kimse sanki sıcak bir dost oluvermiştir.", "Wehre das Böse mit dem ab, was besser ist; dann wird derjenige, zwischen dem und dir Feindschaft war, wie ein herzlicher Freund.", "Repel [evil] by that [deed] which is better; and thereupon the one whom between you and him was enmity [will become] as though he were a devoted friend."],
  [42, 19, "اللَّهُ لَطِيفٌ بِعِبَادِهِ يَرْزُقُ مَن يَشَاءُ ۖ وَهُوَ الْقَوِيُّ الْعَزِيزُ", "Allah kullarına karşı çok lütufkârdır; dilediğini rızıklandırır. O kuvvetlidir, üstündür.", "Allah ist gütig zu Seinen Dienern; Er versorgt, wen Er will, und Er ist der Starke, der Allmächtige.", "Allah is subtle with His servants; He gives provision to whom He wills. And He is the Powerful, the Exalted in Might."],
  [42, 43, "وَلَمَن صَبَرَ وَغَفَرَ إِنَّ ذَٰلِكَ لَمِنْ عَزْمِ الْأُمُورِ", "Kim sabreder ve bağışlarsa şüphesiz bu, azmedilmeye değer en büyük işlerdendir.", "Wahrlich, wer geduldig ist und vergibt – das gehört gewiss zur Entschlossenheit in den Dingen.", "And whoever is patient and forgives - indeed, that is of the matters [requiring] determination."],
  [46, 13, "إِنَّ الَّذِينَ قَالُوا رَبُّنَا اللَّهُ ثُمَّ اسْتَقَامُوا فَلَا خَوْفٌ عَلَيْهِمْ وَلَا هُمْ يَحْزَنُونَ", "Şüphesiz Rabbimiz Allah'tır deyip sonra dosdoğru yaşayanlara hiçbir korku yoktur; onlar üzülmeyeceklerdir de.", "Gewiss, diejenigen, die sagen: 'Unser Herr ist Allah' und sich dann recht verhalten, keine Furcht soll über sie kommen, noch sollen sie trauern.", "Indeed, those who have said, 'Our Lord is Allah,' and then remained on a right course - there will be no fear concerning them, nor will they grieve."],

  // 111-120
  [48, 1, "إِنَّا فَتَحْنَا لَكَ فَتْحًا مُّبِينًا", "Şüphesiz biz sana apaçık bir fetih ihsan ettik.", "Gewiss, Wir haben dir einen offenkundigen Sieg verliehen.", "Indeed, We have given you a clear conquest."],
  [48, 4, "هُوَ الَّذِي أَنزَلَ السَّكِينَةَ فِي قُلُوبِ الْمُؤْمِنِينَ لِيَزْدَادُوا إِيمَانًا مَّعَ إِيمَانِهِمْ", "İmanlarını bir kat daha artırsınlar diye müminlerin kalplerine sekinet (huzur ve güven) indiren O'dur.", "Er ist es, Der die Ruhe in die Herzen der Gläubigen hinabgesandt hat, damit sie Glauben zu ihrem Glauben hinzufügen.", "It is He who sent down tranquility into the hearts of the believers that they would increase in faith together with their [already present] faith."],
  [49, 10, "إِنَّمَا الْمُؤْمِنُونَ إِخْوَةٌ فَأَصْلِحُوا بَيْنَ أَخَوَيْكُمْ ۚ وَاتَّقُوا اللَّهَ لَعَلَّكُمْ تُرْحَمُونَ", "Müminler ancak kardeştirler; öyleyse kardeşlerinizin arasını düzeltin ve Allah'tan korkun ki merhamet olunasınız.", "Die Gläubigen sind ja Brüder. So stiftet Frieden zwischen euren Brüdern und fürchtet Allah, auf dass ihr Barmherzigkeit findet.", "The believers are but brothers, so make settlement between your brothers. And fear Allah that you may receive mercy."],
  [49, 12, "يَا أَيُّهَا الَّذِينَ آمَنُوا اجْتَنِبُوا كَثِيرًا مِّنَ الظَّنِّ إِنَّ بَعْضَ الظَّنِّ إِثْمٌ ۖ وَلَا تَجَسَّسُوا وَلَا يَغْتَب بَّعْضُكُم بَعْضًا", "Ey iman edenler! Zannın çoğundan sakının; çünkü zannın bir kısmı günahtır. Birbirinizin kusurunu araştırmayın, gıybet etmeyin.", "O die ihr glaubt, meidet viel von den Mutmaßungen; gewiss, manche Mutmaßung ist Sünde. Spioniert nicht und führt keine üble Nachrede.", "O you who have believed, avoid much [negative] assumption. Indeed, some assumption is sin. And do not spy or backbite each other."],
  [49, 13, "يَا أَيُّهَا النَّاسُ إِنَّا خَلَقْنَاكُم مِّن ذَكَرٍ وَأُنثَىٰ وَجَعَلْنَاكُمْ شُعُوبًا وَقَبَائِلَ لِتَعَارَفُوا ۚ إِنَّ أَكْرَمَكُمْ عِندَ اللَّهِ أَتْقَاكُمْ", "Ey insanlar! Sizi bir erkekle bir dişiden yarattık ve tanışasınız diye sizi milletlere ve kabilelere ayırdık. Şüphesiz Allah katında en üstün olanınız, en takvalı olanınızdır.", "O Menschen, Wir haben euch aus Mann und Frau erschaffen und zu Völkern und Stämmen gemacht, damit ihr einander kennenlernt. Der Edelste von euch bei Allah ist der Gottesfürchtigste.", "O mankind, indeed We have created you from male and female and made you peoples and tribes that you may know one another. The most noble of you in the sight of Allah is the most righteous of you."],
  [50, 16, "وَلَقَدْ خَلَقْنَا الْإِنسَانَ وَنَعْلَمُ مَا تُوَسْوِسُ بِهِ نَفْسُهُ ۖ وَنَحْنُ أَقْرَبُ إِلَيْهِ مِنْ حَبْلِ الْوَرِيدِ", "Andolsun insanı biz yarattık ve nefsinin ona ne fısıldadığını biliriz; çünkü biz ona şah damarından daha yakınız.", "Und Wir haben den Menschen erschaffen und wissen, was seine Seele ihm zuflüstert; und Wir sind ihm näher als seine Halsschlagader.", "And We have already created man and know what his soul whispers to him, and We are closer to him than [his] jugular vein."],
  [51, 56, "وَمَا خَلَقْتُ الْجِنَّ وَالْإِنسَ إِلَّا لِيَعْبُدُونِ", "Ben cinleri ve insanları ancak bana kulluk etsinler diye yarattım.", "Und Ich habe die Dschinn und die Menschen nur darum erschaffen, damit sie Mir dienen.", "And I did not create the jinn and mankind except to worship Me."],
  [51, 58, "إِنَّ اللَّهَ هُوَ الرَّزَّاقُ ذُو الْقُوَّةِ الْمَتِينُ", "Şüphesiz rızık veren, sarsılmaz güç sahibi olan ancak Allah'tır.", "Gewiss, Allah ist der Allversorger, der Besitzer von Festigkeit und Macht.", "Indeed, it is Allah who is the Continual Provider, the firm possessor of strength."],
  [53, 39, "وَأَن لَّيْسَ لِلْإِنسَانِ إِلَّا مَا سَعَىٰ ۝ وَأَنَّ سَعْيَهُ سَوْفَ يُرَىٰ", "Bilsin ki insan için kendi emeğinden başka bir şey yoktur ve emeği ileride muhakkak görülecektir.", "Und dass der Mensch nur das erhält, worum er sich bemüht hat, und dass sein Bemühen sichtbar sein wird.", "And that there is not for man except that [good] for which he strives, and that his effort is going to be seen."],
  [55, 60, "هَلْ جَزَاءُ الْإِحْسَانِ إِلَّا الْإِحْسَانُ", "İyiliğin karşılığı iyilikten başka bir şey midir?", "Ist der Lohn für das Gute etwas anderes als das Gute?", "Is the reward for good [anything] but good?"],

  // 121-130
  [57, 4, "وَهُوَ مَعَكُمْ أَيْنَ مَا كُنتُمْ ۚ وَاللَّهُ بِمَا تَعْمَلُونَ بَصِيرٌ", "Nerede olursanız olun O sizinle beraberdir. Allah yaptıklarınızı hakkıyla görendir.", "Und Er ist mit euch, wo immer ihr seid. Und Allah sieht wohl, was ihr tut.", "And He is with you wherever you are. And Allah, of what you do, is Seeing."],
  [57, 16, "أَلَمْ يَأْنِ لِلَّذِينَ آمَنُوا أَن تَخْشَعَ قُلُوبُهُمْ لِذِكْرِ اللَّهِ وَمَا نَزَلَ مِنَ الْحَقِّ", "İman edenlerin, Allah'ın zikrine ve inen hakka kalplerinin huşû ile bağlanma zamanı hâlâ gelmedi mi?", "Ist nicht für die Gläubigen die Zeit gekommen, dass ihre Herzen demütig werden vor dem Gedenken Allahs?", "Has the time not come for those who have believed that their hearts should become humbly submissive at the remembrance of Allah?"],
  [58, 11, "يَرْفَعِ اللَّهُ الَّذِينَ آمَنُوا مِنكُمْ وَالَّذِينَ أُوتُوا الْعِلْمَ دَرَجَاتٍ", "Allah sizden iman edenlerin ve kendilerine ilim verilenlerin derecelerini yükseltir.", "Allah erhöht diejenigen von euch, die glauben, und diejenigen, denen das Wissen gegeben wurde, um Rangstufen.", "Allah will raise those who have believed among you and those who were given knowledge, by degrees."],
  [59, 18, "يَا أَيُّهَا الَّذِينَ آمَنُوا اتَّقُوا اللَّهَ وَلْتَنظُرْ نَفْسٌ مَّا قَدَّمَتْ لِغَدٍ ۖ وَاتَّقُوا اللَّهَ", "Ey iman edenler! Allah'tan korkun ve her can yarın için ne hazırladığına bir baksın. Allah'tan korkun!", "O die ihr glaubt, fürchtet Allah; und eine jede Seele schaue, was sie für morgen vorausschickt.", "O you who have believed, fear Allah. And let every soul look to what it has put forth for tomorrow."],
  [59, 22, "هُوَ اللَّهُ الَّذِي لَا إِلَٰهَ إِلَّا هُوَ ۖ عَالِمُ الْغَيْبِ وَالشَّهَادَةِ ۖ هُوَ الرَّحْمَٰنُ الرَّحِيمُ", "O, kendisinden başka hiçbir ilah bulunmayan Allah'tır; gaybı da görünen âlemi de bilendir. O Rahmân'dır, Rahîm'dir.", "Er ist Allah, außer Dem es keinen Gott gibt, der Kenner des Verborgenen und des Sichtbaren; Er ist der Allerbarmer, der Barmherzige.", "He is Allah, other than whom there is no deity, Knower of the unseen and the witnessed. He is the Entirely Merciful, the Especially Merciful."],
  [59, 23, "هُوَ اللَّهُ الَّذِي لَا إِلَٰهَ إِلَّا هُوَ الْمَلِكُ الْقُدُّوسُ السَّلَامُ الْمُؤْمِنُ الْمُهَيْمِنُ الْعَزِيزُ الْجَبَّارُ الْمُتَكَبِّرُ", "O öyle Allah'tır ki O'ndan başka ilah yoktur; Melik'tir, Kuddûs'tür, Selâm'dır, Mü'min'dir, Müheymin'dir, Azîz'dir, Cebbâr'dır, Mütekebbir'dir.", "Er ist Allah, außer Dem es keinen Gott gibt, der König, der Heilige, der Friede, der Gewährer der Sicherheit, der Beschützer, der Allmächtige.", "He is Allah, other than whom there is no deity, the Sovereign, the Pure, the Perfection, the Bestower of Faith, the Overseer, the Exalted in Might."],
  [59, 24, "هُوَ اللَّهُ الْخَالِقُ الْبَارِئُ الْمُصَوِّرُ ۖ لَهُ الْأَسْمَاءُ الْحُسْنَىٰ ۚ يُسَبِّحُ لَهُ مَا فِي السَّمَاوَاتِ وَالْأَرْضِ", "O yaratan, yoktan var eden, şekil veren Allah'tır. En güzel isimler O'nundur. Göklerde ve yerde olanlar O'nu tesbih eder.", "Er ist Allah, der Schöpfer, der Bildner, der Gestalter. Sein sind die schönsten Namen. Ihn preist, was in den Himmeln und auf der Erde ist.", "He is Allah, the Creator, the Inventor, the Fashioner; to Him belong the best names. Whatever is in the heavens and earth is exalting Him."],
  [61, 13, "وَأُخْرَىٰ تُحِبُّونَهَا ۖ نَصْرٌ مِّنَ اللَّهِ وَفَتْحٌ قَرِيبٌ ۗ وَبَشِّرِ الْمُؤْمِنِينَ", "Seveceğiniz bir lütuf daha var: Allah'tan bir yardım ve yakın bir fetih! Müminleri müjdele.", "Und noch ein anderes, das ihr liebt: Hilfe von Allah und ein naher Sieg. Und verkünde den Gläubigen frohe Botschaft.", "And [you will obtain] another [favor] that you love - victory from Allah and an imminent conquest; and give good tidings to the believers."],
  [62, 9, "يَا أَيُّهَا الَّذِينَ آمَنُوا إِذَا نُودِيَ لِلصَّلَاةِ مِن يَوْمِ الْجُمُعَةِ فَاسْعَوْا إِلَىٰ ذِكْرِ اللَّهِ وَذَرُوا الْبَيْعَ", "Ey iman edenler! Cuma günü namaza çağrıldığınız zaman hemen Allah'ın zikrine koşun ve alışverişi bırakın.", "O die ihr glaubt, wenn zum Freitagsgebet gerufen wird, dann eilt zu Allahs Gedenken und lasst das Kaufgeschäft ruhen.", "O you who have believed, when [the adhan] is called for the prayer on the day of Jumu'ah, then proceed to the remembrance of Allah and leave trade."],
  [62, 10, "فَإِذَا قُضِيَتِ الصَّلَاةُ فَانتَشِرُوا فِي الْأَرْضِ وَابْتَغُوا مِن فَضْلِ اللَّهِ وَاذْكُرُوا اللَّهَ كَثِيرًا لَّعَلَّكُمْ تُفْلِحُونَ", "Namaz kılınınca yeryüzüne dağılın ve Allah'ın lütfundan rızık arayın; Allah'ı çokça zikredin ki kurtuluşa eresiniz.", "Wenn das Gebet beendet ist, dann breitet euch auf der Erde aus und trachtet nach Allahs Gunst und gedenkt Allahs viel.", "And when the prayer has been concluded, disperse within the land and seek from the bounty of Allah, and remember Allah often that you may succeed."],

  // 131-140
  [64, 11, "مَا أَصَابَ مِن مُّصِيبَةٍ إِلَّا بِإِذْنِ اللَّهِ ۗ وَمَن يُؤْمِن بِاللَّهِ يَهْدِ قَلْبَهُ", "Allah'ın izni olmadan hiçbir musibet isabet etmez. Kim Allah'a inanırsa, O onun kalbini doğruya iletir.", "Kein Unglück trifft ein, außer mit Allahs Erlaubnis. Und wer an Allah glaubt, dessen Herz leitet Er recht.", "No disaster strikes except by permission of Allah. And whoever believes in Allah - He will guide his heart."],
  [65, 2, "وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجًا ۝ وَيَرْزُقْهُ مِنْ حَيْثُ لَا يَحْتَسِبُ", "Kim Allah'tan korkup sakınırsa, Allah ona bir çıkış yolu ihsan eder ve ona beklemediği yerden rızık verir.", "Und wer Allah fürchtet, dem schafft Er einen Ausweg und versorgt ihn von wo er es nicht erwartet.", "And whoever fears Allah - He will make for him a way out and will provide for him from where he does not expect."],
  [65, 3, "وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ ۚ إِنَّ اللَّهَ بَالِغُ أَمْرِهِ", "Kim Allah'a tevekkül ederse O, ona yeter. Şüphesiz Allah emrini yerine getirendir.", "Und wer auf Allah vertraut, dem ist Er seine Genüge. Gewiss, Allah führt Seine Angelegenheit durch.", "And whoever relies upon Allah - then He is sufficient for him. Indeed, Allah will accomplish His purpose."],
  [67, 1, "تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ", "Mülk elinde bulunan Allah ne yücedir! O, her şeye hakkıyla kadirdir.", "Segensreich ist Derjenige, in Dessen Hand die Herrschaft ist; und Er hat zu allem die Macht.", "Blessed is He in whose hand is dominion, and He is over all things competent."],
  [67, 2, "الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا ۚ وَهُوَ الْعَزِيزُ الْغَفُورُ", "O, hanginizin daha güzel amel yapacağını sınamak için ölümü ve hayatı yarattı. O Azîz'dir, Gafûr'dur.", "Der den Tod und das Leben erschaffen hat, um euch zu prüfen, wer von euch die besten Taten vollbringt.", "He who created death and life to test you as to which of you is best in deed - and He is the Exalted in Might, the Forgiving."],
  [67, 14, "أَلَا يَعْلَمُ مَنْ خَلَقَ وَهُوَ اللَّطِيفُ الْخَبِيرُ", "Yaratan hiç bilmez mi? O Latîf'tir, Habîr'dir (bütün incelikleri bilir, her şeyden haberdardır).", "Sollte Er denn nicht wissen, was Er erschaffen hat? Er ist der Feinfühlige, der Allkundige.", "Does He who created not know, while He is the Subtle, the Acquainted?"],
  [68, 4, "وَإِنَّكَ لَعَلَىٰ خُلُقٍ عَظِيمٍ", "Şüphesiz sen pek yüce bir ahlâk üzeresin.", "Und du bist wahrlich von edler Gemütsart.", "And indeed, you are of a great moral character."],
  [73, 4, "أَوْ زِدْ عَلَيْهِ وَرَتِّلِ الْقُرْآنَ تَرْتِيلًا", "Veya buna biraz ekle ve Kur'an'ı ağır ağır, tane tane oku.", "Oder füge etwas hinzu, und trage den Koran mit deutlicher Stimme vor.", "Or add to it, and recite the Qur'an with measured recitation."],
  [73, 8, "وَاذْكُرِ اسْمَ رَبِّكَ وَتَبَتَّلْ إِلَيْهِ تَبْتِيلًا", "Rabbinin ismini zikret ve bütün varlığınla yalnız O'na yönel.", "Und gedenke des Namens deines Herrn und widme dich Ihm ganz und gar.", "And remember the name of your Lord and devote yourself to Him with [complete] devotion."],
  [73, 20, "وَمَا تُقَدِّمُوا لِأَنفُسِكُم مِّنْ خَيْرٍ تَجِدُوهُ عِندَ اللَّهِ هُوَ خَيْرًا وَأَعْظَمَ أَجْرًا ۚ وَاسْتَغْفِرُوا اللَّهَ", "Kendiniz için önceden ne hayır takdim ederseniz, onu Allah katında daha hayırlı ve daha büyük bir mükâfat olarak bulursunuz. Allah'tan af dileyin.", "Und was ihr für eure Seelen an Gutem vorausschickt, das werdet ihr bei Allah finden, als besser und mit größerem Lohn.", "And whatever good you put forward for yourselves - you will find it with Allah. It is better and greater in reward. And seek forgiveness of Allah."],

  // 141-150
  [76, 8, "وَيُطْعِمُونَ الطَّعَامَ عَلَىٰ حُبِّهِ مِسْكِينًا وَيَتِيمًا وَأَسِيرًا ۝ إِنَّمَا نُطْعِمُكُمْ لِوَجْهِ اللَّهِ لَا نُرِيدُ مِنكُمْ جَزَاءً وَلَا شُكُورًا", "Onlar sevdikleri yiyecekten yoksula, yetime ve esire yedirirler: 'Biz sizi sadece Allah rızası için doyuruyoruz; sizden ne bir karşılık ne de bir teşekkür bekleriz.'", "Und sie geben Speise aus Liebe zu Ihm dem Armen, der Waise und dem Gefangenen: 'Wir speisen euch nur um Allahs Angesicht willen.'", "And they give food in spite of love for it to the needy, the orphan, and the captive, [saying], 'We feed you only for the countenance of Allah.'"],
  [76, 25, "وَاذْكُرِ اسْمَ رَبِّكَ بُكْرَةً وَأَصِيلًا ۝ وَمِنَ اللَّيْلِ فَاسْجُدْ لَهُ وَسَبِّحْهُ لَيْلًا طَوِيلًا", "Sabah akşam Rabbinin adını an. Gecenin bir kısmında da O'na secde et ve geceleyin uzun süre O'nu tesbih et.", "Und gedenke des Namens deines Herrn morgens und abends. Und in der Nacht wirf dich vor Ihm nieder.", "And mention the name of your Lord [in prayer] morning and evening. And during the night prostrate to Him and exalt Him a long night."],
  [79, 40, "وَأَمَّا مَنْ خَافَ مَقَامَ رَبِّهِ وَنَهَى النَّفْسَ عَنِ الْهَوَىٰ ۝ فَإِنَّ الْجَنَّةَ هِيَ الْمَأْوَىٰ", "Rabbinin huzurunda durmaktan korkan ve nefsini kötü arzulardan alıkoyan kimseye gelince, şüphesiz cennet onun barınağıdır.", "Wer aber das Stehen vor seinem Herrn gefürchtet und der Seele die bösen Begierden verwehrt hat, gewiss, das Paradies ist der Zufluchtsort.", "But as for he who feared the position of his Lord and prevented the soul from [unlawful] inclination, then indeed, Paradise will be [his] refuge."],
  [82, 6, "يَا أَيُّهَا الْإِنسَانُ مَا غَرَّكَ بِرَبِّكَ الْكَرِيمِ", "Ey insan! Çok cömert olan Rabbine karşı seni aldatan ne oldu?", "O Mensch, was hat dich über deinen edelmütigen Herrn getäuscht?", "O mankind, what has deceived you concerning your Lord, the Generous?"],
  [84, 6, "يَا أَيُّهَا الْإِنسَانُ إِنَّكَ كَادِحٌ إِلَىٰ رَبِّكَ كَدْحًا فَمُلَاقِيهِ", "Ey insan! Şüphesiz sen Rabbine doğru büyük bir çabayla çabalayıp durmaktasın ve nihayet O'na kavuşacaksın.", "O Mensch, du mühst dich hart ab zu deinem Herrn hin, und so wirst du Ihm begegnen.", "O mankind, indeed you are laboring toward your Lord with [great] exertion and will meet Him."],
  [85, 14, "وَهُوَ الْغَفُورُ الْوَدُودُ ۝ ذُو الْعَرْشِ الْمَجِيدُ", "O çok bağışlayandır, çok sevendir; Arş'ın sahibi ve pek yüce olandır.", "Und Er ist der Allvergebende, der Liebevolle, der Herr des glorreichen Thrones.", "And He is the Forgiving, the Affectionate, Honorable Owner of the Throne."],
  [87, 1, "سَبِّحِ اسْمَ رَبِّكَ الْأَعْلَى", "Yüceler yücesi Rabbinin adını tesbih et.", "Preise den Namen deines allerhöchsten Herrn.", "Exalt the name of your Lord, the Most High."],
  [87, 14, "قَدْ أَفْلَحَ مَن تَزَكَّىٰ ۝ وَذَكَرَ اسْمَ رَبِّهِ فَصَلَّىٰ", "Temizlenip arınan, Rabbinin adını anıp namaz kılan kesinlikle kurtulmuştur.", "Wohl ergehen wird es gewiss dem, der sich läutert und des Namens seines Herrn gedenkt und betet.", "He has certainly succeeded who purifies himself and mentions the name of his Lord and prays."],
  [89, 27, "يَا أَيَّتُهَا النَّفْسُ الْمُطْمَئِنَّةُ ۝ ارْجِعِي إِلَىٰ رَبِّكِ رَاضِيَةً مَّرْضِيَّةً ۝ فَادْخُلِي فِي عِبَادِي ۝ وَادْخُلِي جَنَّتِي", "Ey huzura kavuşmuş nefis! Sen O'ndan razı, O da senden razı olarak Rabbine dön! Gir kullarımın arasına ve gir cennetime!", "O du beruhigte Seele, kehre zu deinem Herrn zufrieden und wohlgefällig zurück! Tritt ein in Meine Dienerschaft und tritt ein in Meinen Garten!", "O reassured soul, return to your Lord, well-pleased and pleasing [to Him], and enter among My [righteous] servants and enter My Paradise!"],
  [90, 17, "ثُمَّ كَانَ مِنَ الَّذِينَ آمَنُوا وَتَوَاصَوْا بِالصَّبْرِ وَتَوَاصَوْا بِالْمَرْحَمَةِ", "Sonra iman edenlerden olup birbirine sabrı ve merhameti tavsiye edenlerden olmaktır.", "Dann zu denen gehören, die glauben und einander zur Geduld und Barmherzigkeit ermahnen.", "And then being among those who believed and advised one another to patience and advised one another to compassion."],

  // 151-160
  [91, 9, "قَدْ أَفْلَحَ مَن زَكَّاهَا ۝ وَقَدْ خَابَ مَن دَسَّاهَا", "Nefsini kötülüklerden arındıran kurtulmuştur; onu günahlarla örten ise hüsrana uğramıştır.", "Wohl ergehen wird es dem, der sie läutert; verloren aber hat, wer sie verkommen lässt.", "He has succeeded who purifies it, and he has failed who instills it [with corruption]."],
  [92, 5, "فَأَمَّا مَنْ أَعْطَىٰ وَاتَّقَىٰ ۝ وَصَدَّقَ بِالْحُسْنَىٰ ۝ فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ", "Kim verir ve takva sahibi olur ve en güzel olanı doğrularsa, biz ona kolay olanı kolaylaştırırız.", "Was nun jemanden angeht, der gibt und gottesfürchtig ist und das Beste für wahr hält, dem werden Wir den Weg zur Leichtigkeit bahnen.", "As for he who gives and fears Allah and believes in the best [reward], We will ease him toward ease."],
  [93, 3, "مَا وَدَّعَكَ رَبُّكَ وَمَا قَلَىٰ ۝ وَلَلْآخِرَةُ خَيْرٌ لَّكَ مِنَ الْأُولَىٰ ۝ وَلَسَوْفَ يُعْطِيكَ رَبُّكَ فَتَرْضَىٰ", "Rabbin seni terk etmedi ve sana darılmadı. Ahiret senin için dünyadan daha hayırlıdır. Ve Rabbin sana verecek, sen de hoşnut olacaksın.", "Dein Herr hat dich weder verlassen noch verabscheut. Das Jenseits ist besser für dich als das Diesseits. Dein Herr wird dir geben, und du wirst zufrieden sein.", "Your Lord has not taken leave of you, nor has He detested [you]. And the Hereafter is better for you than the first [life]. And your Lord is going to give you, and you will be satisfied."],
  [93, 11, "وَأَمَّا بِنِعْمَةِ رَبِّكَ فَحَدِّثْ", "Rabbinin nimetine gelince; işte onu minnetle an!", "Und was die Gnade deines Herrn angeht, so erzähle davon.", "And as for the favor of your Lord, report [it]."],
  [94, 1, "أَلَمْ نَشْرَحْ لَكَ صَدْرَكَ ۝ وَوَضَعْنَا عَنكَ وِزْرَكَ", "Senin göğsünü açıp genişletmedik mi? Belini büken ağır yükünü üzerinden indirmedik mi?", "Haben Wir dir nicht deine Brust geweitet und dir deine Last abgenommen?", "Did We not expand for you, [O Muhammad], your breast? And We removed from you your burden."],
  [94, 5, "فَإِنَّ مَعَ الْعُسْرِ يُسْرًا ۝ إِنَّ مَعَ الْعُسْرِ يُسْرًا", "Şüphesiz güçlükle beraber bir kolaylık vardır. Gerçekten güçlükle beraber bir kolaylık vardır.", "Gewiss, mit der Erschwernis kommt Erleichterung. Gewiss, mit der Erschwernis kommt Erleichterung.", "For indeed, with hardship [will be] ease. Indeed, with hardship [will be] ease."],
  [94, 7, "فَإِذَا فَرَغْتَ فَانصَبْ ۝ وَإِلَىٰ رَبِّكَ فَارْغَب", "Öyleyse bir işi bitirince diğerine koyul ve yalnız Rabbine yönel.", "Wenn du nun fertig bist, dann strenge dich an und nach deinem Herrn strebe.", "So when you have finished [your duties], then stand up [for worship]. And to your Lord direct [your] longing."],
  [95, 4, "لَقَدْ خَلَقْنَا الْإِنسَانَ فِي أَحْسَنِ تَقْوِيمٍ", "Doğrusu biz insanı en güzel biçimde yarattık.", "Wir haben den Menschen ja in bester Gestalt erschaffen.", "We have certainly created man in the best of stature."],
  [96, 1, "اقْرَأْ بِاسْمِ رَبِّكَ الَّذِي خَلَقَ ۝ خَلَقَ الْإِنسَانَ مِنْ عَلَقٍ ۝ اقْرَأْ وَرَبُّكَ الْأَكْرَمُ", "Yaratan Rabbinin adıyla oku! O, insanı bir aşılanmış yumurtadan yarattı. Oku! Rabbin sonsuz kerem sahibidir.", "Lies im Namen deines Herrn, Der erschaffen hat. Erschaffen hat den Menschen aus einem Anhängsel. Lies, denn dein Herr ist der Edelste.", "Recite in the name of your Lord who created - Created man from a clinging substance. Recite, and your Lord is the most Generous."],
  [96, 19, "كَلَّا لَا تُطِعْهُ وَاسْجُدْ وَاقْتَرِب", "Hayır! Ona boyun eğme; secde et ve Rabbine yaklaş!", "Keineswegs! Gehorche ihm nicht, sondern wirf dich nieder und nähere dich.", "No! Do not obey him. But prostrate and draw near [to Allah]."],

  // 161-170
  [97, 1, "إِنَّا أَنزَلْنَاهُ فِي لَيْلَةِ الْقَدْرِ ۝ وَمَا أَدْرَاكَ مَا لَيْلَةُ الْقَدْرِ ۝ لَيْلَةُ الْقَدْرِ خَيْرٌ مِّنْ أَلْفِ شَهْرٍ", "Şüphesiz biz onu Kadir gecesinde indirdik. Kadir gecesinin ne olduğunu sen bilir misin? Kadir gecesi bin aydan daha hayırlıdır.", "Wir haben ihn in der Nacht der Bestimmung herabgesandt. Was weißt du, was die Nacht der Bestimmung ist? Die Nacht der Bestimmung ist besser als tausend Monate.", "Indeed, We sent the Qur'an down during the Night of Decree. And what can make you know what is the Night of Decree? The Night of Decree is better than a thousand months."],
  [97, 4, "تَنَزَّلُ الْمَلَائِكَةُ وَالرُّوحُ فِيهَا بِإِذْنِ رَبِّهِم مِّن كُلِّ أَمْرٍ ۝ سَلَامٌ هِيَ حَتَّىٰ مَطْلَعِ الْفَجْرِ", "Melekler ve Ruh onda Rablerinin izniyle her bir iş için iner dururlar. O gece fecrin doğuşuna kadar bir esenliktir.", "Es kommen die Engel und der Geist in ihr herab mit der Erlaubnis ihres Herrn zu jeder Angelegenheit. Frieden ist sie bis zum Anbruch der Morgendämmerung.", "The angels and the Spirit descend therein by permission of their Lord for every matter. Peace it is until the emergence of dawn."],
  [98, 5, "وَمَا أُمِرُوا إِلَّا لِيَعْبُدُوا اللَّهَ مُخْلِصِينَ لَهُ الدِّينَ حُنَفَاءَ وَيُقِيمُوا الصَّلَاةَ وَيُؤْتُوا الزَّكَاةَ ۚ وَذَٰلِكَ دِينُ الْقَيِّمَةِ", "Halbuki onlara ancak dini yalnız Allah'a has kılarak, hakka yönelmiş kimseler olarak O'na kulluk etmeleri, namazı kılmaları ve zekâtı vermeleri emrolunmuştu.", "Und ihnen wurde nichts anderes befohlen, als nur Allah zu dienen und Ihm den Glauben aufrichtig zu weihen, das Gebet zu verrichten und die Zakat zu entrichten.", "And they were not commanded except to worship Allah, [being] sincere to Him in religion, inclining to truth, and to establish prayer and to give zakah."],
  [99, 7, "فَمَن يَعْمَلْ مِثْقَالَ ذَرَّةٍ خَيْرًا يَرَهُ ۝ وَمَن يَعْمَلْ مِثْقَالَ ذَرَّةٍ شَرًّا يَرَهُ", "Kim zerre miktarı hayır işlerse onu görür. Kim de zerre miktarı şer işlerse onu görür.", "Wer nun im Gewicht eines Stäubchens Gutes tut, wird es sehen. Und wer im Gewicht eines Stäubchens Böses tut, wird es sehen.", "So whoever does an atom's weight of good will see it, and whoever does an atom's weight of evil will see it."],
  [103, 1, "وَالْعَصْرِ ۝ إِنَّ الْإِنسَانَ لَفِي خُسْرٍ ۝ إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ", "Asra yemin olsun ki insan kesinlikle hüsrandadır. Ancak iman edip salih amel işleyenler, birbirine hakkı ve sabrı tavsiye edenler müstesna.", "Beim Nachmittag! Der Mensch befindet sich wahrlich in Verlust, außer denjenigen, die glauben und rechtschaffene Werke tun und einander die Wahrheit und Geduld ans Herz legen.", "By time, indeed, mankind is in loss, except for those who have believed and done righteous deeds and advised each other to truth and advised each other to patience."],
  [106, 3, "فَلْيَعْبُدُوا رَبَّ هَٰذَا الْبَيْتِ ۝ الَّذِي أَطْعَمَهُم مِّن جُوعٍ وَآمَنَهُم مِّنْ خَوْفٍ", "Öyleyse bu Beyt'in (Kâbe'nin) Rabbine kulluk etsinler; O ki onları açlıktan doyurmuş ve korkudan emin kılmıştır.", "So sollen sie dem Herrn dieses Hauses dienen, Der sie vor Hunger gespeist und vor Furcht gesichert hat.", "Let them worship the Lord of this House, who has fed them, [saving them] from hunger and made them safe, [saving them] from fear."],
  [108, 1, "إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ ۝ فَصَلِّ لِرَبِّكَ وَانْحَرْ", "Şüphesiz biz sana Kevser'i verdik. Öyleyse Rabbin için namaz kıl ve kurban kes.", "Gewiss, Wir haben dir die Fülle des Guten gegeben. So bete zu deinem Herrn und schlachte.", "Indeed, We have granted you, [O Muhammad], al-Kawthar. So pray to your Lord and sacrifice."],
  [109, 1, "قُلْ يَا أَيُّهَا الْكَافِرُونَ ۝ لَا أَعْبُدُ مَا تَعْبُدُونَ ۝ لَكُمْ دِينُكُمْ وَلِيَ دِينِ", "De ki: Ey inkârcılar! Ben sizin taptıklarınıza tapmam. Sizin dininiz size, benim dinim banadır.", "Sprich: O ihr Ungläubigen! Ich diene nicht dem, dem ihr dient. Euch eure Religion und mir meine Religion.", "Say, 'O disbelievers, I do not worship what you worship. For you is your religion, and for me is my religion.'"],
  [110, 1, "إِذَا جَاءَ نَصْرُ اللَّهِ وَالْفَتْحُ ۝ وَرَأَيْتَ النَّاسَ يَدْخُلُونَ فِي دِينِ اللَّهِ أَفْوَاجًا ۝ فَسَبِّحْ بِحَمْدِ رَبِّكَ وَاسْتَغْفِرْهُ", "Allah'ın yardımı ve fetih geldiğinde ve insanların dalga dalga Allah'ın dinine girdiğini gördüğünde, Rabbini hamd ile tesbih et ve O'ndan mağfiret dile.", "Wenn die Hilfe Allahs kommt und der Sieg, und du die Menschen in Scharen in Allahs Religion eintreten siehst, dann lobpreise deinen Herrn und bitte Ihn um Vergebung.", "When the victory of Allah has come and the conquest, and you see the people entering into the religion of Allah in multitudes, then exalt [Him] with praise of your Lord and ask forgiveness of Him."],
  [112, 1, "قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ", "De ki: O Allah tektir. Allah Samed'dir (her şey O'na muhtaç, O hiçbir şeye muhtaç değildir). Doğurmamış ve doğmamıştır. Hiçbir şey O'na denk değildir.", "Sprich: Er ist Allah, ein Einer, Allah, der Überlegene. Er zeugt nicht und ist nicht gezeugt worden, und niemand ist Ihm jemals gleich.", "Say, 'He is Allah, [who is] One, Allah, the Eternal Refuge. He neither begets nor is born, nor is there to Him any equivalent.'"],

  // 171-180
  [113, 1, "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ۝ مِن شَرِّ مَا خَلَقَ ۝ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ ۝ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ۝ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ", "De ki: Sabahın Rabbine sığınırım; yarattığı şeylerin şerrinden, karanlığı çöktüğü zaman gecenin şerrinden, düğümlere üfleyenlerin şerrinden ve haset ettiği zaman hasetçinin şerrinden.", "Sprich: Ich nehme Zuflucht beim Herrn des Frühlichts vor dem Übel dessen, was Er erschaffen hat, und vor dem Übel der Dunkelheit, wenn sie hereinbricht.", "Say, 'I seek refuge in the Lord of daybreak from the evil of that which He created and from the evil of darkness when it settles.'"],
  [114, 1, "قُلْ أَعُوذُ بِرَبِّ النَّاسِ ۝ مَلِكِ النَّاسِ ۝ إِلَٰهِ النَّاسِ ۝ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ۝ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ۝ مِنَ الْجِنَّةِ وَالنَّاسِ", "De ki: İnsanların Rabbine, insanların Melikine, insanların İlahına sığınırım; sinsi vesvesecinin şerrinden. O ki insanların göğüslerine vesvese verir; gerek cinlerden gerek insanlardan.", "Sprich: Ich nehme Zuflucht beim Herrn der Menschen, dem König der Menschen, dem Gott der Menschen, vor dem Übel des Einflüsterers, der weicht.", "Say, 'I seek refuge in the Lord of mankind, the Sovereign of mankind, the God of mankind, from the evil of the retreating whisperer.'"],
  [2, 177, "لَّيْسَ الْبِرَّ أَن تُوَلُّوا وُجُوهَكُمْ قِبَلَ الْمَشْرِقِ وَالْمَغْرِبِ وَلَٰكِنَّ الْبِرَّ مَنْ آمَنَ بِاللَّهِ وَالْيَوْمِ الْآخِرِ", "İyilik, yüzlerinizi doğu ve batı tarafına çevirmeniz değildir. Asıl iyilik, Allah'a, ahiret gününe, meleklere, kitaba ve peygamberlere inananın iyiliğidir.", "Güte ist nicht, dass ihr eure Gesichter nach Osten oder Westen wendet. Güte ist vielmehr, dass man an Allah und den Jüngsten Tag glaubt.", "Righteousness is not that you turn your faces toward the east or the west, but [true] righteousness is [in] one who believes in Allah, the Last Day."],
  [2, 195, "وَأَنفِقُوا فِي سَبِيلِ اللَّهِ وَلَا تُلْقُوا بِأَيْدِيكُمْ إِلَى التَّهْلُكَةِ ۛ وَأَحْسِنُوا ۛ إِنَّ اللَّهَ يُحِبُّ الْمُحْسِنِينَ", "Allah yolunda harcayın ve kendi ellerinizle kendinizi tehlikeye atmayın. İyilik edin; şüphesiz Allah iyilik edenleri sever.", "Und gebt auf Allahs Weg aus und stürzt euch nicht mit eigenen Händen ins Verderben. Tut Gutes! Gewiss, Allah liebt die Gutes Tuenden.", "And spend in the way of Allah and do not throw [yourselves] with your [own] hands into destruction. And do good; indeed, Allah loves the doers of good."],
  [3, 17, "الصَّابِرِينَ وَالصَّادِقِينَ وَالْقَانِتِينَ وَالْمُنفِقِينَ وَالْمُسْتَغْفِرِينَ بِالْأَسْحَارِ", "Onlar sabredenler, doğru olanlar, gönülden boyun eğenler, infak edenler ve seher vakitlerinde bağışlanma dileyenlerdir.", "Die Geduldigen und die Wahrhaftigen, die Demütigen und diejenigen, die ausgeben, und die im Morgengrauen um Vergebung Flehenden.", "The patient, the true, the obedient, those who spend [in the way of Allah], and those who seek forgiveness before dawn."],
  [3, 102, "يَا أَيُّهَا الَّذِينَ آمَنُوا اتَّقُوا اللَّهَ حَقَّ تُقَاتِهِ وَلَا تَمُوتُنَّ إِلَّا وَأَنتُم مُّسْلِمُونَ", "Ey iman edenler! Allah'tan, O'na yaraşır şekilde korkun ve ancak müslümanlar olarak can verin.", "O die ihr glaubt, fürchtet Allah in gebührender Furcht und sterbt ja nicht anders denn als Muslime.", "O you who have believed, fear Allah as He should be feared and do not die except as Muslims."],
  [3, 110, "كُنتُمْ خَيْرَ أُمَّةٍ أُخْرِجَتْ لِلنَّاسِ تَأْمُرُونَ بِالْمَعْرُوفِ وَتَنْهَوْنَ عَنِ الْمُنكَرِ وَتُؤْمِنُونَ بِاللَّهِ", "Siz, insanların iyiliği için çıkarılmış en hayırlı ümmetsiniz; iyiliği emreder, kötülükten meneder ve Allah'a inanırsınız.", "Ihr seid die beste Gemeinschaft, die für die Menschen hervorgebracht worden ist: Ihr gebietet das Gute und verbietet das Verwerfliche.", "You are the best nation produced [as an example] for mankind. You enjoin what is right and forbid what is wrong and believe in Allah."],
  [4, 114, "لَّا خَيْرَ فِي كَثِيرٍ مِّن نَّجْوَاهُمْ إِلَّا مَنْ أَمَرَ بِصَدَقَةٍ أَوْ مَعْرُوفٍ أَوْ إِصْلَاحٍ بَيْنَ النَّاسِ", "Onların gizli konuşmalarının çoğunda hayır yoktur; ancak bir sadaka vermeyi, bir iyilik yapmayı yahut insanların arasını düzeltmeyi isteyeninki müstesna.", "Es ist nichts Gutes in vielen ihrer geheimen Gespräche, außer wer eine Spende gebietet oder Güte oder Aussöhnung unter den Menschen.", "No good is there in much of their private conversation, except for those who enjoin charity or that which is right or conciliation between people."],
  [6, 160, "مَن جَاءَ بِالْحَسَنَةِ فَلَهُ عَشْرُ أَمْثَالِهَا ۖ وَمَن جَاءَ بِالسَّيِّئَةِ فَلَا يُجْزَىٰ إِلَّا مِثْلَهَا", "Kim bir iyilikle gelirse ona bunun on katı verilir; kim de bir kötülükle gelirse sadece onun misliyle cezalandırılır.", "Wer mit einer guten Tat kommt, erhält das Zehnfache; wer aber mit einer bösen Tat kommt, dem wird nur deren Gleiches vergolten.", "Whoever comes [on the Day of Judgement] with a good deed will have ten times the like thereof [to his credit], and whoever comes with an evil deed will not be recompensed except the like."],
  [7, 156, "وَرَحْمَتِي وَسِعَتْ كُلَّ شَيْءٍ", "Rahmetim ise her şeyi kuşatmıştır.", "Meine Barmherzigkeit umfasst alle Dinge.", "And My mercy encompasses all things."],

  // 181-190
  [12, 18, "فَصَبْرٌ جَمِيلٌ ۖ وَاللَّهُ الْمُسْتَعَانُ عَلَىٰ مَا تَصِفُونَ", "Artık bana düşen güzel bir sabırdır. Sizin anlattıklarınıza karşı yardımı istenecek olan ancak Allah'tır.", "So ziemt mir schöne Geduld. Und Allah ist derjenige, dessen Hilfe gegen das erbeten wird, was ihr beschreibt.", "So patience is most fitting. And Allah is the one sought for help against that which you describe."],
  [13, 22, "وَالَّذِينَ صَبَرُوا ابْتِغَاءَ وَجْهِ رَبِّهِمْ وَأَقَامُوا الصَّلَاةَ وَأَنفَقُوا مِمَّا رَزَقْنَاهُمْ سِرًّا وَعَلَانِيَةً", "Onlar Rablerinin rızasını dileyerek sabrederler, namazı kılarlar, kendilerine verdiğimiz rızıktan gizli ve açık infak ederler.", "Und diejenigen, die geduldig sind im Trachten nach dem Angesicht ihres Herrn, das Gebet verrichten und spenden.", "And those who are patient, seeking the countenance of their Lord, and establish prayer and spend from what We have provided them."],
  [16, 30, "لِّلَّذِينَ أَحْسَنُوا فِي هَٰذِهِ الدُّنْيَا حَسَنَةٌ ۚ وَلَدَارُ الْآخِرَةِ خَيْرٌ", "Bu dünyada iyilik edenlere bir iyilik vardır; ahiret yurdu ise elbette daha hayırlıdır.", "Für diejenigen, die Gutes tun, gibt es in dieser Welt Gutes. Aber die jenseitige Wohnstätte ist wahrlich besser.", "For those who do good in this world is good; and the home of the Hereafter is better."],
  [17, 37, "وَلَا تَمْشِ فِي الْأَرْضِ مَرَحًا ۖ إِنَّكَ لَن تَخْرِقَ الْأَرْضَ وَلَن تَبْلُغَ الْجِبَالَ طُولًا", "Yeryüzünde böbürlenerek yürüme; zira sen ne yeri yarabilirsin ne de boyca dağlara ulaşabilirsin.", "Und wandle nicht übermütig auf der Erde umher. Du wirst die Erde nicht spalten und die Berge nicht an Höhe erreichen.", "And do not walk upon the earth exultantly. Indeed, you will never tear the earth [apart], and you will never reach the mountains in height."],
  [17, 53, "وَقُل لِّعِبَادِي يَقُولُوا الَّتِي هِيَ أَحْسَنُ ۚ إِنَّ الشَّيْطَانَ يَنزَغُ بَيْنَهُمْ", "Kullarıma söyle: En güzel sözü söylesinler. Çünkü şeytan aralarını açıp bozmak ister.", "Und sage Meinen Dienern, sie sollen das sagen, was am besten ist. Gewiss, der Satan stiftet Zwietracht.", "And tell My servants to say that which is best. Indeed, Satan induces [dissension] among them."],
  [18, 28, "وَاصْبِرْ نَفْسَكَ مَعَ الَّذِينَ يَدْعُونَ رَبَّهُم بِالْغَدَاةِ وَالْعَشِيِّ يُرِيدُونَ وَجْهَهُ", "Sabah akşam Rablerinin rızasını dileyerek O'na dua edenlerle beraber nefsini sabırlı tut.", "Und gedulde dich zusammen mit denjenigen, die ihren Herrn morgens und abends anrufen im Trachten nach Seinem Wohlgefallen.", "And keep yourself patient [by being] with those who call upon their Lord in the morning and the evening, seeking His countenance."],
  [21, 89, "رَبِّ لَا تَذَرْنِي فَرْدًا وَأَنتَ خَيْرُ الْوَارِثِينَ", "Rabbim! Beni tek başıma bırakma; sen varislerin en hayırlısısın.", "Mein Herr, lass mich nicht kinderlos bleiben. Und Du bist der Beste der Erben.", "My Lord, do not leave me alone [with no heir], while You are the best of inheritors."],
  [25, 65, "رَبَّنَا اصْرِفْ عَنَّا عَذَابَ جَهَنَّمَ ۖ إِنَّ عَذَابَهَا كَانَ غَرَامًا", "Rabbimiz! Cehennem azabını bizden sav; şüphesiz onun azabı helak edicidir.", "Unser Herr, wende von uns die Strafe der Hölle ab. Gewiss, ihre Strafe ist eine bedrückende Pein.", "Our Lord, avert from us the punishment of Hell. Indeed, its punishment is ever adhering."],
  [26, 83, "رَبِّ هَبْ لِي حُكْمًا وَأَلْحِقْنِي بِالصَّالِحِينَ ۝ وَاجْعَل لِّي لِسَانَ صِدْقٍ فِي الْآخِرِينَ", "Rabbim! Bana bir hikmet bahşet ve beni salihler arasına kat. Sonradan gelecekler arasında benim hayırla anılmamı nasip eyle.", "Mein Herr, schenke mir Weisheit und füge mich den Rechtschaffenen hinzu. Und verleihe mir einen guten Ruf unter den Späteren.", "My Lord, grant me authority and join me with the righteous. And grant me a reputation of honor among later generations."],
  [28, 24, "رَبِّ إِنِّي لِمَا أَنزَلْتَ إِلَيَّ مِنْ خَيْرٍ فَقِيرٌ", "Rabbim! Doğrusu bana indireceğin her hayra muhtacım.", "Mein Herr, ich bin dessen bedürftig, was Du an Gutem zu mir herabsendest.", "My Lord, indeed I am, for whatever good You would send down to me, in need."],

  // 191-200
  [30, 17, "فَسُبْحَانَ اللَّهِ حِينَ تُمْسُونَ وَحِينَ تُصْبِحُونَ ۝ وَلَهُ الْحَمْدُ فِي السَّمَاوَاتِ وَالْأَرْضِ وَعَشِيًّا وَحِينَ تُظْهِرُونَ", "Öyleyse akşama girdiğinizde ve sabaha erdiğinizde Allah'ı tesbih edin. Göklerde ve yerde, ikindide ve öğleye erdiğinizde hamd O'na mahsustur.", "So preist Allah, wenn ihr den Abend und wenn ihr den Morgen erreicht. Und Ihm gehört alles Lob in den Himmeln und auf der Erde.", "So exalted is Allah when you reach the evening and when you reach the morning. And to Him is [due all] praise throughout the heavens and the earth."],
  [32, 16, "تَتَجَافَىٰ جُنُوبُهُمْ عَنِ الْمَضَاجِعِ يَدْعُونَ رَبَّهُمْ خَوْفًا وَطَمَعًا وَمِمَّا رَزَقْنَاهُمْ يُنفِقُونَ", "Yanları yataklardan uzaklaşır; korku ve ümit içinde Rablerine dua ederler ve kendilerine rızık olarak verdiklerimizden infak ederler.", "Ihre Seiten weichen vor den Schlafstätten zurück; sie rufen ihren Herrn in Furcht und Hoffnung an und spenden.", "They arise from [their] beds; they supplicate their Lord in fear and aspiration, and from what We have provided them, they spend."],
  [33, 70, "يَا أَيُّهَا الَّذِينَ آمَنُوا اتَّقُوا اللَّهَ وَقُولُوا قَوْلًا سَدِيدًا ۝ يُصْلِحْ لَكُمْ أَعْمَالَكُمْ وَيَغْفِرْ لَكُمْ ذُنُوبَكُمْ", "Ey iman edenler! Allah'tan korkun ve doğru söz söyleyin ki Allah işlerinizi düzeltsin ve günahlarınızı bağışlasın.", "O die ihr glaubt, fürchtet Allah und sprecht treffende Worte, so wird Er eure Werke bessern und eure Sünden vergeben.", "O you who have believed, fear Allah and speak words of appropriate justice. He will [then] amend for you your deeds and forgive you your sins."],
  [39, 23, "اللَّهُ نَزَّلَ أَحْسَنَ الْحَدِيثِ كِتَابًا مُّتَشَابِهًا مَّثَانِيَ تَقْشَعِرُّ مِنْهُ جُلُودُ الَّذِينَ يَخْشَوْنَ رَبَّهُمْ", "Allah sözün en güzelini, ahenkli ve tekrar eden bir kitap olarak indirmiştir. Rablerinden korkanların tüyleri ondan ürperir.", "Allah hat die schönste Botschaft herabgesandt, ein Buch mit gleichartigen, sich wiederholenden Versen.", "Allah has sent down the best statement: a consistent Book wherein is reiteration. The skins shiver therefrom of those who fear their Lord."],
  [40, 64, "اللَّهُ الَّذِي جَعَلَ لَكُمُ الْأَرْضَ قَرَارًا وَالسَّمَاءَ بِنَاءً وَصَوَّرَكُمْ فَأَحْسَنَ صُوَرَكُمْ وَرَزَقَكُم مِّنَ الطَّيِّبَاتِ", "Allah, yeryüzünü sizin için bir yerleşme yeri, göğü bir bina kılan, size şekil verip şeklinizi en güzel yapan ve sizi temiz şeylerle rızıklandırandır.", "Allah ist es, Der euch die Erde zu einer Ruhestätte und den Himmel zu einem Bau gemacht und euch Gestalt gegeben hat.", "It is Allah who made for you the earth a place of settlement and the sky a ceiling and formed you and perfected your forms and provided you with good things."],
  [43, 13, "سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَٰذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ ۝ وَإِنَّا إِلَىٰ رَبِّنَا لَمُنقَلِبُونَ", "Bunu bizim hizmetimize veren Allah her türlü eksiklikten münezzehtir; yoksa bizim buna gücümüz yetmezdi. Ve şüphesiz biz Rabbimize döneceğiz.", "Preis sei Dem, Der uns dies dienstbar gemacht hat! Wir hätten es sonst nicht vermocht. Und wir werden zu unserem Herrn zurückkehren.", "Exalted is He who has subjected this to us, and we could not have [otherwise] subdued it. And indeed we, to our Lord, will return."],
  [50, 39, "فَاصْبِرْ عَلَىٰ مَا يَقُولُونَ وَسَبِّحْ بِحَمْدِ رَبِّكَ قَبْلَ طُلُوعِ الشَّمْسِ وَقَبْلَ الْغُرُوبِ ۝ وَمِنَ اللَّيْلِ فَسَبِّحْهُ وَأَدْبَارَ السُّجُودِ", "Onların dediklerine sabret ve güneş doğmadan önce de batmadan önce de Rabbini hamd ile tesbih et; gecenin bir kısmında ve secdelerin ardından da O'nu tesbih et.", "So ertrage geduldig, was sie sagen, und preise deinen Herrn vor dem Aufgang der Sonne und vor dem Untergang.", "So be patient over what they say and exalt [Allah] with praise of your Lord before the rising of the sun and before its setting, and in the night exalt Him and after prostration."],
  [57, 3, "هُوَ الْأَوَّلُ وَالْآخِرُ وَالظَّاهِرُ وَالْبَاطِنُ ۖ وَهُوَ بِكُلِّ شَيْءٍ عَلِيمٌ", "O Evvel'dir, Âhir'dir, Zâhir'dir, Bâtın'dır. O her şeyi hakkıyla bilendir.", "Er ist der Erste und der Letzte, der Offenbare und der Verborgene; und Er weiß über alles Bescheid.", "He is the First and the Last, the Ascendant and the Intimate, and He is, of all things, Knowing."],
  [64, 13, "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ ۚ وَعَلَى اللَّهِ فَلْيَتَوَكَّلِ الْمُؤْمِنُونَ", "Allah, O'ndan başka ilah yoktur. Öyleyse müminler yalnız Allah'a tevekkül etsinler.", "Allah – es gibt keinen Gott außer Ihm. Und auf Allah sollen die Gläubigen vertrauen.", "Allah - there is no deity except Him. And upon Allah let the believers rely."],
  [68, 51, "وَإِن يَكَادُ الَّذِينَ كَفَرُوا لَيُزْلِقُونَكَ بِأَبْصَارِهِمْ لَمَّا سَمِعُوا الذِّكْرَ وَيَقُولُونَ إِنَّهُ لَمَجْنُونٌ ۝ وَمَا هُوَ إِلَّا ذِكْرٌ لِّلْعَالَمِينَ", "Doğrusu inkâr edenler Zikr'i (Kur'an'ı) işittikleri zaman seni neredeyse gözleriyle yıkacaklardı: 'O bir delidir' diyorlardı. Halbuki o âlemler için bir öğüttür.", "Und diejenigen, die ungläubig sind, möchten dich mit ihren Blicken zu Fall bringen, wenn sie die Ermahnung hören.", "And indeed, those who disbelieve would almost make you slip with their eyes when they hear the message, and they say, 'Indeed, he is mad.' But it is not except a reminder to the worlds."]
];

const surahNamesMap = {
  1: { tr: "Fâtiha Sûresi", ar: "سورة الفاتحة", de: "Sure Al-Fatiha", en: "Surah Al-Fatihah" },
  2: { tr: "Bakara Sûresi", ar: "سورة البقرة", de: "Sure Al-Baqarah", en: "Surah Al-Baqarah" },
  3: { tr: "Âl-i İmrân Sûresi", ar: "سورة آل عمران", de: "Sure Al-Imran", en: "Surah Ali 'Imran" },
  4: { tr: "Nisâ Sûresi", ar: "سورة النساء", de: "Sure An-Nisa", en: "Surah An-Nisa" },
  5: { tr: "Mâide Sûresi", ar: "سورة المائدة", de: "Sure Al-Ma'idah", en: "Surah Al-Ma'idah" },
  6: { tr: "En'âm Sûresi", ar: "سورة الأنعام", de: "Sure Al-An'am", en: "Surah Al-An'am" },
  7: { tr: "A'râf Sûresi", ar: "سورة الأعراف", de: "Sure Al-A'raf", en: "Surah Al-A'raf" },
  8: { tr: "Enfâl Sûresi", ar: "سورة الأنفال", de: "Sure Al-Anfal", en: "Surah Al-Anfal" },
  9: { tr: "Tevbe Sûresi", ar: "سورة التوبة", de: "Sure At-Tawbah", en: "Surah At-Tawbah" },
  10: { tr: "Yûnus Sûresi", ar: "سورة يونس", de: "Sure Yunus", en: "Surah Yunus" },
  11: { tr: "Hûd Sûresi", ar: "سورة هود", de: "Sure Hud", en: "Surah Hud" },
  12: { tr: "Yûsuf Sûresi", ar: "سورة يوسف", de: "Sure Yusuf", en: "Surah Yusuf" },
  13: { tr: "Ra'd Sûresi", ar: "سورة الرعد", de: "Sure Ar-Ra'd", en: "Surah Ar-Ra'd" },
  14: { tr: "İbrâhîm Sûresi", ar: "سورة إبراهيم", de: "Sure Ibrahim", en: "Surah Ibrahim" },
  15: { tr: "Hicr Sûresi", ar: "سورة الحجر", de: "Sure Al-Hijr", en: "Surah Al-Hijr" },
  16: { tr: "Nahl Sûresi", ar: "سورة النحل", de: "Sure An-Nahl", en: "Surah An-Nahl" },
  17: { tr: "İsrâ Sûresi", ar: "سورة الإسراء", de: "Sure Al-Isra", en: "Surah Al-Isra" },
  18: { tr: "Kehf Sûresi", ar: "سورة الكهف", de: "Sure Al-Kahf", en: "Surah Al-Kahf" },
  19: { tr: "Meryem Sûresi", ar: "سورة مريم", de: "Sure Maryam", en: "Surah Maryam" },
  20: { tr: "Tâ-Hâ Sûresi", ar: "سورة طه", de: "Sure Ta-Ha", en: "Surah Ta-Ha" },
  21: { tr: "Enbiyâ Sûresi", ar: "سورة الأنبياء", de: "Sure Al-Anbiya", en: "Surah Al-Anbiya" },
  22: { tr: "Hac Sûresi", ar: "سورة الحج", de: "Sure Al-Hajj", en: "Surah Al-Hajj" },
  23: { tr: "Mü'minûn Sûresi", ar: "سورة المؤمنون", de: "Sure Al-Mu'minun", en: "Surah Al-Mu'minun" },
  24: { tr: "Nûr Sûresi", ar: "سورة النور", de: "Sure An-Nur", en: "Surah An-Nur" },
  25: { tr: "Furkân Sûresi", ar: "سورة الفرقان", de: "Sure Al-Furqan", en: "Surah Al-Furqan" },
  26: { tr: "Şuarâ Sûresi", ar: "سورة الشعراء", de: "Sure Asch-Schu'ara", en: "Surah Ash-Shu'ara" },
  27: { tr: "Neml Sûresi", ar: "سورة النمل", de: "Sure An-Naml", en: "Surah An-Naml" },
  28: { tr: "Kasas Sûresi", ar: "سورة القصص", de: "Sure Al-Qasas", en: "Surah Al-Qasas" },
  29: { tr: "Ankebût Sûresi", ar: "سورة العنكبوت", de: "Sure Al-Ankabut", en: "Surah Al-'Ankabut" },
  30: { tr: "Rûm Sûresi", ar: "سورة الروم", de: "Sure Ar-Rum", en: "Surah Ar-Rum" },
  31: { tr: "Lokmân Sûresi", ar: "سورة لقمان", de: "Sure Luqman", en: "Surah Luqman" },
  32: { tr: "Secde Sûresi", ar: "سورة السجدة", de: "Sure As-Sadschdah", en: "Surah As-Sajdah" },
  33: { tr: "Ahzâb Sûresi", ar: "سورة الأحزاب", de: "Sure Al-Ahzab", en: "Surah Al-Ahzab" },
  34: { tr: "Sebe' Sûresi", ar: "سورة سبأ", de: "Sure Saba", en: "Surah Saba" },
  35: { tr: "Fâtır Sûresi", ar: "سورة فاطر", de: "Sure Fatir", en: "Surah Fatir" },
  36: { tr: "Yâ-Sîn Sûresi", ar: "سورة يس", de: "Sure Ya-Sin", en: "Surah Ya-Sin" },
  37: { tr: "Sâffât Sûresi", ar: "سورة الصافات", de: "Sure As-Saffat", en: "Surah As-Saffat" },
  38: { tr: "Sâd Sûresi", ar: "سورة ص", de: "Sure Sad", en: "Surah Sad" },
  39: { tr: "Zümer Sûresi", ar: "سورة الزمر", de: "Sure Az-Zumar", en: "Surah Az-Zumar" },
  40: { tr: "Mü'min (Gâfir) Sûresi", ar: "سورة غافر", de: "Sure Ghafir", en: "Surah Ghafir" },
  41: { tr: "Fussilet Sûresi", ar: "سورة فصلت", de: "Sure Fussilat", en: "Surah Fussilat" },
  42: { tr: "Şûrâ Sûresi", ar: "سورة الشورى", de: "Sure Asch-Schura", en: "Surah Ash-Shura" },
  43: { tr: "Zuhruf Sûresi", ar: "سورة الزخرف", de: "Sure Az-Zukhruf", en: "Surah Az-Zukhruf" },
  44: { tr: "Duhân Sûresi", ar: "سورة الدخان", de: "Sure Ad-Dukhan", en: "Surah Ad-Dukhan" },
  45: { tr: "Câsiye Sûresi", ar: "سورة الجاثية", de: "Sure Al-Jathiyah", en: "Surah Al-Jathiyah" },
  46: { tr: "Ahkâf Sûresi", ar: "سورة الأحقاف", de: "Sure Al-Ahqaf", en: "Surah Al-Ahqaf" },
  47: { tr: "Muhammed Sûresi", ar: "سورة محمد", de: "Sure Muhammad", en: "Surah Muhammad" },
  48: { tr: "Fetih Sûresi", ar: "سورة الفتح", de: "Sure Al-Fath", en: "Surah Al-Fath" },
  49: { tr: "Hucurât Sûresi", ar: "سورة الحجرات", de: "Sure Al-Hujurat", en: "Surah Al-Hujurat" },
  50: { tr: "Kâf Sûresi", ar: "سورة ق", de: "Sure Qaf", en: "Surah Qaf" },
  51: { tr: "Zâriyât Sûresi", ar: "سورة الذاريات", de: "Sure Adh-Dhariyat", en: "Surah Adh-Dhariyat" },
  52: { tr: "Tûr Sûresi", ar: "سورة الطور", de: "Sure At-Tur", en: "Surah At-Tur" },
  53: { tr: "Necm Sûresi", ar: "سورة النجم", de: "Sure An-Najm", en: "Surah An-Najm" },
  54: { tr: "Kamer Sûresi", ar: "سورة القمر", de: "Sure Al-Qamar", en: "Surah Al-Qamar" },
  55: { tr: "Rahmân Sûresi", ar: "سورة الرحمن", de: "Sure Ar-Rahman", en: "Surah Ar-Rahman" },
  56: { tr: "Vâkıa Sûresi", ar: "سورة الواقعة", de: "Sure Al-Waqi'ah", en: "Surah Al-Waqi'ah" },
  57: { tr: "Hadîd Sûresi", ar: "سورة الحديد", de: "Sure Al-Hadid", en: "Surah Al-Hadid" },
  58: { tr: "Mücâdile Sûresi", ar: "سورة المجادلة", de: "Sure Al-Mujadilah", en: "Surah Al-Mujadilah" },
  59: { tr: "Haşr Sûresi", ar: "سورة الحشر", de: "Sure Al-Haschr", en: "Surah Al-Hashr" },
  60: { tr: "Mümtehine Sûresi", ar: "سورة الممتحنة", de: "Sure Al-Mumtahanah", en: "Surah Al-Mumtahanah" },
  61: { tr: "Saff Sûresi", ar: "سورة الصف", de: "Sure As-Saff", en: "Surah As-Saff" },
  62: { tr: "Cum'a Sûresi", ar: "سورة الجمعة", de: "Sure Al-Jumu'ah", en: "Surah Al-Jumu'ah" },
  63: { tr: "Münâfikûn Sûresi", ar: "سورة المنافقون", de: "Sure Al-Munafiqun", en: "Surah Al-Munafiqun" },
  64: { tr: "Tegâbün Sûresi", ar: "سورة التغابن", de: "Sure At-Taghabun", en: "Surah At-Taghabun" },
  65: { tr: "Talâk Sûresi", ar: "سورة الطلاق", de: "Sure At-Talaq", en: "Surah At-Talaq" },
  66: { tr: "Tahrîm Sûresi", ar: "سورة التحريم", de: "Sure At-Tahrim", en: "Surah At-Tahrim" },
  67: { tr: "Mülk Sûresi", ar: "سورة الملك", de: "Sure Al-Mulk", en: "Surah Al-Mulk" },
  68: { tr: "Kalem Sûresi", ar: "سورة القلم", de: "Sure Al-Qalam", en: "Surah Al-Qalam" },
  69: { tr: "Hâkka Sûresi", ar: "سورة الحاقة", de: "Sure Al-Haqqah", en: "Surah Al-Haqqah" },
  70: { tr: "Meâric Sûresi", ar: "سورة المعارج", de: "Sure Al-Ma'arij", en: "Surah Al-Ma'arij" },
  71: { tr: "Nûh Sûresi", ar: "سورة نوح", de: "Sure Nuh", en: "Surah Nuh" },
  72: { tr: "Cin Sûresi", ar: "سورة الجن", de: "Sure Al-Jinn", en: "Surah Al-Jinn" },
  73: { tr: "Müzzemmil Sûresi", ar: "سورة المزمل", de: "Sure Al-Muzzammil", en: "Surah Al-Muzzammil" },
  74: { tr: "Müddessir Sûresi", ar: "سورة المدثر", de: "Sure Al-Muddaththir", en: "Surah Al-Muddaththir" },
  75: { tr: "Kıyâme Sûresi", ar: "سورة القيامة", de: "Sure Al-Qiyamah", en: "Surah Al-Qiyamah" },
  76: { tr: "İnsân Sûresi", ar: "سورة الإنسان", de: "Sure Al-Insan", en: "Surah Al-Insan" },
  77: { tr: "Mürselât Sûresi", ar: "سورة المرسلات", de: "Sure Al-Mursalat", en: "Surah Al-Mursalat" },
  78: { tr: "Nebe' Sûresi", ar: "سورة النبأ", de: "Sure An-Naba", en: "Surah An-Naba" },
  79: { tr: "Nâziât Sûresi", ar: "سورة النازعات", de: "Sure An-Nazi'at", en: "Surah An-Nazi'at" },
  80: { tr: "Abese Sûresi", ar: "سورة عبس", de: "Sure Abasa", en: "Surah 'Abasa" },
  81: { tr: "Tekvîr Sûresi", ar: "سورة التكوير", de: "Sure At-Takwir", en: "Surah At-Takwir" },
  82: { tr: "İnfitâr Sûresi", ar: "سورة الانفطار", de: "Sure Al-Infitar", en: "Surah Al-Infitar" },
  83: { tr: "Mutaffifîn Sûresi", ar: "سورة المطففين", de: "Sure Al-Mutaffifin", en: "Surah Al-Mutaffifin" },
  84: { tr: "İnşikâk Sûresi", ar: "سورة الانشقاق", de: "Sure Al-Inshiqaq", en: "Surah Al-Inshiqaq" },
  85: { tr: "Bürûc Sûresi", ar: "سورة البروج", de: "Sure Al-Buruj", en: "Surah Al-Buruj" },
  86: { tr: "Târık Sûresi", ar: "سورة الطارق", de: "Sure At-Tariq", en: "Surah At-Tariq" },
  87: { tr: "A'lâ Sûresi", ar: "سورة الأعلى", de: "Sure Al-A'la", en: "Surah Al-A'la" },
  88: { tr: "Gâşiye Sûresi", ar: "سورة الغاشية", de: "Sure Al-Ghaschiyah", en: "Surah Al-Ghashiyah" },
  89: { tr: "Fecr Sûresi", ar: "سورة الفجر", de: "Sure Al-Fajr", en: "Surah Al-Fajr" },
  90: { tr: "Beled Sûresi", ar: "سورة البلد", de: "Sure Al-Balad", en: "Surah Al-Balad" },
  91: { tr: "Şems Sûresi", ar: "سورة الشمس", de: "Sure Asch-Schams", en: "Surah Ash-Shams" },
  92: { tr: "Leyl Sûresi", ar: "سورة الليل", de: "Sure Al-Lail", en: "Surah Al-Layl" },
  93: { tr: "Duhâ Sûresi", ar: "سورة الضحى", de: "Sure Ad-Duha", en: "Surah Ad-Duha" },
  94: { tr: "İnşirâh Sûresi", ar: "سورة الشرح", de: "Sure Al-Inschirah", en: "Surah Ash-Sharh" },
  95: { tr: "Tîn Sûresi", ar: "سورة التين", de: "Sure At-Tin", en: "Surah At-Tin" },
  96: { tr: "Alak Sûresi", ar: "سورة العلق", de: "Sure Al-Alaq", en: "Surah Al-'Alaq" },
  97: { tr: "Kadir Sûresi", ar: "سورة القدر", de: "Sure Al-Qadr", en: "Surah Al-Qadr" },
  98: { tr: "Beyyine Sûresi", ar: "سورة البينة", de: "Sure Al-Bayyinah", en: "Surah Al-Bayyinah" },
  99: { tr: "Zilzâl Sûresi", ar: "سورة الزلزلة", de: "Sure Az-Zalzalah", en: "Surah Az-Zalzalah" },
  100: { tr: "Âdiyât Sûresi", ar: "سورة العاديات", de: "Sure Al-Adiyat", en: "Surah Al-'Adiyat" },
  101: { tr: "Kâria Sûresi", ar: "سورة القارعة", de: "Sure Al-Qari'ah", en: "Surah Al-Qari'ah" },
  102: { tr: "Tekâsür Sûresi", ar: "سورة التكاثر", de: "Sure At-Takathur", en: "Surah At-Takathur" },
  103: { tr: "Asr Sûresi", ar: "سورة العصر", de: "Sure Al-Asr", en: "Surah Al-'Asr" },
  104: { tr: "Hümeze Sûresi", ar: "سورة الهمزة", de: "Sure Al-Humazah", en: "Surah Al-Humazah" },
  105: { tr: "Fîl Sûresi", ar: "سورة الفيل", de: "Sure Al-Fil", en: "Surah Al-Fil" },
  106: { tr: "Kureyş Sûresi", ar: "سورة قريش", de: "Sure Quraidsch", en: "Surah Quraysh" },
  107: { tr: "Mâûn Sûresi", ar: "سورة الماعون", de: "Sure Al-Ma'un", en: "Surah Al-Ma'un" },
  108: { tr: "Kevser Sûresi", ar: "سورة الكوثر", de: "Sure Al-Kauthar", en: "Surah Al-Kawthar" },
  109: { tr: "Kâfirûn Sûresi", ar: "سورة الكافرون", de: "Sure Al-Kafirun", en: "Surah Al-Kafirun" },
  110: { tr: "Nasr Sûresi", ar: "سورة النصر", de: "Sure An-Nasr", en: "Surah An-Nasr" },
  111: { tr: "Tebbet Sûresi", ar: "سورة المسد", de: "Sure Al-Masad", en: "Surah Al-Masad" },
  112: { tr: "İhlâs Sûresi", ar: "سورة الإخلاص", de: "Sure Al-Ikhlas", en: "Surah Al-Ikhlas" },
  113: { tr: "Felak Sûresi", ar: "سورة الفلق", de: "Sure Al-Falaq", en: "Surah Al-Falaq" },
  114: { tr: "Nâs Sûresi", ar: "سورة الناس", de: "Sure An-Nas", en: "Surah An-Nas" }
};

remainingAyahsData.forEach((row, idx) => {
  const [sNum, aNum, arabic, tr, de, en] = row;
  const sName = surahNamesMap[sNum] || { tr: `Sûre ${sNum}`, ar: `سورة ${sNum}`, de: `Sure ${sNum}`, en: `Surah ${sNum}` };
  const id = `ayah-${idx + 11}`;
  ayahs.push({
    id,
    surahNumber: sNum,
    ayahNumber: aNum,
    surahName: sName,
    arabic,
    translations: {
      tr,
      ar: arabic,
      de,
      en
    },
    reference: `${sName.tr} ${sNum}:${aNum}`
  });
});

console.log(`Successfully collected ${ayahs.length} ayahs.`);

// Validation check
if (ayahs.length !== 200) {
  console.error(`ERROR: Expected exactly 200 ayahs, but got ${ayahs.length}!`);
  process.exit(1);
}

const idSet = new Set();
ayahs.forEach(a => {
  if (idSet.has(a.id)) {
    console.error(`Duplicate ID found: ${a.id}`);
    process.exit(1);
  }
  idSet.add(a.id);
  if (!a.arabic || !a.translations.tr || !a.translations.ar || !a.translations.de || !a.translations.en) {
    console.error(`Missing translation in ayah: ${a.id}`);
    process.exit(1);
  }
});

const outJson = JSON.stringify(ayahs, null, 2);
fs.writeFileSync(path.join(__dirname, '../src/data/ayetler.json'), outJson);
fs.writeFileSync(path.join(__dirname, '../public/assets/data/ayetler.json'), outJson);

console.log('✓ ayetler.json saved to src/data/ and public/assets/data/ (200 records).');
