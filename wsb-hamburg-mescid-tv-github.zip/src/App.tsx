import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Power } from 'lucide-react';
import { Header } from './components/Header';
import { PrayerCards } from './components/PrayerCards';
import { DailyContent } from './components/DailyContent';
import { SpecialBanners } from './components/SpecialBanners';
import { TickerBar } from './components/TickerBar';
import { PrayerSequenceModal } from './components/PrayerSequenceModal';
import { AdminModal } from './components/AdminModal';
import { RemoteControlGuide } from './components/RemoteControlGuide';
import { PwaInstallPrompt } from './components/PwaInstallPrompt';

import { LuxuryTvDisplay } from './components/LuxuryTvDisplay';

import {
  Language,
  MosqueSettings,
  PrayerTimes,
  DailyPair,
  Announcement,
} from './types';
import { storageService } from './services/storageService';
import { prayerTimeService } from './services/prayerTimeService';
import { wakeLockService } from './services/wakeLockService';
import { dailyContentService } from './services/dailyContentService';

export default function App() {
  // 1. Persistent State
  const [settings, setSettings] = useState<MosqueSettings>(() => storageService.getSettings());
  const [dailyPairs, setDailyPairs] = useState<DailyPair[]>(() => storageService.getDailyPairs());
  const [announcements, setAnnouncements] = useState<Announcement[]>(() =>
    storageService.getAnnouncements()
  );

  // 2. Runtime Dynamic State
  const [currentLanguage, setCurrentLanguage] = useState<Language>(settings.defaultLanguage);
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [timings, setTimings] = useState<PrayerTimes | null>(null);
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [isWakeLocked, setIsWakeLocked] = useState<boolean>(false);
  const [autoRotateSecondsLeft, setAutoRotateSecondsLeft] = useState<number>(
    settings.rotationIntervalSeconds
  );

  // 7/24 TV User Gesture Prompt for browsers requiring click/interaction to grant WakeLock & Autoplay
  const [showStartPrompt, setShowStartPrompt] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return !sessionStorage.getItem('wsb_tv_gesture_activated');
    }
    return false;
  });

  // Modals state
  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(false);
  const [isPrayerSequenceOpen, setIsPrayerSequenceOpen] = useState<boolean>(false);
  const [sequencePrayerName, setSequencePrayerName] = useState<string>('');

  // Daily trigger tracker to avoid repeating sequence for the same prayer
  const triggeredPrayersToday = useRef<Set<string>>(new Set());
  const lastDateStrRef = useRef<string>('');
  const hasReloadedAt3AmRef = useRef<string>('');

  // 3. User Gesture Activation for TV WakeLock and Media Playback
  const handleStartTvMode = async () => {
    setShowStartPrompt(false);
    if (typeof window !== 'undefined') {
      sessionStorage.setItem('wsb_tv_gesture_activated', 'true');
    }
    const active = await wakeLockService.activateFromUserGesture();
    setIsWakeLocked(active);
  };

  // Global interaction listener: first touch / click / remote key activates TV full-screen & wake lock
  useEffect(() => {
    const handleGlobalInteraction = () => {
      if (showStartPrompt) {
        handleStartTvMode();
      } else {
        wakeLockService.requestLock().then((active) => setIsWakeLocked(active));
      }
    };

    window.addEventListener('click', handleGlobalInteraction, { passive: true });
    window.addEventListener('keydown', handleGlobalInteraction, { passive: true });
    window.addEventListener('touchstart', handleGlobalInteraction, { passive: true });

    return () => {
      window.removeEventListener('click', handleGlobalInteraction);
      window.removeEventListener('keydown', handleGlobalInteraction);
      window.removeEventListener('touchstart', handleGlobalInteraction);
    };
  }, [showStartPrompt]);

  // Keep admin mouse cursor state in sync
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.body.classList.toggle('admin-mode-open', isAdminOpen);
    }
  }, [isAdminOpen]);

  // Screen Wake Lock Heartbeat (Continuous 24/7 TV Keep-Awake)
  useEffect(() => {
    wakeLockService.requestLock().then((active) => setIsWakeLocked(active));

    const handleOnline = () => {
      setIsOnline(true);
      loadTimings(); // Immediate refresh when connectivity restored
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Heartbeat check every 20s to ensure WakeLock remains active 24/7
    const wakeHeartbeat = setInterval(() => {
      wakeLockService.requestLock().then((active) => setIsWakeLocked(active));
    }, 20000);

    return () => {
      clearInterval(wakeHeartbeat);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // 4. Fetch Hamburg Prayer Times (With robust offline recovery & 15-minute sync)
  const loadTimings = async () => {
    try {
      const res = await prayerTimeService.fetchPrayerTimes(settings);
      setTimings(res.timings);
      setIsOnline(res.isOnline);
    } catch {
      setIsOnline(false);
    }
  };

  useEffect(() => {
    loadTimings();
    // Re-fetch every 15 minutes to guarantee up-to-date timings across midnight & DST
    const interval = setInterval(loadTimings, 15 * 60 * 1000);
    return () => clearInterval(interval);
  }, [settings.calculationMethod, settings.asrMethod, settings.minuteOffsets, settings.city, settings.country]);

  // Accelerated 30-second recovery poll when offline
  useEffect(() => {
    if (isOnline) return;
    const offlineRetry = setInterval(() => {
      loadTimings();
    }, 30000);
    return () => clearInterval(offlineRetry);
  }, [isOnline]);

  // 5. Clock Tick (every second) + 03:00 AM Daily Memory Cleanup Reload + Midnight Day Change Detector
  useEffect(() => {
    const clockInterval = setInterval(() => {
      const now = new Date();
      setCurrentTime(now);

      const y = now.getFullYear();
      const m = String(now.getMonth() + 1).padStart(2, '0');
      const d = String(now.getDate()).padStart(2, '0');
      const todayDateStr = `${y}-${m}-${d}`;

      // 1. Scheduled 03:00 AM daily page reload to eliminate browser memory leaks
      if (now.getHours() === 3 && now.getMinutes() === 0 && hasReloadedAt3AmRef.current !== todayDateStr) {
        hasReloadedAt3AmRef.current = todayDateStr;
        console.log('[WSB Hamburg Mescid TV] Scheduled 03:00 AM memory cleanup reload triggered');
        window.location.reload();
      }

      // 2. Check for midnight / day change in local time (00:00:00)
      if (lastDateStrRef.current && lastDateStrRef.current !== todayDateStr) {
        // New calendar day reached: clear prayer triggers and reload prayer timings automatically
        triggeredPrayersToday.current.clear();
        loadTimings();
      }
      lastDateStrRef.current = todayDateStr;
    }, 1000);

    return () => clearInterval(clockInterval);
  }, [settings]);

  // 6. Automatic Language Rotation
  useEffect(() => {
    if (!settings.autoRotateLanguages) return;

    const langs: Language[] = ['tr', 'ar', 'de', 'en'];
    const timer = setInterval(() => {
      setAutoRotateSecondsLeft((prev) => {
        if (prev <= 1) {
          setCurrentLanguage((curr) => {
            const idx = langs.indexOf(curr);
            const nextIdx = (idx + 1) % langs.length;
            return langs[nextIdx];
          });
          return settings.rotationIntervalSeconds;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [settings.autoRotateLanguages, settings.rotationIntervalSeconds]);

  // 7. Check for prayer arrival minute -> trigger sequence
  useEffect(() => {
    if (!timings || !settings.enablePrayerSequence) return;

    const nowH = currentTime.getHours();
    const nowM = currentTime.getMinutes();
    const nowStr = `${String(nowH).padStart(2, '0')}:${String(nowM).padStart(2, '0')}`;
    const y = currentTime.getFullYear();
    const m = String(currentTime.getMonth() + 1).padStart(2, '0');
    const d = String(currentTime.getDate()).padStart(2, '0');
    const todayStr = `${y}-${m}-${d}`;

    const prayersToCheck: (keyof PrayerTimes)[] = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

    for (const p of prayersToCheck) {
      if (timings[p] === nowStr) {
        const triggerKey = `${todayStr}-${p}`;
        if (!triggeredPrayersToday.current.has(triggerKey)) {
          triggeredPrayersToday.current.add(triggerKey);
          setSequencePrayerName(p);
          setIsPrayerSequenceOpen(true);
          break;
        }
      }
    }
  }, [currentTime, timings, settings.enablePrayerSequence]);

  // 7b. Strict 30-Second Auto-Close for Prayer Entrance Pop-up (No human remote action needed)
  useEffect(() => {
    if (!isPrayerSequenceOpen) return;

    const autoCloseTimer = setTimeout(() => {
      setIsPrayerSequenceOpen(false);
    }, 30000); // exactly 30 seconds

    return () => clearTimeout(autoCloseTimer);
  }, [isPrayerSequenceOpen]);

  // 8. Remote Control / Keyboard Listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'm' || e.key === 'M') {
        setIsAdminOpen((prev) => !prev);
      } else if (e.key === 'Escape') {
        if (isAdminOpen) setIsAdminOpen(false);
        if (isPrayerSequenceOpen) setIsPrayerSequenceOpen(false);
      } else if (e.key === '1') {
        setCurrentLanguage('tr');
      } else if (e.key === '2') {
        setCurrentLanguage('ar');
      } else if (e.key === '3') {
        setCurrentLanguage('de');
      } else if (e.key === '4') {
        setCurrentLanguage('en');
      }
    };

    const handleTvMenu = () => setIsAdminOpen(true);
    const handleTvBack = () => {
      if (isAdminOpen) setIsAdminOpen(false);
      if (isPrayerSequenceOpen) setIsPrayerSequenceOpen(false);
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('tv-remote-menu', handleTvMenu);
    window.addEventListener('tv-remote-back', handleTvBack);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('tv-remote-menu', handleTvMenu);
      window.removeEventListener('tv-remote-back', handleTvBack);
    };
  }, [isAdminOpen, isPrayerSequenceOpen]);

  // 9. Calculated Prayer State
  const nextPrayer = useMemo(() => {
    if (!timings) return null;
    return prayerTimeService.calculateNextPrayer(timings, currentTime);
  }, [timings, currentTime]);

  const activePrayer = useMemo(() => {
    if (!timings) return null;
    return prayerTimeService.calculateActivePrayer(timings, currentTime);
  }, [timings, currentTime]);

  // Today's Quran Ayah & Hadith pair (Europe/Berlin deterministic 200-day cycle)
  const todayPair = useMemo(() => {
    return dailyContentService.getTodayPair(currentTime);
  }, [currentTime]);

  // Theme styles
  const isIvoryTheme = settings.theme === 'ivory' || !settings.theme;
  const themeClasses = useMemo(() => {
    switch (settings.theme) {
      case 'midnight':
        return 'bg-[#000000] text-gray-100';
      case 'sapphire':
        return 'bg-[#030d1a] text-blue-50';
      case 'high-contrast':
        return 'bg-black text-white font-extrabold';
      case 'emerald':
        return 'bg-[#040e0c] text-white';
      case 'ivory':
      default:
        return 'bg-[#F5F3EC] text-[#1F2421]';
    }
  }, [settings.theme]);

  // Scaled 1920x1080 TV Stage calculation
  const [stageDimensions, setStageDimensions] = useState(() => {
    if (typeof window === 'undefined') return { scale: 1, left: 0, top: 0 };
    const scale = Math.min(window.innerWidth / 1920, window.innerHeight / 1080);
    const left = (window.innerWidth - 1920 * scale) / 2;
    const top = (window.innerHeight - 1080 * scale) / 2;
    return { scale, left, top };
  });

  useEffect(() => {
    const handleResize = () => {
      const scale = Math.min(window.innerWidth / 1920, window.innerHeight / 1080);
      const left = (window.innerWidth - 1920 * scale) / 2;
      const top = (window.innerHeight - 1080 * scale) / 2;
      setStageDimensions({ scale, left, top });
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div
      className="fixed inset-0 w-screen h-screen overflow-hidden bg-[#F5F3EC] text-[#1F2421] select-none"
      style={{ margin: 0, padding: 0 }}
    >
      {/* 1920x1080 Fixed Stage with Proportional Scaling (Stage columns never mirrored; dir="ltr") */}
      <div
        id="wsb-tv-stage"
        dir="ltr"
        style={{
          position: 'absolute',
          width: 1920,
          height: 1080,
          left: stageDimensions.left,
          top: stageDimensions.top,
          transform: `scale(${stageDimensions.scale})`,
          transformOrigin: 'top left',
          overflow: 'hidden',
          backgroundColor: '#F5F3EC',
        }}
        className="w-[1920px] h-[1080px] overflow-hidden flex flex-col justify-between p-[24px] box-border"
      >
        <LuxuryTvDisplay
          timings={timings}
          activePrayer={activePrayer}
          nextPrayer={nextPrayer}
          currentTime={currentTime}
          currentLanguage={currentLanguage}
          onLanguageChange={setCurrentLanguage}
          isOnline={isOnline}
          isWakeLocked={isWakeLocked}
          settings={settings}
          onOpenAdmin={() => setIsAdminOpen(true)}
          autoRotateSecondsLeft={autoRotateSecondsLeft}
          todayPair={todayPair}
        />

        {/* Bottom Ticker Bar - Part of normal stage flow, fixed 80px height, never overlays */}
        <TickerBar announcements={announcements} currentLanguage={currentLanguage} />
      </div>

      {/* 4. Remote Control Shortcuts Guide */}
      <RemoteControlGuide currentLanguage={currentLanguage} />

      {/* 5. Prayer Entrance Animation Modal */}
      {todayPair && (
        <PrayerSequenceModal
          isOpen={isPrayerSequenceOpen}
          onClose={() => setIsPrayerSequenceOpen(false)}
          pair={todayPair}
          currentLanguage={currentLanguage}
          prayerName={sequencePrayerName}
          settings={settings}
        />
      )}

      {/* 6. Admin Settings Modal */}
      <AdminModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        settings={settings}
        onSaveSettings={(newSettings) => {
          setSettings(newSettings);
          storageService.saveSettings(newSettings);
        }}
        dailyPairs={dailyPairs}
        onSaveDailyPairs={(pairs) => {
          setDailyPairs(pairs);
          storageService.saveDailyPairs(pairs);
        }}
        announcements={announcements}
        onSaveAnnouncements={(anns) => {
          setAnnouncements(anns);
          storageService.saveAnnouncements(anns);
        }}
        onManualRefresh={loadTimings}
        onTriggerTestSequence={() => {
          setSequencePrayerName('ÖĞLE');
          setIsPrayerSequenceOpen(true);
        }}
        currentLanguage={currentLanguage}
      />

      {/* 6b. Progressive Web App (PWA) Add to Home Screen Prompt (3 seconds after load) */}
      <PwaInstallPrompt />

      {/* 7. Initial TV Gesture Activation Button (WakeLock & Media Keep-Alive) */}
      {showStartPrompt && (
        <div
          onClick={handleStartTvMode}
          className="fixed bottom-12 right-6 z-50 flex items-center gap-3 px-4 py-3 rounded-2xl bg-[#1C201D]/95 text-white border-2 border-[#D4AF37] shadow-[0_12px_40px_rgba(0,0,0,0.5)] backdrop-blur-md cursor-pointer animate-pulse transition-all hover:scale-105 active:scale-95"
        >
          <span className="p-2 rounded-xl bg-[#8E630D] text-amber-200 shrink-0">
            <Power className="w-4 h-4 text-[#FFDF78]" />
          </span>
          <div className="text-left">
            <div className="text-xs sm:text-sm font-black font-cinzel text-amber-300 tracking-wider">
              7/24 KESİNTİSİZ TV MODUNU BAŞLAT
            </div>
            <div className="text-[10px] sm:text-[11px] text-[#A6B0A8]">
              Kumandadan OK tuşuna basın veya ekrana dokunun
            </div>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleStartTvMode();
            }}
            className="ml-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#8E630D] text-black font-black text-xs hover:brightness-110 shadow-sm"
          >
            BAŞLAT
          </button>
        </div>
      )}
    </div>
  );
}
