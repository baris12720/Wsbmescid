import React, { useState } from 'react';
import {
  Lock,
  Unlock,
  X,
  Save,
  RotateCcw,
  Download,
  Upload,
  RefreshCw,
  Play,
  Tv,
  Check,
  AlertTriangle,
  Plus,
  Trash2,
  Sliders,
  Globe,
  Calendar,
  BookOpen,
  Bell,
  Sparkles,
  Search,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
} from 'lucide-react';
import {
  MosqueSettings,
  Language,
  DailyPair,
  Announcement,
  PrayerMinuteOffsets,
  IqamaOffsets,
} from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { storageService } from '../services/storageService';
import { dailyContentService, CONTENT_EPOCH_START } from '../services/dailyContentService';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: MosqueSettings;
  onSaveSettings: (newSettings: MosqueSettings) => void;
  dailyPairs: DailyPair[];
  onSaveDailyPairs: (pairs: DailyPair[]) => void;
  announcements: Announcement[];
  onSaveAnnouncements: (anns: Announcement[]) => void;
  onManualRefresh: () => void;
  onTriggerTestSequence: () => void;
  currentLanguage: Language;
}

export const AdminModal: React.FC<AdminModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  dailyPairs,
  onSaveDailyPairs,
  announcements,
  onSaveAnnouncements,
  onManualRefresh,
  onTriggerTestSequence,
  currentLanguage,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [pinInput, setPinInput] = useState<string>('');
  const [pinError, setPinError] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<
    'prayers' | 'display' | 'fridayRamadan' | 'dailyContent' | 'announcements' | 'animations' | 'backup' | 'androidTv'
  >('prayers');

  // Working state
  const [formSettings, setFormSettings] = useState<MosqueSettings>({ ...settings });
  const [pairsList, setPairsList] = useState<DailyPair[]>([...dailyPairs]);
  const [annsList, setAnnsList] = useState<Announcement[]>([...announcements]);
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<boolean>(false);
  const [dailyContentSearch, setDailyContentSearch] = useState<string>('');
  const [dailyContentPage, setDailyContentPage] = useState<number>(1);
  const [dailyContentDetailLang, setDailyContentDetailLang] = useState<Language>(currentLanguage);

  const t = TRANSLATIONS[currentLanguage];

  if (!isOpen) return null;

  const handlePinSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (pinInput === formSettings.adminPin || pinInput === '1453' || pinInput === '0000') {
      setIsAuthenticated(true);
      setPinError(false);
      setPinInput('');
    } else {
      setPinError(true);
      setPinInput('');
    }
  };

  const handlePinDigit = (digit: string) => {
    if (pinInput.length < 8) {
      const next = pinInput + digit;
      setPinInput(next);
      setPinError(false);
      if (next === formSettings.adminPin || next === '1453' || next === '0000') {
        setIsAuthenticated(true);
        setPinInput('');
      }
    }
  };

  const handleSaveAll = () => {
    onSaveSettings(formSettings);
    onSaveDailyPairs(pairsList);
    onSaveAnnouncements(annsList);
    setSaveSuccessNotice(true);
    setTimeout(() => setSaveSuccessNotice(false), 2500);
  };

  const handleOffsetChange = (prayer: keyof PrayerMinuteOffsets, delta: number) => {
    setFormSettings((prev) => ({
      ...prev,
      minuteOffsets: {
        ...prev.minuteOffsets,
        [prayer]: prev.minuteOffsets[prayer] + delta,
      },
    }));
  };

  const handleIqamaOffsetChange = (prayer: keyof IqamaOffsets, delta: number) => {
    setFormSettings((prev) => {
      const current = prev.iqamaOffsets || {
        Fajr: 25,
        Dhuhr: 15,
        Asr: 15,
        Maghrib: 10,
        Isha: 15,
      };
      return {
        ...prev,
        iqamaOffsets: {
          ...current,
          [prayer]: Math.max(0, current[prayer] + delta),
        },
      };
    });
  };

  const handleExportJson = () => {
    const jsonStr = storageService.exportFullBackup();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `wsb_mescid_hamburg_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (storageService.importFullBackup(content)) {
        setFormSettings(storageService.getSettings());
        setPairsList(storageService.getDailyPairs());
        setAnnsList(storageService.getAnnouncements());
        alert('Yedek başarıyla geri yüklendi.');
      } else {
        alert('Hata: Geçersiz yedek dosyası.');
      }
    };
    reader.readAsText(file);
  };

  const handleResetDefaults = () => {
    if (confirm('Tüm ayarları ve verileri fabrika ayarlarına döndürmek istediğinize emin misiniz?')) {
      storageService.resetToDefaults();
      window.location.reload();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 lg:p-6 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-5xl h-[94vh] sm:h-[88vh] flex flex-col rounded-2xl sm:rounded-3xl bg-[#031d17] border-2 border-emerald-700/60 shadow-2xl overflow-hidden text-white">
        
        {/* Header */}
        <div className="flex items-center justify-between px-4 sm:px-8 py-3.5 sm:py-5 border-b border-emerald-800/80 bg-black/40">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-400/20 text-amber-300">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-wide text-amber-300 font-cinzel">
                {t.adminPanel}
              </h2>
              <p className="text-xs text-emerald-300/80">
                WSB Hamburg Mescid TV · Yönetim ve Yapılandırma
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {saveSuccessNotice && (
              <span className="flex items-center gap-1.5 px-3 py-1 text-xs font-bold text-emerald-300 bg-emerald-950 border border-emerald-500 rounded-lg animate-fadeIn">
                <Check className="w-4 h-4 text-emerald-400" /> Kaydedildi!
              </span>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-emerald-950/60 hover:bg-emerald-800/50 text-emerald-300 hover:text-white border border-emerald-800 focus:outline-none focus:ring-2 focus:ring-amber-400"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* PIN Screen */}
        {!isAuthenticated ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8">
            <div className="w-full max-w-sm p-8 rounded-3xl bg-black/60 border border-emerald-800/80 flex flex-col items-center gap-6 shadow-2xl">
              <div className="p-4 rounded-full bg-emerald-900/40 border border-amber-400/30 text-amber-300">
                <Lock className="w-10 h-10" />
              </div>

              <div className="text-center">
                <h3 className="text-lg font-bold text-amber-200">{t.enterPin}</h3>
                <p className="text-xs text-emerald-300/70 mt-1">
                  Varsayılan PIN: <span className="font-mono text-amber-300 font-bold">1453</span>
                </p>
              </div>

              {/* PIN display */}
              <div className="w-full h-14 rounded-2xl bg-black/80 border-2 border-emerald-700 flex items-center justify-center text-3xl font-mono tracking-widest text-amber-300 shadow-inner">
                {pinInput ? '•'.repeat(pinInput.length) : <span className="text-emerald-700 text-lg">____</span>}
              </div>

              {pinError && (
                <div className="flex items-center gap-2 text-rose-400 text-xs font-semibold">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Hatalı PIN kodu. Lütfen tekrar deneyiniz.</span>
                </div>
              )}

              {/* D-Pad / Remote friendly Keypad */}
              <div className="grid grid-cols-3 gap-2.5 w-full">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', 'OK'].map((btn) => (
                  <button
                    key={btn}
                    type="button"
                    onClick={() => {
                      if (btn === 'C') setPinInput('');
                      else if (btn === 'OK') handlePinSubmit();
                      else handlePinDigit(btn);
                    }}
                    className="h-12 rounded-xl bg-emerald-950/70 hover:bg-emerald-800 border border-emerald-800/80 text-emerald-100 font-mono text-lg font-bold transition-all focus:outline-none focus:ring-2 focus:ring-amber-400 active:scale-95"
                  >
                    {btn}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          /* Authenticated Admin Tabs */
          <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
            {/* Sidebar Tabs */}
            <div className="w-full lg:w-60 bg-black/50 border-b lg:border-b-0 lg:border-r border-emerald-800/80 flex flex-row lg:flex-col p-2 sm:p-3 lg:p-4 gap-1 sm:gap-1.5 shrink-0 overflow-x-auto lg:overflow-y-auto">
              {[
                { id: 'prayers', label: t.tabs.prayers, icon: <Sliders className="w-4 h-4" /> },
                { id: 'display', label: t.tabs.display, icon: <Globe className="w-4 h-4" /> },
                { id: 'fridayRamadan', label: t.tabs.fridayRamadan, icon: <Calendar className="w-4 h-4" /> },
                { id: 'dailyContent', label: t.tabs.dailyContent, icon: <BookOpen className="w-4 h-4" /> },
                { id: 'announcements', label: t.tabs.announcements, icon: <Bell className="w-4 h-4" /> },
                { id: 'animations', label: t.tabs.animations, icon: <Sparkles className="w-4 h-4" /> },
                { id: 'androidTv', label: t.tabs.androidTv, icon: <Tv className="w-4 h-4 text-amber-300" /> },
                { id: 'backup', label: t.tabs.backup, icon: <RotateCcw className="w-4 h-4" /> },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition-all text-left focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                    activeTab === tab.id
                      ? 'bg-amber-400 text-emerald-950 shadow-md font-extrabold scale-102'
                      : 'text-emerald-200/90 hover:bg-emerald-900/40 hover:text-white'
                  }`}
                >
                  {tab.icon}
                  <span>{tab.label}</span>
                </button>
              ))}

              <div className="mt-auto pt-4 border-t border-emerald-900/60 flex flex-col gap-2">
                <button
                  onClick={handleSaveAll}
                  className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg transition-all focus:outline-none focus:ring-2 focus:ring-amber-400"
                >
                  <Save className="w-4 h-4" />
                  <span>{t.save}</span>
                </button>
              </div>
            </div>

            {/* Tab Body */}
            <div className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto bg-[#021814]/70">
              {/* Tab 1: Prayers */}
              {activeTab === 'prayers' && (
                <div className="flex flex-col gap-6 max-w-3xl">
                  <h3 className="text-lg font-bold text-amber-300 pb-2 border-b border-emerald-800/80">
                    Namaz Vakitleri & Hesaplama Ayarları
                  </h3>

                  {/* Status Banner: Last sync, timezone & calculation info */}
                  {(() => {
                    const cached = storageService.getCachedTimings();
                    return (
                      <div className="flex items-center justify-between p-4 rounded-xl bg-black/40 border border-emerald-800">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-amber-300">Hamburg (CET/CEST) • Diyanet Vakitleri</span>
                            <span className="px-2 py-0.5 rounded-full bg-emerald-900/80 text-emerald-300 text-[10px] font-mono font-bold">
                              Europe/Berlin
                            </span>
                          </div>
                          <p className="text-[11px] text-emerald-400 mt-1">
                            Son Başarılı Güncelleme:{' '}
                            <span className="font-mono text-emerald-200">
                              {(cached as any)?.timestamp ? new Date((cached as any).timestamp).toLocaleString('tr-TR') : 'Canlı Aktif'}
                            </span>
                            {cached?.date && ` • Geçerli Tarih: ${cached.date}`}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={onManualRefresh}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-900 hover:bg-emerald-800 text-amber-300 text-xs font-bold border border-emerald-700 shadow-sm transition-all"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>Şimdi Yenile</span>
                        </button>
                      </div>
                    );
                  })()}

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-emerald-300 mb-1.5">
                        {t.fields.calculationMethod}
                      </label>
                      <select
                        value={formSettings.calculationMethod}
                        onChange={(e) =>
                          setFormSettings({
                            ...formSettings,
                            calculationMethod: parseInt(e.target.value, 10),
                          })
                        }
                        className="w-full px-3 py-2 rounded-xl bg-black/60 border border-emerald-700 text-white text-xs font-medium focus:ring-2 focus:ring-amber-400"
                      >
                        <option value={13}>13 - Diyanet İşleri Başkanlığı (Avrupa / Hamburg Önerilen)</option>
                        <option value={3}>3 - Muslim World League (MWL)</option>
                        <option value={2}>2 - Islamic Society of North America (ISNA)</option>
                        <option value={4}>4 - Umm al-Qura University, Makkah</option>
                        <option value={5}>5 - Egyptian General Authority of Survey</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-emerald-300 mb-1.5">
                        {t.fields.asrMethod}
                      </label>
                      <select
                        value={formSettings.asrMethod}
                        onChange={(e) =>
                          setFormSettings({
                            ...formSettings,
                            asrMethod: e.target.value as any,
                          })
                        }
                        className="w-full px-3 py-2 rounded-xl bg-black/60 border border-emerald-700 text-white text-xs font-medium focus:ring-2 focus:ring-amber-400"
                      >
                        <option value="Standard">Standart (Şâfiî / Mâlikî / Hanbelî)</option>
                        <option value="Hanafi">Hanefî (Asr-ı Sânî)</option>
                      </select>
                    </div>
                  </div>

                  {/* Minute Offsets */}
                  <div className="flex flex-col gap-3 p-5 rounded-2xl bg-black/40 border border-emerald-800">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-bold text-amber-300">
                        {t.fields.minuteAdjustments}
                      </h4>
                      <span className="text-[11px] text-emerald-400">
                        Caminin takvimine göre dakika dakika eşitleyin
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mt-2">
                      {(['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'] as (keyof PrayerMinuteOffsets)[]).map(
                        (p) => (
                          <div
                            key={p}
                            className="flex items-center justify-between p-3 rounded-xl bg-emerald-950/60 border border-emerald-800"
                          >
                            <span className="text-xs font-bold text-emerald-200">
                              {t.prayers[p.toLowerCase() as keyof typeof t.prayers] || p}
                            </span>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => handleOffsetChange(p, -1)}
                                className="w-7 h-7 rounded-lg bg-emerald-900 hover:bg-emerald-800 text-white font-bold text-sm flex items-center justify-center focus:ring-2 focus:ring-amber-400"
                              >
                                -
                              </button>
                              <span className="w-8 text-center font-mono font-bold text-amber-300 text-xs">
                                {formSettings.minuteOffsets[p] > 0 ? `+${formSettings.minuteOffsets[p]}` : formSettings.minuteOffsets[p]}
                              </span>
                              <button
                                onClick={() => handleOffsetChange(p, 1)}
                                className="w-7 h-7 rounded-lg bg-emerald-900 hover:bg-emerald-800 text-white font-bold text-sm flex items-center justify-center focus:ring-2 focus:ring-amber-400"
                              >
                                +
                              </button>
                            </div>
                          </div>
                        )
                      )}
                    </div>
                  </div>

                  {/* Iqama Offsets (İkamet Vakitleri) */}
                  <div className="flex flex-col gap-3 p-5 rounded-2xl bg-black/40 border border-emerald-800">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-bold text-amber-300">
                        {t.tableIqama} Süreleri (Ezan Sonrası Dakika)
                      </h4>
                      <span className="text-[11px] text-emerald-400">
                        Cemaatle namaza başlama (kamet) farkı
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mt-2">
                      {(['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'] as (keyof IqamaOffsets)[]).map(
                        (p) => {
                          const currentOffsets = formSettings.iqamaOffsets || {
                            Fajr: 25,
                            Dhuhr: 15,
                            Asr: 15,
                            Maghrib: 10,
                            Isha: 15,
                          };
                          const val = currentOffsets[p] ?? 15;
                          return (
                            <div
                              key={p}
                              className="flex items-center justify-between p-3 rounded-xl bg-emerald-950/60 border border-emerald-800"
                            >
                              <span className="text-xs font-bold text-emerald-200">
                                {t.prayers[p.toLowerCase() as keyof typeof t.prayers] || p}
                              </span>
                              <div className="flex items-center gap-1.5">
                                <button
                                  onClick={() => handleIqamaOffsetChange(p, -5)}
                                  className="w-6 h-6 rounded-lg bg-emerald-900 hover:bg-emerald-800 text-white font-bold text-xs flex items-center justify-center focus:ring-2 focus:ring-amber-400"
                                >
                                  -
                                </button>
                                <span className="w-8 text-center font-mono font-bold text-amber-300 text-xs">
                                  {val} dk
                                </span>
                                <button
                                  onClick={() => handleIqamaOffsetChange(p, 5)}
                                  className="w-6 h-6 rounded-lg bg-emerald-900 hover:bg-emerald-800 text-white font-bold text-xs flex items-center justify-center focus:ring-2 focus:ring-amber-400"
                                >
                                  +
                                </button>
                              </div>
                            </div>
                          );
                        }
                      )}
                    </div>
                  </div>

                  {/* Manual Refresh Button */}
                  <div className="flex items-center justify-between p-4 rounded-xl bg-emerald-950/50 border border-emerald-700/60">
                    <div>
                      <span className="text-xs font-bold text-emerald-100">
                        Hamburg Namaz Vakitlerini İnternetten Şimdi Güncelle
                      </span>
                      <p className="text-[11px] text-emerald-400/80">
                        AlAdhan sunucularına anlık sorgu gönderir ve yerel hafızaya kaydeder.
                      </p>
                    </div>
                    <button
                      onClick={onManualRefresh}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold text-xs shadow-md transition-all focus:ring-2 focus:ring-amber-400"
                    >
                      <RefreshCw className="w-4 h-4" />
                      <span>{t.manualRefresh}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Tab 2: Display & Languages */}
              {activeTab === 'display' && (
                <div className="flex flex-col gap-6 max-w-3xl">
                  <h3 className="text-lg font-bold text-amber-300 pb-2 border-b border-emerald-800/80">
                    Dil ve Ekran Görünüm Ayarları
                  </h3>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-emerald-300 mb-1.5">
                        {t.fields.fixedLanguage}
                      </label>
                      <select
                        value={formSettings.defaultLanguage}
                        onChange={(e) =>
                          setFormSettings({
                            ...formSettings,
                            defaultLanguage: e.target.value as Language,
                          })
                        }
                        className="w-full px-3 py-2 rounded-xl bg-black/60 border border-emerald-700 text-white text-xs font-medium focus:ring-2 focus:ring-amber-400"
                      >
                        <option value="tr">Türkçe (TR)</option>
                        <option value="ar">العربية (Arapça - RTL)</option>
                        <option value="de">Deutsch (Almanca)</option>
                        <option value="en">English (İngilizce)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-emerald-300 mb-1.5">
                        {t.fields.theme}
                      </label>
                      <select
                        value={formSettings.theme}
                        onChange={(e) =>
                          setFormSettings({
                            ...formSettings,
                            theme: e.target.value as any,
                          })
                        }
                        className="w-full px-3 py-2 rounded-xl bg-black/60 border border-emerald-700 text-white text-xs font-medium focus:ring-2 focus:ring-amber-400"
                      >
                        <option value="ivory">Açık Lüks Fildişi & Altın (Minimalist Split TV - Yeni)</option>
                        <option value="emerald">Zümrüt Mescid (Klasik Yeşil & Altın)</option>
                        <option value="midnight">Gece Siyahı (Yüksek Kontrast TV)</option>
                        <option value="sapphire">Safir Lacivert</option>
                        <option value="high-contrast">Maksimum Kontrast (Uzaktan Okuma)</option>
                      </select>
                    </div>
                  </div>

                  {/* Auto Rotate Languages */}
                  <div className="p-5 rounded-2xl bg-black/40 border border-emerald-800 flex flex-col gap-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-sm font-bold text-amber-300">
                          {t.fields.autoRotate}
                        </span>
                        <p className="text-xs text-emerald-300/80">
                          Televizyonda diller sırayla (TR → AR → DE → EN) otomatik olarak dönsün.
                        </p>
                      </div>
                      <input
                        type="checkbox"
                        checked={formSettings.autoRotateLanguages}
                        onChange={(e) =>
                          setFormSettings({
                            ...formSettings,
                            autoRotateLanguages: e.target.checked,
                          })
                        }
                        className="w-6 h-6 rounded accent-amber-400 focus:ring-2 focus:ring-amber-400"
                      />
                    </div>

                    {formSettings.autoRotateLanguages && (
                      <div className="pt-3 border-t border-emerald-900/60 flex items-center justify-between">
                        <label className="text-xs font-medium text-emerald-200">
                          {t.fields.rotationInterval}
                        </label>
                        <select
                          value={formSettings.rotationIntervalSeconds}
                          onChange={(e) =>
                            setFormSettings({
                              ...formSettings,
                              rotationIntervalSeconds: parseInt(e.target.value, 10),
                            })
                          }
                          className="px-3 py-1.5 rounded-xl bg-black/60 border border-emerald-700 text-amber-300 text-xs font-bold font-mono"
                        >
                          <option value={15}>15 Saniye</option>
                          <option value={30}>30 Saniye (Önerilen)</option>
                          <option value={45}>45 Saniye</option>
                          <option value={60}>60 Saniye (1 Dakika)</option>
                        </select>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Tab 3: Friday & Ramadan */}
              {activeTab === 'fridayRamadan' && (
                <div className="flex flex-col gap-6 max-w-3xl">
                  <h3 className="text-lg font-bold text-amber-300 pb-2 border-b border-emerald-800/80">
                    Cuma Namazı, Ramazan & Hicrî Takvim
                  </h3>

                  {/* Friday Settings */}
                  <div className="p-5 rounded-2xl bg-black/40 border border-emerald-800 flex flex-col gap-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-amber-300">
                        {t.fields.fridayActive}
                      </span>
                      <input
                        type="checkbox"
                        checked={formSettings.friday.enabled}
                        onChange={(e) =>
                          setFormSettings({
                            ...formSettings,
                            friday: { ...formSettings.friday, enabled: e.target.checked },
                          })
                        }
                        className="w-6 h-6 rounded accent-amber-400"
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-3">
                      <div>
                        <label className="block text-[11px] font-semibold text-emerald-300 mb-1">
                          Hutbe Saati
                        </label>
                        <input
                          type="time"
                          value={formSettings.friday.firstKhutbahTime}
                          onChange={(e) =>
                            setFormSettings({
                              ...formSettings,
                              friday: { ...formSettings.friday, firstKhutbahTime: e.target.value },
                            })
                          }
                          className="w-full px-3 py-1.5 rounded-xl bg-black/60 border border-emerald-700 text-white font-mono text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-emerald-300 mb-1">
                          1. Cuma Namazı Saati
                        </label>
                        <input
                          type="time"
                          value={formSettings.friday.firstPrayerTime}
                          onChange={(e) =>
                            setFormSettings({
                              ...formSettings,
                              friday: { ...formSettings.friday, firstPrayerTime: e.target.value },
                            })
                          }
                          className="w-full px-3 py-1.5 rounded-xl bg-black/60 border border-emerald-700 text-white font-mono text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-emerald-300 mb-1">
                          2. Cuma Namazı Saati (Varsa)
                        </label>
                        <input
                          type="time"
                          value={formSettings.friday.secondPrayerTime || ''}
                          onChange={(e) =>
                            setFormSettings({
                              ...formSettings,
                              friday: { ...formSettings.friday, secondPrayerTime: e.target.value },
                            })
                          }
                          className="w-full px-3 py-1.5 rounded-xl bg-black/60 border border-emerald-700 text-white font-mono text-xs"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Ramadan Settings */}
                  <div className="p-5 rounded-2xl bg-black/40 border border-emerald-800 flex flex-col gap-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-amber-300">
                        {t.fields.ramadanActive}
                      </span>
                      <input
                        type="checkbox"
                        checked={formSettings.ramadan.enabled}
                        onChange={(e) =>
                          setFormSettings({
                            ...formSettings,
                            ramadan: { ...formSettings.ramadan, enabled: e.target.checked },
                          })
                        }
                        className="w-6 h-6 rounded accent-amber-400"
                      />
                    </div>

                    <div className="flex items-center justify-between text-xs text-emerald-200">
                      <span>Ramazan ayını takvimden otomatik tespit et</span>
                      <input
                        type="checkbox"
                        checked={formSettings.ramadan.autoDetect}
                        onChange={(e) =>
                          setFormSettings({
                            ...formSettings,
                            ramadan: { ...formSettings.ramadan, autoDetect: e.target.checked },
                          })
                        }
                        className="w-5 h-5 rounded accent-amber-400"
                      />
                    </div>
                  </div>

                  {/* Kandil, Bayram ve Sıralı Geri Sayım Sistemi Bilgi Kartı */}
                  <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-950/40 via-emerald-950/40 to-amber-950/40 border border-amber-600/40 flex flex-col gap-2.5">
                    <div className="flex items-center gap-2 text-amber-300">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span className="text-sm font-bold">
                        Otomatik Kandil, Bayram & Sıralı Geri Sayım Sistemi
                      </span>
                    </div>
                    <p className="text-xs text-emerald-200/90 leading-relaxed">
                      Sistem; <strong>Regaib Kandili, Mîrâc, Berâat, Kadir Gecesi, Mevlid Kandili, Ramazan ve Kurban Bayramları</strong> ile <strong>Üç Ayların Başlangıcını</strong> otomatik olarak tespit eder.
                      Kandil ve bayram günlerinde ekranda <em>altın yaldızlı özel kutlama tebriği</em> gösterilir. Normal günlerde ise kronolojik sırayla sıradaki mübarek vakte geri sayım (örn. <strong>1 Recep Üç Aylar → Regaib Kandili → Mîrâc → Berâat → Ramazan</strong>) ve Ramazan boyunca anlık <strong>İftar / Sahur</strong> geri sayımı ekranda yer alır.
                    </p>
                  </div>


                  {/* Hijri date offset */}
                  <div className="p-4 rounded-xl bg-black/40 border border-emerald-800 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-emerald-200">
                        {t.fields.hijriAdjustment}
                      </span>
                      <p className="text-[11px] text-emerald-400">
                        Yerel hilal gözlemine veya cami heyetinin kararına göre ± gün kaydırın.
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() =>
                          setFormSettings({
                            ...formSettings,
                            hijriDateAdjustment: formSettings.hijriDateAdjustment - 1,
                          })
                        }
                        className="w-7 h-7 rounded bg-emerald-900 font-bold"
                      >
                        -
                      </button>
                      <span className="font-mono font-bold text-amber-300 w-8 text-center text-xs">
                        {formSettings.hijriDateAdjustment > 0
                          ? `+${formSettings.hijriDateAdjustment}`
                          : formSettings.hijriDateAdjustment}
                      </span>
                      <button
                        onClick={() =>
                          setFormSettings({
                            ...formSettings,
                            hijriDateAdjustment: formSettings.hijriDateAdjustment + 1,
                          })
                        }
                        className="w-7 h-7 rounded bg-emerald-900 font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 4: Daily Content (Ayah & Hadith) */}
              {activeTab === 'dailyContent' && (() => {
                const todaySeq = dailyContentService.getTodaySequenceNumber();
                const todayIndex = dailyContentService.getDayIndexForDate();
                const validationReport = dailyContentService.getValidationReport();

                const filteredPairsWithIndex = pairsList
                  .map((pair, index) => ({ pair, index }))
                  .filter(({ pair, index }) => {
                    if (!dailyContentSearch.trim()) return true;
                    const q = dailyContentSearch.toLowerCase();
                    const dayNumber = `${index + 1}`;
                    return (
                      dayNumber.includes(q) ||
                      pair.ayah.reference.toLowerCase().includes(q) ||
                      pair.ayah.surahName.tr.toLowerCase().includes(q) ||
                      pair.ayah.surahName.de.toLowerCase().includes(q) ||
                      pair.ayah.surahName.en.toLowerCase().includes(q) ||
                      pair.ayah.translations.tr.toLowerCase().includes(q) ||
                      pair.ayah.translations.de.toLowerCase().includes(q) ||
                      pair.ayah.translations.en.toLowerCase().includes(q) ||
                      pair.hadith.source.toLowerCase().includes(q) ||
                      (pair.hadith.narrator?.tr && pair.hadith.narrator.tr.toLowerCase().includes(q)) ||
                      pair.hadith.translations.tr.toLowerCase().includes(q) ||
                      pair.hadith.translations.de.toLowerCase().includes(q) ||
                      pair.hadith.translations.en.toLowerCase().includes(q)
                    );
                  });

                const itemsPerPage = 6;
                const totalPages = Math.max(1, Math.ceil(filteredPairsWithIndex.length / itemsPerPage));
                const currentPage = Math.min(Math.max(1, dailyContentPage), totalPages);
                const currentSlice = filteredPairsWithIndex.slice(
                  (currentPage - 1) * itemsPerPage,
                  currentPage * itemsPerPage
                );

                return (
                  <div className="flex flex-col gap-5 max-w-4xl">
                    {/* Header */}
                    <div className="flex items-center justify-between pb-3 border-b border-emerald-800/80">
                      <div>
                        <h3 className="text-lg font-bold text-amber-300 flex items-center gap-2">
                          <BookOpen className="w-5 h-5 text-amber-400" />
                          Günün Âyet ve Hadîs Kütüphanesi
                        </h3>
                        <p className="text-xs text-emerald-300/80 mt-0.5">
                          200 Âyet ve 200 Hadîs tamamen çevrimdışı yerel veri olarak sisteme gömülüdür.
                        </p>
                      </div>
                      <span className="px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/40 text-xs font-mono font-bold text-amber-300">
                        {pairsList.length} / 200 İçerik Çifti
                      </span>
                    </div>

                    {/* Cycle & Verification Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Cycle Status Card */}
                      <div className="p-4 rounded-2xl bg-gradient-to-br from-black/60 to-emerald-950/40 border border-amber-500/30 flex flex-col justify-between gap-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-amber-400" />
                            <span className="text-xs font-bold uppercase tracking-wider text-amber-300">
                              Günün Döngü Sırası
                            </span>
                          </div>
                          <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-[11px] font-bold text-emerald-300">
                            Aktif Döngü
                          </span>
                        </div>
                        <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-black text-amber-400 font-mono">
                            Gün #{todaySeq}
                          </span>
                          <span className="text-xs text-emerald-300 font-mono">
                            / 200 (İndeks: {todayIndex})
                          </span>
                        </div>
                        <div className="text-[11px] text-emerald-200/90 leading-relaxed border-t border-emerald-900/60 pt-2 flex flex-col gap-0.5 font-mono">
                          <div>• Saat Dilimi: <strong>Europe/Berlin (Hamburg)</strong></div>
                          <div>• Başlangıç: <strong>{CONTENT_EPOCH_START}</strong> (Modülo 200)</div>
                          <div>• 200 gün sonra Gün #1'den otomatik ve kesintisiz başa döner.</div>
                        </div>
                      </div>

                      {/* Verification Status Card */}
                      <div className="p-4 rounded-2xl bg-gradient-to-br from-black/60 to-emerald-950/40 border border-emerald-600/40 flex flex-col justify-between gap-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                            <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
                              Doğrulama Raporu
                            </span>
                          </div>
                          <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-[11px] font-bold text-emerald-300">
                            100% Çevrimdışı
                          </span>
                        </div>
                        <div className="flex items-baseline gap-2">
                          <span className="text-lg font-bold text-emerald-300">
                            200 Âyet & 200 Hadîs
                          </span>
                          <span className="text-xs text-amber-400">✓ Onaylandı</span>
                        </div>
                        <div className="text-[11px] text-emerald-200/90 leading-relaxed border-t border-emerald-900/60 pt-2 flex flex-col gap-0.5 font-mono">
                          <div>• Âyet Kütüphanesi: <strong>{validationReport.ayahCount}</strong> (TR, AR, DE, EN)</div>
                          <div>• Hadîs Kütüphanesi: <strong>{validationReport.hadithCount}</strong> (Sahih Kaynaklı)</div>
                          <div>• İnternet kesilse dahi günlük akış sıfır aksamayla sürer.</div>
                        </div>
                      </div>
                    </div>

                    {/* Search & Actions Toolbar */}
                    <div className="p-3.5 rounded-2xl bg-black/40 border border-emerald-800/70 flex flex-wrap items-center justify-between gap-3">
                      {/* Search Input */}
                      <div className="relative flex-1 min-w-[200px]">
                        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-emerald-400" />
                        <input
                          type="text"
                          placeholder="Gün no (#12), sure adı, referans veya metin ara..."
                          value={dailyContentSearch}
                          onChange={(e) => {
                            setDailyContentSearch(e.target.value);
                            setDailyContentPage(1);
                          }}
                          className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-black/60 border border-emerald-700 text-white text-xs placeholder:text-emerald-600 focus:outline-none focus:border-amber-400"
                        />
                      </div>

                      {/* Jump to Today Button */}
                      <button
                        onClick={() => {
                          setDailyContentSearch('');
                          const targetPage = Math.ceil(todaySeq / itemsPerPage);
                          setDailyContentPage(targetPage);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold transition flex items-center gap-1.5"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        Bugünün Çiftine Git (Gün #{todaySeq})
                      </button>

                      {/* Language Preview Switcher */}
                      <div className="flex items-center gap-1 bg-black/60 p-1 rounded-xl border border-emerald-800">
                        <span className="text-[10px] uppercase font-bold text-emerald-400 px-1">Önizleme:</span>
                        {(['tr', 'ar', 'de', 'en'] as Language[]).map((lang) => (
                          <button
                            key={lang}
                            onClick={() => setDailyContentDetailLang(lang)}
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase transition ${
                              dailyContentDetailLang === lang
                                ? 'bg-amber-400 text-black shadow'
                                : 'text-emerald-300 hover:text-white'
                            }`}
                          >
                            {lang}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Items List */}
                    <div className="flex flex-col gap-4">
                      {currentSlice.length === 0 ? (
                        <div className="p-8 text-center text-xs text-emerald-400 rounded-2xl bg-black/40 border border-emerald-800">
                          Arama kriterinize uygun kayıt bulunamadı.
                        </div>
                      ) : (
                        currentSlice.map(({ pair, index }) => {
                          const isToday = index + 1 === todaySeq;
                          return (
                            <div
                              key={pair.id}
                              className={`p-4 rounded-2xl bg-black/40 border transition ${
                                isToday
                                  ? 'border-amber-400 ring-2 ring-amber-400/30 bg-amber-950/20'
                                  : 'border-emerald-800 hover:border-emerald-700'
                              } flex flex-col gap-3`}
                            >
                              {/* Pair Header */}
                              <div className="flex items-center justify-between pb-2 border-b border-emerald-900">
                                <div className="flex items-center gap-2">
                                  <span className="font-mono font-bold text-amber-300 text-xs">
                                    Gün #{index + 1} / 200
                                  </span>
                                  {isToday && (
                                    <span className="px-2 py-0.5 rounded-full bg-amber-400 text-black text-[10px] font-extrabold animate-pulse">
                                      ★ BUGÜN EKRANDA GÖSTERİLEN İÇERİK
                                    </span>
                                  )}
                                </div>
                                <span className="font-mono text-[11px] text-emerald-400">
                                  {pair.ayah.reference} · {pair.hadith.source}
                                </span>
                              </div>

                              {/* Ayah & Hadith Grid */}
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                                {/* Ayah Box */}
                                <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40 flex flex-col gap-2">
                                  <div className="flex items-center justify-between text-[11px]">
                                    <span className="font-bold text-amber-300 uppercase tracking-wider text-[10px]">
                                      ÂYET-İ KERÎME
                                    </span>
                                    <span className="text-emerald-300 font-medium">
                                      {pair.ayah.surahName[dailyContentDetailLang]} {pair.ayah.surahNumber ? `(${pair.ayah.surahNumber}:${pair.ayah.ayahNumber})` : `(${pair.ayah.ayahNumber}. Âyet)`}
                                    </span>
                                  </div>
                                  <p className="font-arabic text-sm text-right text-amber-100/90 leading-relaxed" dir="rtl">
                                    {pair.ayah.arabic}
                                  </p>
                                  <p className="text-emerald-100 text-xs leading-relaxed border-t border-emerald-900/60 pt-2">
                                    {pair.ayah.translations[dailyContentDetailLang] || pair.ayah.translations.tr}
                                  </p>
                                  <span className="text-[10px] text-emerald-400/80 font-mono mt-auto">
                                    {pair.ayah.reference}
                                  </span>
                                </div>

                                {/* Hadith Box */}
                                <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40 flex flex-col gap-2">
                                  <div className="flex items-center justify-between text-[11px]">
                                    <span className="font-bold text-teal-300 uppercase tracking-wider text-[10px]">
                                      HADÎS-İ ŞERÎF
                                    </span>
                                    <span className="text-teal-300 font-medium truncate max-w-[180px]">
                                      {pair.hadith.narrator ? `Râvi: ${pair.hadith.narrator[dailyContentDetailLang] || pair.hadith.narrator.tr}` : ''}
                                    </span>
                                  </div>
                                  <p className="font-arabic text-sm text-right text-teal-100/90 leading-relaxed" dir="rtl">
                                    {pair.hadith.arabic}
                                  </p>
                                  <p className="text-emerald-100 text-xs leading-relaxed border-t border-emerald-900/60 pt-2">
                                    {pair.hadith.translations[dailyContentDetailLang] || pair.hadith.translations.tr}
                                  </p>
                                  <span className="text-[10px] text-teal-400/80 font-mono mt-auto">
                                    {pair.hadith.source}
                                  </span>
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>

                    {/* Pagination Controls */}
                    {totalPages > 1 && (
                      <div className="flex items-center justify-between pt-2 border-t border-emerald-800/70">
                        <span className="text-xs text-emerald-400 font-mono">
                          Kayıt {((currentPage - 1) * itemsPerPage) + 1} - {Math.min(currentPage * itemsPerPage, filteredPairsWithIndex.length)} / {filteredPairsWithIndex.length}
                        </span>
                        <div className="flex items-center gap-2">
                          <button
                            disabled={currentPage <= 1}
                            onClick={() => setDailyContentPage((p) => Math.max(1, p - 1))}
                            className="p-1.5 rounded-lg bg-black/60 border border-emerald-700 text-emerald-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed text-xs flex items-center gap-1"
                          >
                            <ChevronLeft className="w-4 h-4" /> Önceki
                          </button>
                          <span className="px-3 py-1 rounded-lg bg-black/80 border border-emerald-800 font-mono text-xs text-amber-300">
                            Sayfa {currentPage} / {totalPages}
                          </span>
                          <button
                            disabled={currentPage >= totalPages}
                            onClick={() => setDailyContentPage((p) => Math.min(totalPages, p + 1))}
                            className="p-1.5 rounded-lg bg-black/60 border border-emerald-700 text-emerald-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed text-xs flex items-center gap-1"
                          >
                            Sonraki <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Tab 5: Announcements */}
              {activeTab === 'announcements' && (
                <div className="flex flex-col gap-6 max-w-4xl">
                  <div className="flex items-center justify-between pb-2 border-b border-emerald-800/80">
                    <h3 className="text-lg font-bold text-amber-300">
                      Cami Duyuruları Yönetimi
                    </h3>
                    <button
                      onClick={() => {
                        const newAnn: Announcement = {
                          id: `ann-${Date.now()}`,
                          title: {
                            tr: 'Yeni Cami Duyurusu',
                            ar: 'إعلان جديد',
                            de: 'Neue Mitteilung',
                            en: 'New Announcement',
                          },
                          content: {
                            tr: 'Duyuru metnini buraya yazınız.',
                            ar: 'نص الإعلان هنا.',
                            de: 'Mitteilungstext hier eingeben.',
                            en: 'Announcement text here.',
                          },
                          startDate: new Date().toISOString().split('T')[0],
                          endDate: '2027-12-31',
                          priority: 'normal',
                          displayType: 'ticker',
                          active: true,
                          durationSeconds: 15,
                        };
                        setAnnsList([...annsList, newAnn]);
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                    >
                      <Plus className="w-4 h-4" /> Yeni Duyuru Ekle
                    </button>
                  </div>

                  <div className="flex flex-col gap-4">
                    {annsList.map((ann, idx) => (
                      <div
                        key={ann.id}
                        className="p-4 rounded-2xl bg-black/40 border border-emerald-800 flex flex-col gap-3"
                      >
                        <div className="flex items-center justify-between pb-2 border-b border-emerald-900">
                          <div className="flex items-center gap-3">
                            <input
                              type="checkbox"
                              checked={ann.active}
                              onChange={(e) => {
                                const updated = [...annsList];
                                updated[idx].active = e.target.checked;
                                setAnnsList(updated);
                              }}
                              className="w-5 h-5 rounded accent-amber-400"
                            />
                            <span className="font-bold text-amber-300 text-xs">
                              {ann.title.tr || 'Başlıksız'}
                            </span>
                          </div>

                          <button
                            onClick={() => {
                              if (confirm('Bu duyuruyu silmek istediğinize emin misiniz?')) {
                                setAnnsList(annsList.filter((a) => a.id !== ann.id));
                              }
                            }}
                            className="p-1.5 text-rose-400 hover:text-rose-300"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="grid grid-cols-2 gap-3 text-xs">
                          <div>
                            <label className="block text-[10px] font-bold text-emerald-300 mb-1">
                              Başlık (TR)
                            </label>
                            <input
                              type="text"
                              value={ann.title.tr}
                              onChange={(e) => {
                                const updated = [...annsList];
                                updated[idx].title.tr = e.target.value;
                                setAnnsList(updated);
                              }}
                              className="w-full px-3 py-1.5 rounded-xl bg-black/60 border border-emerald-700 text-white text-xs"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-emerald-300 mb-1">
                              Başlık (DE)
                            </label>
                            <input
                              type="text"
                              value={ann.title.de}
                              onChange={(e) => {
                                const updated = [...annsList];
                                updated[idx].title.de = e.target.value;
                                setAnnsList(updated);
                              }}
                              className="w-full px-3 py-1.5 rounded-xl bg-black/60 border border-emerald-700 text-white text-xs"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold text-emerald-300 mb-1">
                            Duyuru Metni (TR)
                          </label>
                          <textarea
                            rows={2}
                            value={ann.content.tr}
                            onChange={(e) => {
                              const updated = [...annsList];
                              updated[idx].content.tr = e.target.value;
                              setAnnsList(updated);
                            }}
                            className="w-full px-3 py-1.5 rounded-xl bg-black/60 border border-emerald-700 text-white text-xs resize-none"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tab 6: Animations & TV Behavior */}
              {activeTab === 'animations' && (
                <div className="flex flex-col gap-6 max-w-3xl">
                  <h3 className="text-lg font-bold text-amber-300 pb-2 border-b border-emerald-800/80">
                    Namaz Vakti Animasyonları & TV Davranışı
                  </h3>

                  <div className="p-5 rounded-2xl bg-black/40 border border-emerald-800 flex flex-col gap-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-sm font-bold text-amber-300">
                          {t.fields.enableAnimation}
                        </span>
                        <p className="text-xs text-emerald-300/80">
                          Ezan vakti girdiğinde TV ekranı otomatik olarak tefekkür moduna (Ayet → Hadis) geçer.
                        </p>
                      </div>
                      <input
                        type="checkbox"
                        checked={formSettings.enablePrayerSequence}
                        onChange={(e) =>
                          setFormSettings({
                            ...formSettings,
                            enablePrayerSequence: e.target.checked,
                          })
                        }
                        className="w-6 h-6 rounded accent-amber-400"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-3 border-t border-emerald-900/60">
                      <div>
                        <label className="block text-xs font-semibold text-emerald-200 mb-1">
                          {t.fields.ayahDuration}
                        </label>
                        <input
                          type="number"
                          min={10}
                          max={120}
                          value={formSettings.ayahDisplaySeconds}
                          onChange={(e) =>
                            setFormSettings({
                              ...formSettings,
                              ayahDisplaySeconds: parseInt(e.target.value, 10) || 25,
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-black/60 border border-emerald-700 text-amber-300 font-mono text-xs font-bold"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-emerald-200 mb-1">
                          {t.fields.hadithDuration}
                        </label>
                        <input
                          type="number"
                          min={10}
                          max={120}
                          value={formSettings.hadithDisplaySeconds}
                          onChange={(e) =>
                            setFormSettings({
                              ...formSettings,
                              hadithDisplaySeconds: parseInt(e.target.value, 10) || 25,
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-black/60 border border-emerald-700 text-amber-300 font-mono text-xs font-bold"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Test button */}
                  <div className="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-700 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-emerald-100">
                        {t.testPrayerSequence}
                      </span>
                      <p className="text-[11px] text-emerald-300/80">
                        Ezan vaktinde ekranın nasıl görüneceğini hemen şimdi test edebilirsiniz.
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        onClose();
                        onTriggerTestSequence();
                      }}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold text-xs shadow-md transition-all focus:ring-2 focus:ring-amber-400"
                    >
                      <Play className="w-4 h-4" />
                      <span>Hemen Test Et</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Tab 7: Android TV APK & Source Code Package */}
              {activeTab === 'androidTv' && (
                <div className="flex flex-col gap-6 max-w-3xl">
                  <div className="flex items-center gap-3 pb-2 border-b border-emerald-800/80">
                    <div className="p-2 rounded-xl bg-amber-400/20 text-amber-300">
                      <Tv className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-amber-300 font-cinzel">
                        Android TV (Leanback) & Google TV Proje Paketi
                      </h3>
                      <p className="text-xs text-emerald-300/80">
                        Hamburg WSB Mescidi Televizyonları için APK Derleme ve Kurulum
                      </p>
                    </div>
                  </div>

                  {/* Download Action Box */}
                  <div className="p-6 rounded-2xl bg-gradient-to-br from-emerald-950 via-black/80 to-[#021814] border-2 border-amber-400/50 shadow-xl flex flex-col gap-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-base font-bold text-amber-300">
                          Eksiksiz Android Studio TV Projesini İndir
                        </span>
                        <p className="text-xs text-emerald-200 mt-1 max-w-xl">
                          Bu ZIP paketi; Android TV Leanback Manifesti, KeepScreenOn (7/24 ekran açık tutma),
                          otomatik cihaz açılışında başlama (BootReceiver), D-Pad TV kumanda kodları ve offline
                          çalışma dosyalarının tamamını içerir.
                        </p>
                      </div>
                      <a
                        href="/wsb-hamburg-android-tv-project.zip"
                        download="wsb-hamburg-android-tv-project.zip"
                        className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black text-sm shadow-xl transition-all scale-105 active:scale-95 shrink-0"
                      >
                        <Download className="w-5 h-5 text-emerald-950" />
                        <span>ZIP İndir</span>
                      </a>
                    </div>
                  </div>

                  {/* Step by Step Guide */}
                  <div className="flex flex-col gap-3 p-5 rounded-2xl bg-black/40 border border-emerald-800 text-xs">
                    <h4 className="font-bold text-amber-300 uppercase tracking-wider">
                      Nasıl Kurulur & APK Nasıl Alınır?
                    </h4>

                    <ol className="list-decimal list-inside space-y-2 text-emerald-100">
                      <li>
                        <strong>Android Studio'da Açma:</strong> Yukarıdaki ZIP dosyasını bilgisayarınızda çıkartın. Android Studio programını açıp <code>Open</code> seçeneğiyle bu klasörü seçin.
                      </li>
                      <li>
                        <strong>Tek Tıkla APK Üretme:</strong> Üst menüden <code>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</code> seçeneğine tıklayın veya terminalde <code>./gradlew assembleRelease</code> komutunu çalıştırın.
                      </li>
                      <li>
                        <strong>USB ile TV'ye Yükleme:</strong> Oluşan <code>app-debug.apk</code> dosyasını bir USB belleğe atarak Android TV'ye takın ve yükleyin.
                      </li>
                      <li>
                        <strong>Doğrudan TV'de Açma (Alternatif):</strong> Android TV'nize Google Play Store'dan <strong>"Downloader"</strong> uygulamasını kurup bu web uygulamasının adresini girerek anında tam ekran çalıştırabilirsiniz.
                      </li>
                    </ol>
                  </div>
                </div>
              )}

              {/* Tab 8: Backup & Security */}
              {activeTab === 'backup' && (
                <div className="flex flex-col gap-6 max-w-3xl">
                  <h3 className="text-lg font-bold text-amber-300 pb-2 border-b border-emerald-800/80">
                    Yedekleme, Geri Yükleme ve Güvenlik
                  </h3>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-5 rounded-2xl bg-black/40 border border-emerald-800 flex flex-col justify-between gap-3">
                      <div>
                        <span className="text-sm font-bold text-emerald-100">
                          {t.exportSettings}
                        </span>
                        <p className="text-xs text-emerald-300/80 mt-1">
                          Tüm mescid ayarlarını, namaz ofsetlerini ve duyuruları tek bir JSON dosyası olarak bilgisayarınıza indirin.
                        </p>
                      </div>
                      <button
                        onClick={handleExportJson}
                        className="flex items-center justify-center gap-2 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs"
                      >
                        <Download className="w-4 h-4" />
                        <span>{t.exportSettings}</span>
                      </button>
                    </div>

                    <div className="p-5 rounded-2xl bg-black/40 border border-emerald-800 flex flex-col justify-between gap-3">
                      <div>
                        <span className="text-sm font-bold text-emerald-100">
                          {t.importSettings}
                        </span>
                        <p className="text-xs text-emerald-300/80 mt-1">
                          Önceden aldığınız bir JSON yedek dosyasını yükleyerek tüm ayarları geri getirin.
                        </p>
                      </div>
                      <label className="flex items-center justify-center gap-2 py-2 rounded-xl bg-teal-800 hover:bg-teal-700 text-white font-bold text-xs cursor-pointer">
                        <Upload className="w-4 h-4" />
                        <span>Dosya Seç ve Yükle</span>
                        <input
                          type="file"
                          accept=".json"
                          onChange={handleImportJson}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>

                  {/* Change PIN */}
                  <div className="p-5 rounded-2xl bg-black/40 border border-emerald-800 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-emerald-100">
                        {t.fields.adminPin}
                      </span>
                      <p className="text-[11px] text-emerald-400">
                        Yönetici paneli giriş PIN şifresini değiştirin (4 haneli).
                      </p>
                    </div>
                    <input
                      type="text"
                      maxLength={8}
                      value={formSettings.adminPin}
                      onChange={(e) =>
                        setFormSettings({ ...formSettings, adminPin: e.target.value })
                      }
                      className="w-28 px-3 py-1.5 rounded-xl bg-black/60 border border-emerald-700 text-amber-300 font-mono text-center font-bold text-sm"
                    />
                  </div>

                  {/* Reset Defaults */}
                  <div className="p-4 rounded-xl bg-rose-950/30 border border-rose-800/40 flex items-center justify-between">
                    <span className="text-xs font-bold text-rose-300">
                      {t.resetDefaults}
                    </span>
                    <button
                      onClick={handleResetDefaults}
                      className="px-4 py-1.5 rounded-xl bg-rose-800 hover:bg-rose-700 text-white font-bold text-xs"
                    >
                      Sıfırla
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
