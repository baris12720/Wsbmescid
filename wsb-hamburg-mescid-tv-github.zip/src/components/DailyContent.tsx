import React from 'react';
import { BookOpen, HeartHandshake } from 'lucide-react';
import { DailyPair, Language } from '../types';
import { TRANSLATIONS } from '../i18n/translations';

interface DailyContentProps {
  pair: DailyPair;
  currentLanguage: Language;
}

export const DailyContent: React.FC<DailyContentProps> = ({ pair, currentLanguage }) => {
  const t = TRANSLATIONS[currentLanguage];
  const isArabic = currentLanguage === 'ar';

  const ayahTranslation = pair.ayah.translations[currentLanguage] || pair.ayah.translations.tr;
  const ayahSurah = pair.ayah.surahName[currentLanguage] || pair.ayah.surahName.tr;

  const hadithTranslation = pair.hadith.translations[currentLanguage] || pair.hadith.translations.tr;
  const hadithNarrator = pair.hadith.narrator
    ? pair.hadith.narrator[currentLanguage] || pair.hadith.narrator.tr
    : undefined;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5 lg:gap-4 w-full flex-1 min-h-0">
      {/* 1. Verse of the Day (Günün Ayeti) */}
      <div className="relative flex flex-col justify-between p-3.5 sm:p-4 lg:p-5 rounded-2xl bg-gradient-to-br from-emerald-950/85 via-black/75 to-[#021814]/90 border border-emerald-800/60 shadow-xl overflow-hidden min-h-[220px] lg:min-h-0 h-full">
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-400/5 rounded-full blur-2xl pointer-events-none" />

        {/* 1.1 Header: Icon, Title & Surah Badge */}
        <div className="flex items-center justify-between pb-2.5 border-b border-emerald-900/60 gap-2 shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <div className="p-1.5 rounded-lg bg-amber-400/20 text-amber-300 shrink-0">
              <BookOpen className="w-4 h-4" />
            </div>
            <span className="text-xs sm:text-sm font-black tracking-widest text-amber-300 uppercase font-cinzel truncate">
              {t.dailyVerse}
            </span>
          </div>
          <span className="px-2.5 py-0.5 text-xs font-bold text-emerald-300 bg-emerald-900/50 border border-emerald-700/50 rounded-full font-mono shrink-0">
            {ayahSurah} : {pair.ayah.ayahNumber}
          </span>
        </div>

        {/* 1.2 Middle: Arabic Verse & Translation in separate distinct vertical blocks */}
        <div className="flex flex-col justify-center gap-2.5 py-2.5 flex-1 min-h-0 overflow-y-auto">
          {/* Arabic Text Block */}
          <div
            dir="rtl"
            className="text-right font-arabic text-lg sm:text-xl lg:text-2xl font-bold leading-relaxed text-amber-100/95 tracking-wide px-1 drop-shadow-sm select-text"
          >
            {pair.ayah.arabic}
          </div>

          {/* Translation Block - Distinct beneath Arabic */}
          <div
            dir={isArabic ? 'rtl' : 'ltr'}
            className="text-xs sm:text-sm lg:text-base font-medium leading-relaxed text-emerald-100/90 py-1.5 px-3 rounded-xl bg-black/40 border-l-2 border-amber-400/70 italic select-text"
          >
            "{ayahTranslation}"
          </div>
        </div>

        {/* 1.3 Footer: Citation & Islamic Honorific */}
        <div className="flex items-center justify-between pt-2 border-t border-emerald-900/50 text-[11px] sm:text-xs text-emerald-400/80 font-semibold gap-2 shrink-0">
          <span className="truncate">{pair.ayah.reference}</span>
          <span className="font-arabic text-amber-300/80 text-xs shrink-0">صَدَقَ اللّٰهُ الْعَظِيمُ</span>
        </div>
      </div>

      {/* 2. Hadith of the Day (Günün Hadisi) */}
      <div className="relative flex flex-col justify-between p-3.5 sm:p-4 lg:p-5 rounded-2xl bg-gradient-to-br from-emerald-950/85 via-black/75 to-[#021814]/90 border border-emerald-800/60 shadow-xl overflow-hidden min-h-[220px] lg:min-h-0 h-full">
        <div className="absolute top-0 right-0 w-32 h-32 bg-teal-400/5 rounded-full blur-2xl pointer-events-none" />

        {/* 2.1 Header: Icon, Title & Narrator Badge */}
        <div className="flex items-center justify-between pb-2.5 border-b border-emerald-900/60 gap-2 shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <div className="p-1.5 rounded-lg bg-teal-400/20 text-teal-300 shrink-0">
              <HeartHandshake className="w-4 h-4" />
            </div>
            <span className="text-xs sm:text-sm font-black tracking-widest text-teal-300 uppercase font-cinzel truncate">
              {t.dailyHadith}
            </span>
          </div>
          {hadithNarrator && (
            <span className="px-2.5 py-0.5 text-xs font-bold text-emerald-200 bg-emerald-900/50 border border-emerald-700/50 rounded-full shrink-0 truncate max-w-[150px] sm:max-w-none">
              {hadithNarrator}
            </span>
          )}
        </div>

        {/* 2.2 Middle: Arabic Hadith & Translation in separate distinct vertical blocks */}
        <div className="flex flex-col gap-3 py-2.5 flex-1 min-h-0 overflow-y-auto">
          {/* Arabic Text Block */}
          <div
            dir="rtl"
            className="text-right font-arabic text-base sm:text-lg lg:text-xl font-bold leading-[1.65] text-emerald-100 tracking-wide px-1 drop-shadow-sm select-text break-words mb-1"
          >
            {pair.hadith.arabic}
          </div>

          {/* Translation Block - Distinct beneath Arabic with proper line height */}
          <div
            dir={isArabic ? 'rtl' : 'ltr'}
            className="text-xs sm:text-sm font-medium leading-[1.55] text-emerald-100/90 py-2 px-3 rounded-xl bg-black/40 border-l-2 border-teal-400/70 italic select-text break-words mb-2"
          >
            "{hadithTranslation}"
          </div>

          {/* 2.3 Citation & Islamic Salawat - Normal flow below meal with min 12px gap, non-monospace, 0.8em, opacity 0.7 */}
          <div
            className="w-full pt-2 border-t border-emerald-900/50 text-emerald-400/70 font-sans mt-auto shrink-0 flex items-center justify-between flex-wrap gap-2"
            style={{ marginTop: '13px', fontSize: '0.8em', lineHeight: 1.5 }}
          >
            <span className="break-words [text-wrap:balance] select-text">{pair.hadith.source}</span>
            <span className="font-arabic text-amber-300/80 text-xs shrink-0 select-none">ﷺ عَلَيْهِ الصَّلَاةُ وَالسَّلَامُ</span>
          </div>
        </div>
      </div>
    </div>
  );
};
