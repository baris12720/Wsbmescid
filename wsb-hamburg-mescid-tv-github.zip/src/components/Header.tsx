import React, { useState } from 'react';
import { Wifi, WifiOff, ShieldCheck, Settings, Globe, Moon } from 'lucide-react';
import { Language, MosqueSettings } from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { hijriService } from '../services/hijriService';

interface HeaderProps {
  currentTime: Date;
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  isOnline: boolean;
  isWakeLocked: boolean;
  settings: MosqueSettings;
  onOpenAdmin: () => void;
  autoRotateSecondsLeft?: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTime,
  currentLanguage,
  onLanguageChange,
  isOnline,
  isWakeLocked,
  settings,
  onOpenAdmin,
  autoRotateSecondsLeft,
}) => {
  const [logoFailed, setLogoFailed] = useState<boolean>(false);
  const t = TRANSLATIONS[currentLanguage];

  // Format local digital time (strictly 24-hour standard digits)
  const timeFormatted = new Intl.DateTimeFormat('de-DE', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).format(currentTime);

  // Format Gregorian date
  const gregorianDateFormatted = new Intl.DateTimeFormat(
    currentLanguage === 'ar' ? 'ar-SA' : currentLanguage === 'de' ? 'de-DE' : currentLanguage === 'en' ? 'en-GB' : 'tr-TR',
    { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }
  ).format(currentTime);

  // Format Hijri date with configured offset
  const hijriFormatted = hijriService.formatHijriDate(
    currentTime,
    currentLanguage,
    settings.hijriDateAdjustment
  );

  const languages: { code: Language; label: string; native: string }[] = [
    { code: 'tr', label: 'TR', native: 'Türkçe' },
    { code: 'ar', label: 'العربية', native: 'العربية' },
    { code: 'de', label: 'DE', native: 'Deutsch' },
    { code: 'en', label: 'EN', native: 'English' },
  ];

  return (
    <header className="relative z-10 w-full px-4 sm:px-6 lg:px-8 py-2.5 lg:py-3.5 bg-gradient-to-b from-[#021814]/95 via-[#03231d]/90 to-transparent border-b border-emerald-900/50 backdrop-blur-md">
      {/* 1. Large TV / Desktop Layout (lg and above: 16:9 1080p / 768p) */}
      <div className="hidden lg:flex items-center justify-between gap-4">
        {/* Left: Official WSB Hamburg Logo & Brand */}
        <div className="flex items-center gap-3.5 min-w-0 shrink-0">
          {!logoFailed ? (
            <img
              src="/assets/logo/wsb-logo.png"
              alt="WSB Hamburg"
              onError={() => setLogoFailed(true)}
              className="w-14 h-14 xl:w-16 xl:h-16 object-contain select-none filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)] shrink-0"
              loading="eager"
            />
          ) : (
            <div className="flex items-center justify-center px-3.5 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-700/60 font-cinzel font-bold text-amber-300 text-sm tracking-wider select-none shrink-0">
              WSB Hamburg
            </div>
          )}

          <div className="min-w-0">
            <div className="flex items-center gap-2.5">
              <h1 className="text-xl xl:text-2xl font-black tracking-wider text-amber-300 drop-shadow-sm font-cinzel whitespace-nowrap">
                {settings.mosqueName}
              </h1>
              <span className="px-2 py-0.5 text-[11px] font-bold tracking-widest text-emerald-300 bg-emerald-950/80 border border-emerald-700/60 rounded-full shrink-0">
                HAMBURG
              </span>
            </div>
            <p className="text-xs font-medium tracking-wide text-emerald-200/80 truncate max-w-md">
              {settings.mosqueSubName}
            </p>
          </div>
        </div>

        {/* Center: Live Clock & Gregorian / Hijri Dates */}
        <div className="flex flex-col items-center justify-center px-6 py-1 rounded-2xl bg-black/45 border border-emerald-800/40 shadow-inner shrink-0">
          <div className="flex items-baseline gap-2" dir="ltr" style={{ direction: 'ltr' }}>
            <span className="font-mono text-4xl xl:text-5xl font-black tracking-wider text-amber-200 drop-shadow-[0_0_15px_rgba(251,191,36,0.35)] tabular-nums whitespace-nowrap">
              {timeFormatted}
            </span>
            <span className="text-[11px] uppercase tracking-widest text-emerald-400/80 font-bold">
              CET / CEST
            </span>
          </div>

          <div className="flex items-center gap-2.5 text-xs whitespace-nowrap">
            <span className="font-semibold text-emerald-100 capitalize">
              {gregorianDateFormatted}
            </span>
            <span className="text-emerald-500">•</span>
            <span className="flex items-center gap-1 font-semibold text-amber-300/90 font-arabic text-sm">
              <Moon className="w-3.5 h-3.5 text-amber-400" />
              {hijriFormatted}
            </span>
          </div>
        </div>

        {/* Right: Languages, Status Indicators & Admin Trigger */}
        <div className="flex items-center gap-2.5 xl:gap-3 shrink-0">
          {/* Language Switcher */}
          <div className="flex items-center p-1 rounded-xl bg-black/50 border border-emerald-800/50 shadow-md">
            {languages.map((item) => {
              const isSelected = currentLanguage === item.code;
              return (
                <button
                  key={item.code}
                  onClick={() => onLanguageChange(item.code)}
                  title={item.native}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-amber-400 ${
                    isSelected
                      ? 'bg-amber-400 text-emerald-950 shadow-md shadow-amber-500/20 scale-105 font-extrabold'
                      : 'text-emerald-300/80 hover:text-white hover:bg-emerald-900/40'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>

          {/* Auto rotate indicator if active */}
          {settings.autoRotateLanguages && (
            <div
              className="flex items-center gap-1 px-2 py-1 text-[11px] font-medium text-emerald-300/90 bg-emerald-950/60 border border-emerald-800/40 rounded-lg"
              title="Otomatik dil rotasyonu aktif"
            >
              <Globe className="w-3 h-3 text-emerald-400 animate-spin" style={{ animationDuration: '10s' }} />
              <span className="font-mono text-amber-300 text-xs">{autoRotateSecondsLeft}s</span>
            </div>
          )}

          {/* Online/Offline status badge */}
          <div
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-lg border ${
              isOnline
                ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                : 'bg-amber-950/60 border-amber-500/40 text-amber-300'
            }`}
          >
            {isOnline ? (
              <Wifi className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <WifiOff className="w-3.5 h-3.5 text-amber-400" />
            )}
            <span className="text-[11px]">{isOnline ? t.online : t.offline}</span>
          </div>

          {/* Wake Lock Status */}
          <div
            className="flex items-center gap-1 px-2 py-1 text-xs rounded-lg bg-emerald-950/50 border border-emerald-700/30 text-emerald-300/80"
            title={isWakeLocked ? t.screenWakeLockActive : t.screenWakeLockInactive}
          >
            <ShieldCheck className={`w-3.5 h-3.5 ${isWakeLocked ? 'text-amber-400' : 'text-gray-400'}`} />
            <span className="text-[10px]">TV 7/24</span>
          </div>

          {/* Admin Button */}
          <button
            onClick={onOpenAdmin}
            className="p-2 text-emerald-300 transition-all rounded-xl bg-black/40 hover:bg-emerald-900/50 border border-emerald-700/40 hover:border-amber-400/60 hover:text-amber-300 focus:outline-none focus:ring-2 focus:ring-amber-400"
            title={`${t.adminPanel} (TV Kumandası: Menü tuşu veya 'M')`}
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* 2. Mobile & Narrow Screen Layout (< lg: Phones 390x844, Tablets) */}
      <div className="flex lg:hidden flex-col gap-2.5 w-full">
        {/* Top Mobile Row: Logo, Title, Languages & Admin */}
        <div className="flex items-center justify-between gap-2 w-full">
          {/* Logo + Mosque Name */}
          <div className="flex items-center gap-2.5 min-w-0">
            {!logoFailed ? (
              <img
                src="/assets/logo/wsb-logo.png"
                alt="WSB Hamburg"
                onError={() => setLogoFailed(true)}
                className="w-10 h-10 object-contain select-none shrink-0"
              />
            ) : (
              <div className="px-2 py-1 rounded bg-emerald-950 border border-emerald-700 font-cinzel text-amber-300 text-xs font-bold shrink-0">
                WSB
              </div>
            )}
            <div className="min-w-0">
              <h1 className="text-base font-black tracking-wide text-amber-300 font-cinzel truncate">
                WSB HAMBURG
              </h1>
              <p className="text-[10px] text-emerald-300/80 truncate">
                Wilhelmsburg Mescidi
              </p>
            </div>
          </div>

          {/* Languages & Admin button */}
          <div className="flex items-center gap-1.5 shrink-0">
            <div className="flex items-center p-0.5 rounded-lg bg-black/50 border border-emerald-800/50">
              {languages.map((item) => (
                <button
                  key={item.code}
                  onClick={() => onLanguageChange(item.code)}
                  className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                    currentLanguage === item.code
                      ? 'bg-amber-400 text-emerald-950 font-black'
                      : 'text-emerald-300/80'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <button
              onClick={onOpenAdmin}
              className="p-1.5 rounded-lg bg-black/40 border border-emerald-700/40 text-emerald-300"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Bottom Mobile Row: Clock, Dates and Online Indicator */}
        <div className="flex items-center justify-between px-3 py-1.5 rounded-xl bg-black/40 border border-emerald-800/40 text-xs">
          <div className="flex items-baseline gap-1.5" dir="ltr" style={{ direction: 'ltr' }}>
            <span className="font-mono text-2xl font-black text-amber-200 tracking-wider tabular-nums">
              {timeFormatted}
            </span>
            <span className="text-[9px] text-emerald-400 font-bold">CET</span>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-emerald-200 truncate">
            <span>{gregorianDateFormatted}</span>
            <span className="text-emerald-500">•</span>
            <span className="font-arabic text-amber-300 text-xs">{hijriFormatted}</span>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-400' : 'bg-amber-400'}`} />
            <span className="text-[10px] text-emerald-400 font-medium">
              {isOnline ? 'Online' : 'Offline'}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
