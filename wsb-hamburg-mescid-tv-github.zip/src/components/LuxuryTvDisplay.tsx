import React, { useState, useEffect } from 'react';
import {
  Wifi,
  WifiOff,
  ShieldCheck,
  Settings,
  Globe,
  Moon,
  Sun,
  Sunrise,
  Sunset,
  Sparkles,
  BookOpen,
  Calendar,
  Quote,
} from 'lucide-react';
import { Language, MosqueSettings, PrayerTimes, DailyPair } from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { hijriService } from '../services/hijriService';
import { islamicDateService } from '../services/islamicDateService';

interface LuxuryTvDisplayProps {
  timings: PrayerTimes | null;
  activePrayer: keyof PrayerTimes | null;
  nextPrayer: {
    key: keyof PrayerTimes;
    name?: string;
    time: string;
    remainingMinutes: number;
    remainingSeconds: number;
    totalSpanMinutes: number;
    progressPercentage: number;
  } | null;
  currentTime: Date;
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  isOnline: boolean;
  isWakeLocked: boolean;
  settings: MosqueSettings;
  onOpenAdmin: () => void;
  autoRotateSecondsLeft?: number;
  todayPair?: DailyPair | null;
}

export const LuxuryTvDisplay: React.FC<LuxuryTvDisplayProps> = ({
  timings,
  activePrayer,
  nextPrayer,
  currentTime,
  currentLanguage,
  onLanguageChange,
  isOnline,
  isWakeLocked,
  settings,
  onOpenAdmin,
  autoRotateSecondsLeft,
  todayPair,
}) => {
  const [logoFailed, setLogoFailed] = useState<boolean>(false);
  const t = TRANSLATIONS[currentLanguage];

  // Live Hamburg Clock formatting (strictly standard 24-hour CET)
  const timeFormatted = new Intl.DateTimeFormat('de-DE', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
    timeZone: 'Europe/Berlin',
  }).format(currentTime);

  // Gregorian date formatting
  const gregorianFormatted = new Intl.DateTimeFormat(
    currentLanguage === 'ar' ? 'ar-SA' : currentLanguage === 'de' ? 'de-DE' : currentLanguage === 'en' ? 'en-US' : 'tr-TR',
    { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }
  ).format(currentTime);

  // Hijri date formatting
  const hijriFormatted = hijriService.formatHijriDate(
    currentTime,
    currentLanguage,
    settings.hijriDateAdjustment
  );

  // Islamic Special Day / Kandil detection via islamicDateService
  const specialEvent = islamicDateService.getActiveSpecialDay(
    currentTime,
    settings.hijriDateAdjustment
  );

  // Sequential Upcoming Holy Milestones
  const sequentialMilestones = islamicDateService.getUpcomingMilestones(
    currentTime,
    settings.hijriDateAdjustment
  );

  // Real-time Ramadan Fasting Countdown
  const ramadanCountdown = islamicDateService.getRamadanCountdown(
    currentTime,
    timings,
    settings.hijriDateAdjustment,
    settings.ramadan.enabled
  );

  // Determine current focus prayer
  const focusPrayerKey: keyof PrayerTimes = (nextPrayer?.key || activePrayer || 'Dhuhr') as keyof PrayerTimes;

  // Adhan (Ezan saati) for the focus prayer
  const focusAdhanTime = timings ? timings[focusPrayerKey] || '--:--' : '--:--';

  // Table rows definition: ALL 6 prayers (Fajr, Sunrise, Dhuhr, Asr, Maghrib, Isha)
  const prayerRows: { key: keyof PrayerTimes; name: string; icon: React.ReactNode }[] = [
    { key: 'Fajr', name: t.prayers.fajr, icon: <Sunrise className="w-5 h-5 text-[#8E630D]" /> },
    { key: 'Sunrise', name: t.prayers.sunrise, icon: <Sun className="w-5 h-5 text-[#8E630D]/75" /> },
    { key: 'Dhuhr', name: t.prayers.dhuhr, icon: <Sun className="w-5 h-5 text-[#8E630D]" /> },
    { key: 'Asr', name: t.prayers.asr, icon: <Sun className="w-5 h-5 text-[#8E630D]" /> },
    { key: 'Maghrib', name: t.prayers.maghrib, icon: <Sunset className="w-5 h-5 text-[#8E630D]" /> },
    { key: 'Isha', name: t.prayers.isha, icon: <Moon className="w-5 h-5 text-[#8E630D]" /> },
  ];

  const languages: { code: Language; label: string }[] = [
    { code: 'tr', label: 'TR' },
    { code: 'ar', label: 'عربي' },
    { code: 'de', label: 'DE' },
    { code: 'en', label: 'EN' },
  ];

  // Localized titles
  const ayahCardTitle = {
    tr: 'GÜNÜN ÂYET-İ KERÎMESİ',
    ar: 'آية اليوم الكريمة',
    de: 'VERS DES TAGES',
    en: 'VERSE OF THE DAY',
  }[currentLanguage];

  const hadithCardTitle = {
    tr: 'GÜNÜN HADÎS-İ ŞERÎFİ',
    ar: 'الحديث النبوي الشريف',
    de: 'HADITH DES TAGES',
    en: 'NOBLE HADITH OF THE DAY',
  }[currentLanguage];

  const prophetCitation = {
    tr: 'Hz. Muhammed (s.a.v.)',
    ar: 'قَالَ رَسُولُ اللَّهِ ﷺ',
    de: 'Prophet Muhammad ﷺ',
    en: 'Prophet Muhammad ﷺ',
  }[currentLanguage];

  // Ayah texts
  const ayahMealText = todayPair?.ayah
    ? (todayPair.ayah.translations[currentLanguage] || todayPair.ayah.translations.tr)
    : '';
  const ayahArabicText = todayPair?.ayah?.arabic || '';

  // Hadith texts
  const hadithMealText = todayPair?.hadith
    ? (todayPair.hadith.translations[currentLanguage] || todayPair.hadith.translations.tr)
    : '';
  const hadithArabicText = todayPair?.hadith?.arabic || '';
  const hadithNarratorText = todayPair?.hadith?.narrator
    ? (todayPair.hadith.narrator[currentLanguage] || todayPair.hadith.narrator.tr)
    : '';
  const hadithSourceText = todayPair?.hadith?.source || '';

  // Determine if Ayah needs 2-page rotation
  // When text is long (Arabic > 60 chars or Meal > 90 chars or combined > 130), split into 2 pages
  // Page 0: Arabic text (>= 44px)
  // Page 1: Translation / Meal (>= 30px)
  const ayahNeedsPagination = Boolean(
    ayahArabicText &&
    ayahMealText &&
    (ayahArabicText.length > 55 || ayahMealText.length > 85 || (ayahArabicText.length + ayahMealText.length) > 130)
  );

  // Determine if Hadith needs 2-page rotation
  const hadithNeedsPagination = Boolean(
    hadithArabicText &&
    hadithMealText &&
    (hadithArabicText.length > 55 || hadithMealText.length > 85 || (hadithArabicText.length + hadithMealText.length) > 130)
  );

  // Pagination states: 12 seconds per page
  const [ayahPageIndex, setAyahPageIndex] = useState<number>(0);
  const [ayahFade, setAyahFade] = useState<'in' | 'out'>('in');

  const [hadithPageIndex, setHadithPageIndex] = useState<number>(0);
  const [hadithFade, setHadithFade] = useState<'in' | 'out'>('in');

  // 12-second pagination timer for Ayah
  useEffect(() => {
    if (!ayahNeedsPagination) {
      setAyahPageIndex(0);
      return;
    }
    const interval = setInterval(() => {
      setAyahFade('out');
      setTimeout(() => {
        setAyahPageIndex((prev) => (prev === 0 ? 1 : 0));
        setAyahFade('in');
      }, 350);
    }, 12000); // 12 seconds per page

    return () => clearInterval(interval);
  }, [ayahNeedsPagination, currentLanguage, todayPair?.ayah?.id]);

  // 12-second pagination timer for Hadith
  useEffect(() => {
    if (!hadithNeedsPagination) {
      setHadithPageIndex(0);
      return;
    }
    const interval = setInterval(() => {
      setHadithFade('out');
      setTimeout(() => {
        setHadithPageIndex((prev) => (prev === 0 ? 1 : 0));
        setHadithFade('in');
      }, 350);
    }, 12000); // 12 seconds per page

    return () => clearInterval(interval);
  }, [hadithNeedsPagination, currentLanguage, todayPair?.hadith?.id]);

  // Dynamic font sizing (strictly obeying Arabic >= 44px, Meal >= 30px, Source >= 24px)
  const getAyahArabicFontSize = () => {
    if (ayahNeedsPagination) {
      if (ayahArabicText.length > 140) return 'text-[44px]';
      if (ayahArabicText.length > 90) return 'text-[48px]';
      return 'text-[52px]';
    }
    return 'text-[44px]';
  };

  const getAyahMealFontSize = () => {
    if (ayahNeedsPagination) {
      if (ayahMealText.length > 160) return 'text-[30px]';
      if (ayahMealText.length > 100) return 'text-[32px]';
      return 'text-[36px]';
    }
    return 'text-[30px]';
  };

  const getHadithArabicFontSize = () => {
    if (hadithNeedsPagination) {
      if (hadithArabicText.length > 140) return 'text-[44px]';
      if (hadithArabicText.length > 90) return 'text-[48px]';
      return 'text-[52px]';
    }
    return 'text-[44px]';
  };

  const getHadithMealFontSize = () => {
    if (hadithNeedsPagination) {
      if (hadithMealText.length > 160) return 'text-[30px]';
      if (hadithMealText.length > 100) return 'text-[32px]';
      return 'text-[36px]';
    }
    return 'text-[30px]';
  };

  return (
    <div
      dir="ltr"
      style={{ direction: 'ltr', width: 1872, height: 936 }}
      className="w-[1872px] h-[936px] flex gap-[28px] overflow-hidden select-none box-border"
    >
      {/* ========================================================
          LEFT COLUMN (~1350px width, 936px height)
          Header (~125px) + Vakit Box (~95px) + Ayah (~340px) + Hadith (~340px)
          ======================================================== */}
      <div
        dir="ltr"
        style={{ direction: 'ltr', width: 1350 }}
        className="w-[1350px] h-[936px] flex flex-col justify-between pr-[28px] border-r border-[#C59B27]/30 overflow-hidden box-border shrink-0"
      >
        {/* 1. TOP HEADER (~125px) */}
        <div className="w-full h-[125px] flex items-center gap-5 shrink-0 overflow-hidden">
          {!logoFailed ? (
            <img
              src="/assets/logo/wsb-logo.png"
              alt="WSB Hamburg"
              onError={() => setLogoFailed(true)}
              className="w-[96px] h-[96px] object-contain rounded-2xl border border-[#C59B27]/30 p-1.5 shrink-0 select-none"
            />
          ) : (
            <div className="w-[96px] h-[96px] flex items-center justify-center rounded-2xl bg-[#EDE6D2] border border-[#C59B27]/40 font-cinzel font-black text-[#8E630D] text-[18px] shrink-0 select-none">
              WSB
            </div>
          )}

          <div className="flex-1 min-w-0 flex flex-col justify-center">
            {/* Mosque Name & Badge - No truncation, wraps naturally */}
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-[28px] font-black tracking-wide text-[#1F2421] font-cinzel leading-tight whitespace-normal break-words">
                {settings.mosqueName}
              </h1>
              <span className="px-3 py-0.5 text-[12px] font-black tracking-widest text-[#8E630D] bg-[#EDE6D2] border border-[#C59B27]/30 rounded-full uppercase shrink-0">
                HAMBURG
              </span>
            </div>

            {/* Subtitle - No truncation, wraps naturally */}
            <p className="text-[16px] font-medium text-[#1F2421]/80 leading-snug whitespace-normal break-words mt-1">
              {settings.mosqueSubName}
            </p>

            {/* Date line */}
            <div className="flex items-center gap-3 mt-1 text-[15px] text-[#1F2421]/70 font-medium">
              <span>{gregorianFormatted}</span>
              <span className="text-[#C59B27]">·</span>
              <span className="font-arabic text-[#8E630D] font-bold text-[17px]">{hijriFormatted}</span>
            </div>
          </div>
        </div>

        {/* 2. FOCUS PRAYER & EZAN BOX (~95px) */}
        <div className="w-full h-[95px] flex items-center justify-between px-6 rounded-2xl bg-transparent border border-[#C59B27]/30 shrink-0 box-border">
          <div className="flex items-center gap-3 min-w-0">
            <span className="p-2 rounded-xl bg-[#EDE6D2] border border-[#C59B27]/30 text-[#8E630D] shrink-0">
              <Sparkles className="w-6 h-6 text-[#8E630D]" />
            </span>
            <div className="flex flex-col">
              <span className="text-[12px] font-bold text-[#8E630D] tracking-widest uppercase font-cinzel">
                {nextPrayer?.remainingMinutes !== undefined && nextPrayer.remainingMinutes > 0
                  ? (currentLanguage === 'ar' ? 'الصلاة القادمة' : currentLanguage === 'de' ? 'NÄCHSTES GEBET' : currentLanguage === 'en' ? 'NEXT PRAYER' : 'SIRADAKİ VAKİT')
                  : (currentLanguage === 'ar' ? 'الوقت الحالي' : currentLanguage === 'de' ? 'AKTUELLES GEBET' : currentLanguage === 'en' ? 'CURRENT PRAYER' : 'VAKİT')}
              </span>
              <h2 className="text-[32px] font-black tracking-wider text-[#8E630D] font-cinzel uppercase leading-tight truncate">
                {t.prayers[focusPrayerKey.toLowerCase() as keyof typeof t.prayers] || focusPrayerKey}
              </h2>
            </div>
          </div>

          {/* Adhan Time Pill */}
          <div
            dir="ltr"
            className="flex items-center gap-3 px-5 py-2 rounded-xl bg-transparent border border-[#C59B27]/30 shrink-0"
          >
            <span className="text-[18px] font-black tracking-widest text-[#1F2421]/70 uppercase">
              {focusPrayerKey === 'Sunrise' ? (t.prayers.sunrise || 'GÜNEŞ') : t.tableAdhan}:
            </span>
            <span className="font-mono text-[34px] font-black text-[#1F2421] tracking-tight tabular-nums px-4 py-0.5 rounded-lg bg-[#EDE6D2] border border-[#C59B27]/40 min-w-[5rem] text-center">
              {focusAdhanTime}
            </span>
          </div>
        </div>

        {/* 3. AYAH CARD (~340px) */}
        <div className="w-full h-[340px] rounded-2xl bg-transparent border border-[#C59B27]/30 p-5 flex flex-col justify-between overflow-hidden shrink-0 box-border">
          {/* Header Row */}
          <div className="w-full h-[40px] flex items-center justify-between pb-2 border-b border-[#C59B27]/25 shrink-0">
            <div className="flex items-center gap-3">
              <span className="p-1.5 rounded-lg bg-[#EDE6D2] text-[#8E630D] border border-[#C59B27]/30 shrink-0">
                <BookOpen className="w-5 h-5 text-[#8E630D]" />
              </span>
              <span className="text-[18px] font-black tracking-wider text-[#8E630D] font-cinzel">
                {ayahCardTitle}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {ayahNeedsPagination && (
                <span className="px-3 py-0.5 rounded-full bg-[#EDE6D2] border border-[#C59B27]/40 text-[13px] font-black text-[#8E630D] font-mono tracking-wider">
                  {ayahPageIndex === 0 ? '1/2 · ARAPÇA' : '2/2 · MEÂL'}
                </span>
              )}
              {todayPair?.ayah && (
                <div className="flex items-center gap-2 px-3 py-0.5 rounded-full bg-[#EDE6D2] border border-[#C59B27]/30 text-[14px] font-bold text-[#1F2421]">
                  <span>{todayPair.ayah.surahName[currentLanguage] || todayPair.ayah.surahName.tr}</span>
                  <span>·</span>
                  <span>{currentLanguage === 'ar' ? `آية ${todayPair.ayah.ayahNumber}` : `Âyet ${todayPair.ayah.ayahNumber}`}</span>
                </div>
              )}
            </div>
          </div>

          {/* Body Area - Generous height (~240px) with NO line-clamp and 12s pagination */}
          <div
            className={`w-full flex-1 flex flex-col justify-center items-center py-2 transition-opacity duration-350 ease-out overflow-hidden ${
              ayahFade === 'in' ? 'opacity-100' : 'opacity-0'
            }`}
          >
            {todayPair?.ayah ? (
              ayahNeedsPagination ? (
                /* Paginated View: Page 0 is Arabic, Page 1 is Meal */
                ayahPageIndex === 0 ? (
                  <div
                    dir="rtl"
                    className={`w-full font-arabic font-bold text-center text-[#1F2421] break-words leading-[1.6] select-text px-2 ${getAyahArabicFontSize()}`}
                  >
                    {ayahArabicText}
                  </div>
                ) : (
                  <div
                    dir={currentLanguage === 'ar' ? 'rtl' : 'ltr'}
                    className={`w-full font-medium italic text-center text-[#1F2421] break-words leading-[1.45] select-text px-2 ${getAyahMealFontSize()}`}
                  >
                    “{ayahMealText}”
                  </div>
                )
              ) : (
                /* Single Page View: Both fit comfortably */
                <div className="w-full flex flex-col justify-center gap-3">
                  <div
                    dir="rtl"
                    className="w-full font-arabic font-bold text-center text-[#1F2421] break-words leading-[1.5] select-text text-[44px]"
                  >
                    {ayahArabicText}
                  </div>
                  <div
                    dir={currentLanguage === 'ar' ? 'rtl' : 'ltr'}
                    className="w-full font-medium italic text-center text-[#1F2421] break-words leading-[1.4] select-text text-[30px]"
                  >
                    “{ayahMealText}”
                  </div>
                </div>
              )
            ) : (
              <p className="text-[20px] text-[#1F2421]/60 italic">Âyet-i Kerîme yükleniyor...</p>
            )}
          </div>

          {/* Footer Reference Row (Font size >= 24px) */}
          <div className="w-full h-[38px] pt-2 border-t border-[#C59B27]/25 flex items-center justify-between text-[#1F2421]/80 shrink-0">
            <span className="text-[24px] font-sans font-medium text-[#1F2421] select-text truncate">
              {todayPair?.ayah?.reference || 'Kur\'an-ı Kerim'}
            </span>
            <span className="font-arabic text-[#8E630D] font-bold text-[24px] select-none shrink-0" dir="rtl">
              صَدَقَ اللّٰهُ الْعَظِيمُ
            </span>
          </div>
        </div>

        {/* 4. HADITH CARD (~340px) */}
        <div className="w-full h-[340px] rounded-2xl bg-transparent border border-[#C59B27]/30 p-5 flex flex-col justify-between overflow-hidden shrink-0 box-border">
          {/* Header Row */}
          <div className="w-full h-[40px] flex items-center justify-between pb-2 border-b border-[#C59B27]/25 shrink-0">
            <div className="flex items-center gap-3">
              <span className="p-1.5 rounded-lg bg-[#EDE6D2] text-[#8E630D] border border-[#C59B27]/30 shrink-0">
                <Quote className="w-5 h-5 text-[#8E630D]" />
              </span>
              <span className="text-[18px] font-black tracking-wider text-[#8E630D] font-cinzel">
                {hadithCardTitle}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {hadithNeedsPagination && (
                <span className="px-3 py-0.5 rounded-full bg-[#EDE6D2] border border-[#C59B27]/40 text-[13px] font-black text-[#8E630D] font-mono tracking-wider">
                  {hadithPageIndex === 0 ? '1/2 · ARAPÇA' : '2/2 · MEÂL'}
                </span>
              )}
              <div className="flex items-center gap-2 px-3 py-0.5 rounded-full bg-[#EDE6D2] border border-[#C59B27]/30 text-[14px] font-bold text-[#1F2421]">
                <Sparkles className="w-3.5 h-3.5 text-[#8E630D]" />
                <span>{prophetCitation}</span>
              </div>
            </div>
          </div>

          {/* Body Area - Generous height (~240px) with NO line-clamp and 12s pagination */}
          <div
            className={`w-full flex-1 flex flex-col justify-center items-center py-2 transition-opacity duration-350 ease-out overflow-hidden ${
              hadithFade === 'in' ? 'opacity-100' : 'opacity-0'
            }`}
          >
            {todayPair?.hadith ? (
              hadithNeedsPagination ? (
                /* Paginated View: Page 0 is Arabic, Page 1 is Meal */
                hadithPageIndex === 0 ? (
                  <div
                    dir="rtl"
                    className={`w-full font-arabic font-bold text-center text-[#1F2421] break-words leading-[1.6] select-text px-2 ${getHadithArabicFontSize()}`}
                  >
                    {hadithArabicText}
                  </div>
                ) : (
                  <div
                    dir={currentLanguage === 'ar' ? 'rtl' : 'ltr'}
                    className={`w-full font-medium italic text-center text-[#1F2421] break-words leading-[1.45] select-text px-2 ${getHadithMealFontSize()}`}
                  >
                    “{hadithMealText}”
                  </div>
                )
              ) : (
                /* Single Page View: Both fit comfortably */
                <div className="w-full flex flex-col justify-center gap-3">
                  {hadithArabicText && (
                    <div
                      dir="rtl"
                      className="w-full font-arabic font-bold text-center text-[#1F2421] break-words leading-[1.5] select-text text-[44px]"
                    >
                      {hadithArabicText}
                    </div>
                  )}
                  <div
                    dir={currentLanguage === 'ar' ? 'rtl' : 'ltr'}
                    className="w-full font-medium italic text-center text-[#1F2421] break-words leading-[1.4] select-text text-[30px]"
                  >
                    “{hadithMealText}”
                  </div>
                </div>
              )
            ) : (
              <p className="text-[20px] text-[#1F2421]/60 italic">Hadîs-i Şerîf yükleniyor...</p>
            )}
          </div>

          {/* Footer Citation Row (Font size >= 24px) */}
          <div className="w-full h-[38px] pt-2 border-t border-[#C59B27]/25 flex items-center justify-between text-[#1F2421] shrink-0">
            <div className="text-[24px] font-sans font-medium select-text truncate">
              {hadithNarratorText ? (
                <span>
                  <span className="font-semibold text-[#1F2421]">{hadithNarratorText}</span>
                  <span className="mx-2 text-[#C59B27]">·</span>
                </span>
              ) : null}
              <span className="font-bold text-[#8E630D]">{hadithSourceText}</span>
            </div>
            <span className="font-arabic text-[#8E630D] font-bold text-[24px] select-none shrink-0">
              ﷺ
            </span>
          </div>
        </div>
      </div>

      {/* ========================================================
          RIGHT COLUMN (494px width, 936px height)
          Clock (~125px) + Kutlu Vakit (~100px) + Prayer Times Table (~687px)
          ======================================================== */}
      <div
        dir="ltr"
        style={{ direction: 'ltr', width: 494 }}
        className="w-[494px] h-[936px] flex flex-col justify-between overflow-hidden box-border shrink-0"
      >
        {/* 1. CLOCK CARD (~125px) */}
        <div className="w-full h-[125px] flex flex-col justify-between p-4 rounded-2xl bg-transparent border border-[#C59B27]/30 shrink-0 box-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-[#EDE6D2] border border-[#C59B27]/30 text-[13px] font-black tracking-widest text-[#8E630D] uppercase font-cinzel">
                HAMBURG
              </span>
              <span className="text-[15px] font-bold text-[#8E630D] font-mono tracking-wider">
                CET
              </span>
            </div>
            <span className="text-[13px] font-bold text-[#1F2421]/60 uppercase tracking-widest">
              CANLI SAAT
            </span>
          </div>

          <div
            dir="ltr"
            className="flex items-center justify-center font-mono text-[56px] font-black text-[#1F2421] tracking-tight tabular-nums leading-none py-1"
          >
            {timeFormatted}
          </div>
        </div>

        {/* 2. KUTLU VAKİT / RAMADAN COUNTDOWN CARD (~100px) */}
        <div className="w-full h-[100px] rounded-2xl p-3.5 bg-transparent border border-[#C59B27]/30 shrink-0 flex flex-col justify-between box-border">
          {ramadanCountdown.isRamadan ? (
            /* Case A: Ramadan Fasting Countdown */
            <>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Moon className="w-5 h-5 text-[#8E630D]" />
                  <span className="text-[14px] font-black text-[#8E630D] tracking-wider uppercase font-cinzel">
                    {ramadanCountdown.label[currentLanguage] || ramadanCountdown.label.tr}
                  </span>
                </div>
                <span className="px-3 py-0.5 rounded-md bg-[#EDE6D2] border border-[#C59B27]/30 text-[#8E630D] font-mono text-[13px] font-bold">
                  {ramadanCountdown.phase === 'iftar'
                    ? (currentLanguage === 'ar' ? 'الإفطار' : 'İFTAR')
                    : (currentLanguage === 'ar' ? 'الإمساك' : 'İMSAK')}{' '}
                  {ramadanCountdown.targetTimeStr}
                </span>
              </div>
              <div className="flex items-center justify-between pt-1 border-t border-[#C59B27]/20" dir="ltr">
                <span className="font-mono text-[24px] font-black text-[#8E630D] tracking-tight tabular-nums">
                  {ramadanCountdown.formattedCountdown}
                </span>
                {sequentialMilestones[0] && (
                  <span className="text-[13px] font-bold text-[#1F2421]/80">
                    {sequentialMilestones[0].shortName[currentLanguage] || sequentialMilestones[0].shortName.tr}:{' '}
                    <span className="text-[#8E630D] font-black">{sequentialMilestones[0].daysRemaining} {currentLanguage === 'ar' ? 'يوم' : 'gün'}</span>
                  </span>
                )}
              </div>
            </>
          ) : specialEvent && (specialEvent.isToday || specialEvent.isTonight) ? (
            /* Case B: Special Day Active Today or Tonight */
            <>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-1 rounded bg-[#EDE6D2] text-[#8E630D] border border-[#C59B27]/30">
                    <Sparkles className="w-4 h-4 text-[#8E630D]" />
                  </span>
                  <h3 className="text-[16px] font-black text-[#1F2421] font-cinzel truncate">
                    {specialEvent.celebrationGreeting?.heading[currentLanguage] || specialEvent.title[currentLanguage] || specialEvent.title.tr}
                  </h3>
                </div>
                <span className="px-3 py-0.5 text-[12px] font-black tracking-wider uppercase rounded-full bg-[#EDE6D2] border border-[#C59B27]/30 text-[#8E630D]">
                  {specialEvent.isTonight
                    ? (currentLanguage === 'ar' ? 'الليلة' : currentLanguage === 'de' ? 'HEUTE NACHT' : currentLanguage === 'en' ? 'TONIGHT' : 'BU GECE')
                    : (currentLanguage === 'ar' ? 'اليوم' : currentLanguage === 'de' ? 'HEUTE' : currentLanguage === 'en' ? 'TODAY' : 'BUGÜN')}
                </span>
              </div>
              <div className="flex items-center justify-between pt-1 border-t border-[#C59B27]/20 text-[13px] text-[#1F2421]/80">
                <span className="truncate">
                  {specialEvent.celebrationGreeting?.badge[currentLanguage] || specialEvent.badgeText[currentLanguage] || '✦ MÜBAREK OLSUN ✦'}
                </span>
                {sequentialMilestones[0] && (
                  <span className="font-mono font-bold text-[#8E630D] shrink-0 pl-2">
                    {sequentialMilestones[0].daysRemaining} {currentLanguage === 'ar' ? 'يوم' : 'gün'}
                  </span>
                )}
              </div>
            </>
          ) : (
            /* Case C: Upcoming Holy Occasion */
            <>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-1 rounded-md bg-[#EDE6D2] text-[#8E630D] border border-[#C59B27]/30">
                    <Calendar className="w-4 h-4 text-[#8E630D]" />
                  </span>
                  <div>
                    <span className="text-[11px] font-bold tracking-widest text-[#8E630D] uppercase font-cinzel block leading-none">
                      {currentLanguage === 'ar' ? 'المناسبة المباركة القادمة' : currentLanguage === 'de' ? 'NÄCHSTER HEILIGER TAG' : currentLanguage === 'en' ? 'NEXT SACRED MILESTONE' : 'SIRADAKİ KUTLU VAKİT'}
                    </span>
                    <h3 className="text-[16px] font-black text-[#1F2421] font-cinzel truncate mt-0.5">
                      {sequentialMilestones[0]?.title[currentLanguage] || sequentialMilestones[0]?.title.tr || 'Mübarek Günler'}
                    </h3>
                  </div>
                </div>

                {sequentialMilestones[0] && (
                  <span className="px-3 py-1 text-[13px] font-black tracking-wider uppercase rounded-full bg-[#EDE6D2] border border-[#C59B27]/30 text-[#8E630D] shrink-0">
                    {sequentialMilestones[0].daysRemaining === 1
                      ? (currentLanguage === 'ar' ? 'غداً' : currentLanguage === 'de' ? 'MORGEN' : currentLanguage === 'en' ? 'TOMORROW' : 'YARIN')
                      : (currentLanguage === 'ar' ? `باقي ${sequentialMilestones[0].daysRemaining} يوماً` : `${sequentialMilestones[0].daysRemaining} GÜN`)}
                  </span>
                )}
              </div>

              {sequentialMilestones[1] && (
                <div className="flex items-center justify-between pt-1 border-t border-[#C59B27]/20 text-[13px] text-[#1F2421]/80">
                  <span className="truncate">
                    <span className="font-semibold text-[#8E630D]">
                      {currentLanguage === 'ar' ? 'ثم يليه: ' : currentLanguage === 'de' ? 'Danach: ' : currentLanguage === 'en' ? 'Following: ' : 'Ardından: '}
                    </span>
                    {sequentialMilestones[1].shortName[currentLanguage] || sequentialMilestones[1].shortName.tr}
                  </span>
                  <span className="font-mono font-bold text-[#8E630D] shrink-0 pl-2">
                    {sequentialMilestones[1].daysRemaining} {currentLanguage === 'ar' ? 'يوم' : 'gün'}
                  </span>
                </div>
              )}
            </>
          )}
        </div>

        {/* 3. PRAYER TIMES TABLE (~687px) - All 6 prayers + Friday + System Bar */}
        <div className="w-full h-[687px] rounded-2xl p-4 bg-transparent border border-[#C59B27]/30 flex flex-col justify-between overflow-hidden shrink-0 box-border">
          {/* Table Header (30px) */}
          <div className="w-full h-[30px] flex items-center justify-between px-4 text-[13px] font-black tracking-widest text-[#1F2421]/60 uppercase border-b border-[#C59B27]/25 shrink-0">
            <span>{t.tablePrayer}</span>
            <span>{t.tableAdhan}</span>
          </div>

          {/* 6 Prayer Rows (Spacious and prominent across the table) */}
          <div className="w-full flex-1 flex flex-col justify-between py-2 gap-2 overflow-hidden">
            {prayerRows.map((row) => {
              const isFocus = focusPrayerKey === row.key;
              const adhanTime = timings ? timings[row.key] || '--:--' : '--:--';

              return (
                <div
                  key={row.key}
                  className={`w-full h-[82px] flex items-center justify-between px-5 rounded-xl transition-all duration-300 box-border ${
                    isFocus
                      ? 'bg-[#EDE6D2] text-[#1F2421] border border-[#C59B27]/50 font-bold shadow-sm'
                      : 'bg-transparent text-[#1F2421]'
                  }`}
                >
                  {/* Icon & Name */}
                  <div className="flex items-center gap-3.5">
                    <span className={`p-2 rounded-lg ${isFocus ? 'bg-[#C59B27]/25 text-[#8E630D]' : 'bg-[#EDE6D2]/50 text-[#8E630D]'}`}>
                      {row.icon}
                    </span>
                    <span className={`text-[22px] font-cinzel tracking-wider uppercase ${isFocus ? 'font-black text-[#1F2421]' : 'font-bold'}`}>
                      {row.name}
                    </span>
                  </div>

                  {/* Adhan Time */}
                  <div
                    className={`font-mono text-[30px] font-black tracking-tight tabular-nums min-w-[5.2rem] text-right ${
                      isFocus ? 'text-[#8E630D]' : 'text-[#1F2421]'
                    }`}
                    dir="ltr"
                  >
                    {adhanTime}
                  </div>
                </div>
              );
            })}
          </div>

          {/* System Control Bar (~46px) */}
          <div className="w-full h-[46px] flex items-center justify-between pt-2 border-t border-[#C59B27]/25 shrink-0 box-border">
            {/* Language Switcher */}
            <div className="flex items-center p-0.5 rounded-xl bg-transparent border border-[#C59B27]/30">
              {languages.map((item) => {
                const isSelected = currentLanguage === item.code;
                return (
                  <button
                    key={item.code}
                    onClick={() => onLanguageChange(item.code)}
                    className={`px-3 py-1 rounded-lg text-[13px] font-bold transition-all ${
                      isSelected
                        ? 'bg-[#EDE6D2] text-[#8E630D] font-black border border-[#C59B27]/40'
                        : 'text-[#1F2421]/70 hover:text-[#1F2421]'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </div>

            {/* Auto Rotate Countdown */}
            {settings.autoRotateLanguages && (
              <div
                className="flex items-center gap-1.5 px-2.5 py-1 text-[12px] font-medium text-[#1F2421]/80 bg-[#EDE6D2]/60 border border-[#C59B27]/30 rounded-lg"
                title="Otomatik dil rotasyonu"
              >
                <Globe className="w-3.5 h-3.5 text-[#8E630D] animate-spin" style={{ animationDuration: '10s' }} />
                <span className="font-mono text-[#8E630D] font-bold">{autoRotateSecondsLeft}s</span>
              </div>
            )}

            {/* Status Badges & Admin Button */}
            <div className="flex items-center gap-2">
              <div
                className="flex items-center gap-1.5 px-2 py-1 text-[12px] font-semibold rounded-lg border border-[#C59B27]/30 bg-[#EDE6D2]/60 text-[#1F2421]"
              >
                {isOnline ? (
                  <Wifi className="w-3.5 h-3.5 text-emerald-700" />
                ) : (
                  <WifiOff className="w-3.5 h-3.5 text-amber-700" />
                )}
                <span>{isOnline ? 'Online' : 'Offline'}</span>
              </div>

              <div
                className="flex items-center gap-1.5 px-2 py-1 text-[12px] font-semibold rounded-lg bg-[#EDE6D2]/60 border border-[#C59B27]/30 text-[#1F2421]"
                title={isWakeLocked ? t.screenWakeLockActive : t.screenWakeLockInactive}
              >
                <ShieldCheck className={`w-3.5 h-3.5 ${isWakeLocked ? 'text-[#8E630D]' : 'text-gray-400'}`} />
                <span>TV 7/24</span>
              </div>

              <button
                onClick={onOpenAdmin}
                className="p-1.5 rounded-lg bg-[#EDE6D2]/60 hover:bg-[#EDE6D2] text-[#1F2421] border border-[#C59B27]/30 transition-all cursor-pointer"
                title={`${t.adminPanel} (TV Kumandası: Menü tuşu veya 'M')`}
              >
                <Settings className="w-4 h-4 text-[#8E630D]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
