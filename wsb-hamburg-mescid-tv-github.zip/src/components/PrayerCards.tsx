import React from 'react';
import { Sunrise, Sun, Sunset, Moon, Sparkles, Clock } from 'lucide-react';
import { PrayerTimes, Language } from '../types';
import { TRANSLATIONS } from '../i18n/translations';

interface PrayerCardsProps {
  timings: PrayerTimes | null;
  activePrayer: keyof PrayerTimes | null;
  nextPrayer: {
    key: keyof PrayerTimes;
    time: string;
    remainingMinutes: number;
    remainingSeconds: number;
    totalSpanMinutes: number;
    progressPercentage: number;
  } | null;
  currentLanguage: Language;
}

export const PrayerCards: React.FC<PrayerCardsProps> = ({
  timings,
  activePrayer,
  nextPrayer,
  currentLanguage,
}) => {
  const t = TRANSLATIONS[currentLanguage];

  if (!timings) {
    return (
      <div className="flex items-center justify-center h-32 rounded-2xl bg-black/40 border border-emerald-800/40">
        <div className="flex items-center gap-3 text-amber-300 font-semibold text-sm sm:text-base">
          <Clock className="w-5 h-5 animate-spin text-amber-400" />
          <span>{t.subTitle} — Namaz vakitleri yükleniyor…</span>
        </div>
      </div>
    );
  }

  const prayerDefs: {
    key: keyof PrayerTimes;
    icon: React.ReactNode;
    label: string;
    subLabel: string;
  }[] = [
    {
      key: 'Fajr',
      icon: <Sunrise className="w-5 h-5 sm:w-6 sm:h-6 text-amber-300" />,
      label: t.prayers.fajr,
      subLabel: 'Fajr',
    },
    {
      key: 'Sunrise',
      icon: <Sun className="w-5 h-5 sm:w-6 sm:h-6 text-amber-400" />,
      label: t.prayers.sunrise,
      subLabel: 'Tulu',
    },
    {
      key: 'Dhuhr',
      icon: <Sun className="w-5 h-5 sm:w-6 sm:h-6 text-yellow-300" />,
      label: t.prayers.dhuhr,
      subLabel: 'Dhuhr',
    },
    {
      key: 'Asr',
      icon: <Sun className="w-5 h-5 sm:w-6 sm:h-6 text-amber-400" />,
      label: t.prayers.asr,
      subLabel: 'Asr',
    },
    {
      key: 'Maghrib',
      icon: <Sunset className="w-5 h-5 sm:w-6 sm:h-6 text-orange-400" />,
      label: t.prayers.maghrib,
      subLabel: 'Maghrib',
    },
    {
      key: 'Isha',
      icon: <Moon className="w-5 h-5 sm:w-6 sm:h-6 text-indigo-300" />,
      label: t.prayers.isha,
      subLabel: 'Isha',
    },
  ];

  // Format countdown string
  let countdownFormatted = '';
  if (nextPrayer) {
    const hours = Math.floor(nextPrayer.remainingMinutes / 60);
    const mins = nextPrayer.remainingMinutes % 60;
    const secs = nextPrayer.remainingSeconds;

    const parts: string[] = [];
    if (hours > 0) parts.push(`${hours} ${t.hours}`);
    parts.push(`${mins} ${t.minutes}`);
    parts.push(`${secs} ${t.seconds}`);

    countdownFormatted = `${parts.join(' ')} ${t.timeRemaining}`;
  }

  return (
    <div className="flex flex-col gap-2.5 sm:gap-3 w-full shrink-0">
      {/* 6 Prayer Cards: 2 cols on Mobile, 3 on Tablet, 6 on TV / Desktop */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 sm:gap-2.5 lg:gap-3 w-full">
        {prayerDefs.map((p) => {
          const isNext = nextPrayer?.key === p.key;
          const isActive = activePrayer === p.key;
          const time = timings[p.key] || '--:--';

          return (
            <div
              key={p.key}
              className={`relative flex flex-col items-center justify-between p-2.5 sm:p-3 lg:p-3.5 rounded-2xl transition-all duration-300 border min-w-0 w-full box-border ${
                isNext
                  ? 'bg-gradient-to-b from-amber-500/25 via-emerald-950/90 to-emerald-950/95 border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.35)] ring-1 ring-amber-400/50'
                  : isActive
                  ? 'bg-gradient-to-b from-emerald-600/30 via-emerald-900/60 to-emerald-950/80 border-emerald-400/80 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
                  : 'bg-black/50 border-emerald-900/50 hover:border-emerald-700/60'
              }`}
            >
              {/* Highlight badge for Next Prayer */}
              {isNext && (
                <div className="absolute -top-2.5 px-2 py-0.5 rounded-full bg-amber-400 text-emerald-950 text-[9px] sm:text-[10px] font-black uppercase tracking-wider shadow-md flex items-center gap-1 animate-pulse">
                  <Sparkles className="w-2.5 h-2.5 text-emerald-950" />
                  <span>{t.nextPrayer}</span>
                </div>
              )}

              {/* Active Prayer Badge */}
              {isActive && !isNext && (
                <div className="absolute -top-2.5 px-2 py-0.5 rounded-full bg-emerald-500 text-black text-[9px] sm:text-[10px] font-black uppercase tracking-wider shadow-md">
                  {t.nowInPrayer}
                </div>
              )}

              {/* Card Header: Icon & Prayer Label */}
              <div className="flex flex-col items-center gap-1 w-full min-w-0">
                <div className={`p-1.5 sm:p-2 rounded-xl shrink-0 ${isNext ? 'bg-amber-400/20' : 'bg-emerald-950/60'}`}>
                  {p.icon}
                </div>
                <span className="text-xs sm:text-sm lg:text-base font-extrabold tracking-wide text-emerald-100 truncate w-full text-center">
                  {p.label}
                </span>
              </div>

              {/* Prayer Time: Guaranteed independent cell with tabular numerals */}
              <div className="my-1 sm:my-1.5 w-full text-center min-w-0">
                <span
                  className={`font-mono text-xl sm:text-2xl lg:text-3xl font-black tracking-tight tabular-nums whitespace-nowrap block ${
                    isNext ? 'text-amber-200 drop-shadow-[0_0_10px_rgba(251,191,36,0.5)]' : 'text-white'
                  }`}
                >
                  {time}
                </span>
              </div>

              {/* Bottom Subtle Indicator */}
              <div className="w-full pt-1 border-t border-emerald-900/40 text-center truncate">
                <span className="text-[10px] font-medium text-emerald-400/70 uppercase tracking-wider">
                  {p.subLabel}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Next Prayer Countdown Bar: Wraps gracefully on mobile, single row on TV */}
      {nextPrayer && (
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-950/95 via-[#032921]/95 to-emerald-950/95 border border-amber-400/40 shadow-lg p-2.5 sm:px-5 sm:py-2.5 w-full">
          {/* Background Progress Fill */}
          <div
            className="absolute left-0 top-0 bottom-0 bg-gradient-to-r from-emerald-700/20 to-amber-500/15 transition-all duration-1000 ease-linear pointer-events-none"
            style={{ width: `${nextPrayer.progressPercentage}%` }}
          />

          <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-2 w-full">
            {/* Left: Next Prayer Info */}
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="p-1.5 rounded-xl bg-amber-400/20 text-amber-300 shrink-0">
                <Clock className="w-4 h-4 animate-pulse" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] sm:text-xs font-bold uppercase tracking-wider text-emerald-300/90 mr-1.5">
                  {t.nextPrayer}:
                </span>
                <span className="text-sm sm:text-base lg:text-lg font-black text-amber-300 font-cinzel">
                  {t.prayers[nextPrayer.key.toLowerCase() as keyof typeof t.prayers]} ({nextPrayer.time})
                </span>
              </div>
            </div>

            {/* Right: Countdown & Progress */}
            <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
              <div className="px-3 py-1 rounded-xl bg-black/60 border border-amber-400/30">
                <span className="font-mono text-xs sm:text-sm lg:text-base font-black text-amber-300 tracking-wider">
                  {countdownFormatted}
                </span>
              </div>
              <div className="text-right text-[10px] sm:text-[11px] text-emerald-400/70 font-mono shrink-0">
                %{nextPrayer.progressPercentage}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
