import React, { useState, useEffect } from 'react';
import { BookOpen, HeartHandshake, X, Sparkles } from 'lucide-react';
import { DailyPair, Language, MosqueSettings } from '../types';
import { TRANSLATIONS } from '../i18n/translations';

interface PrayerSequenceModalProps {
  isOpen: boolean;
  onClose: () => void;
  pair: DailyPair;
  currentLanguage: Language;
  prayerName?: string;
  settings: MosqueSettings;
}

export const PrayerSequenceModal: React.FC<PrayerSequenceModalProps> = ({
  isOpen,
  onClose,
  pair,
  currentLanguage,
  prayerName,
  settings,
}) => {
  const [stage, setStage] = useState<'ayah' | 'hadith'>('ayah');
  const [totalSecondsRemaining, setTotalSecondsRemaining] = useState<number>(30);
  const t = TRANSLATIONS[currentLanguage];
  const isArabic = currentLanguage === 'ar';

  useEffect(() => {
    if (!isOpen) {
      setStage('ayah');
      setTotalSecondsRemaining(30);
      return;
    }

    setStage('ayah');
    setTotalSecondsRemaining(30);

    // 1. Strict 30-second setTimeout: closes automatically without user input
    const autoCloseTimeout = setTimeout(() => {
      onClose();
    }, 30000);

    // 2. Second-by-second countdown (15s Ayah + 15s Hadith = 30s total)
    const interval = setInterval(() => {
      setTotalSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        const next = prev - 1;
        // At 15 seconds remaining, switch to Hadith
        if (next <= 15 && stage === 'ayah') {
          setStage('hadith');
        }
        return next;
      });
    }, 1000);

    return () => {
      clearTimeout(autoCloseTimeout);
      clearInterval(interval);
    };
  }, [isOpen, stage, onClose]);

  if (!isOpen) return null;

  const currentAyahText = pair.ayah.translations[currentLanguage] || pair.ayah.translations.tr;
  const currentHadithText = pair.hadith.translations[currentLanguage] || pair.hadith.translations.tr;

  const progressPercent = Math.round(((30 - totalSecondsRemaining) / 30) * 100);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between p-4 sm:p-8 lg:p-12 bg-gradient-to-b from-[#021813] via-[#041a14] to-black text-white backdrop-blur-xl animate-fadeIn overflow-y-auto">
      {/* Top Banner */}
      <div className="w-full flex items-center justify-between border-b border-amber-400/30 pb-4 sm:pb-6 gap-3 shrink-0">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="p-2 sm:p-2.5 rounded-2xl bg-amber-400/20 text-amber-300 border border-amber-400/40 shrink-0">
            <Sparkles className="w-6 h-6 sm:w-8 sm:h-8 animate-pulse text-amber-400" />
          </div>
          <div className="min-w-0">
            <h2 className="text-lg sm:text-2xl font-black tracking-widest text-amber-300 uppercase font-cinzel truncate">
              {prayerName ? `${prayerName} — ${t.nowInPrayer}` : t.nowInPrayer}
            </h2>
            <p className="text-xs sm:text-sm text-emerald-200/80 font-medium truncate">
              WSB Hamburg Mescid · Huzur ve Tefekkür Vakti
            </p>
          </div>
        </div>

        {/* Stage & Timer Badge (Explicitly indicating automatic close countdown) */}
        <div className="flex items-center gap-2.5 sm:gap-4 shrink-0">
          <div className="px-3 sm:px-4 py-1.5 rounded-xl bg-black/60 border border-emerald-700/60 flex items-center gap-2">
            <span className="text-[10px] sm:text-xs uppercase font-bold text-emerald-300">
              {stage === 'ayah' ? t.dailyVerse : t.dailyHadith}
            </span>
            <span className="font-mono text-amber-300 font-bold text-xs sm:text-sm">
              · {totalSecondsRemaining}s sonra kapanır
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 sm:p-2 rounded-xl bg-black/40 hover:bg-emerald-900/60 border border-emerald-800 text-emerald-300 hover:text-white transition-all focus:outline-none focus:ring-2 focus:ring-amber-400"
            title="Kapat (ESC / TV Geri Tuşu)"
          >
            <X className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
        </div>
      </div>

      {/* Main Peaceful Content Area */}
      <div className="flex-1 flex flex-col items-center justify-center max-w-5xl w-full text-center py-6 sm:py-8 my-auto">
        {stage === 'ayah' ? (
          <div className="flex flex-col items-center gap-4 sm:gap-8 animate-fadeIn w-full">
            {/* Arabic Verse */}
            <div
              dir="rtl"
              className="font-arabic text-2xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold leading-[1.8] text-amber-200 drop-shadow-[0_0_25px_rgba(251,191,36,0.4)] tracking-wide px-2"
            >
              {pair.ayah.arabic}
            </div>

            {/* Translation */}
            <div
              dir={isArabic ? 'rtl' : 'ltr'}
              className="text-base sm:text-xl lg:text-2xl xl:text-3xl font-light text-emerald-50 leading-relaxed max-w-4xl italic px-3"
            >
              "{currentAyahText}"
            </div>

            {/* Reference */}
            <div className="flex items-center gap-2.5 px-4 sm:px-6 py-1.5 sm:py-2 rounded-full bg-emerald-950/80 border border-amber-400/40 text-amber-300 font-mono text-xs sm:text-base font-semibold shadow-lg">
              <BookOpen className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
              <span>{pair.ayah.surahName[currentLanguage] || pair.ayah.surahName.tr} — {pair.ayah.reference}</span>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-4 sm:gap-8 animate-fadeIn w-full">
            {/* Arabic Hadith */}
            <div
              dir="rtl"
              className="font-arabic text-2xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold leading-[1.8] text-teal-200 drop-shadow-[0_0_25px_rgba(45,212,191,0.4)] tracking-wide px-2"
            >
              {pair.hadith.arabic}
            </div>

            {/* Translation */}
            <div
              dir={isArabic ? 'rtl' : 'ltr'}
              className="text-base sm:text-xl lg:text-2xl xl:text-3xl font-light text-emerald-50 leading-relaxed max-w-4xl italic px-3"
            >
              "{currentHadithText}"
            </div>

            {/* Reference */}
            <div className="flex items-center gap-2.5 px-4 sm:px-6 py-1.5 sm:py-2 rounded-full bg-emerald-950/80 border border-teal-400/40 text-teal-300 font-mono text-xs sm:text-base font-semibold shadow-lg">
              <HeartHandshake className="w-4 h-4 sm:w-5 sm:h-5 text-teal-400" />
              <span>{pair.hadith.source}</span>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Progress Bar */}
      <div className="w-full flex flex-col gap-2 shrink-0">
        <div className="w-full h-2 rounded-full bg-black/60 overflow-hidden border border-emerald-900/60">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 via-amber-400 to-emerald-400 transition-all duration-1000 ease-linear"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
        <div className="flex items-center justify-between text-[11px] sm:text-xs text-emerald-400/80">
          <span>{stage === 'ayah' ? '1/2 Âyet-i Kerîme' : '2/2 Hadîs-i Şerîf'}</span>
          <span className="font-mono text-amber-300">
            Otomatik Kapanış: {totalSecondsRemaining} saniye sonra ana ekrana dönülür
          </span>
        </div>
      </div>
    </div>
  );
};
