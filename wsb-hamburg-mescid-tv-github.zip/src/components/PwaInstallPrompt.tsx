import React, { useState, useEffect } from 'react';
import { Tv, Download, X, CheckCircle, Sparkles } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const PwaInstallPrompt: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showPrompt, setShowPrompt] = useState<boolean>(false);
  const [isInstalled, setIsInstalled] = useState<boolean>(false);
  const [installSuccess, setInstallSuccess] = useState<boolean>(false);

  useEffect(() => {
    // 1. Check if already running in standalone / installed PWA mode
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as any).standalone === true ||
      document.referrer.includes('android-app://');

    if (isStandalone) {
      setIsInstalled(true);
      return;
    }

    // 2. Capture native beforeinstallprompt event
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      const promptEvent = e as BeforeInstallPromptEvent;
      setDeferredPrompt(promptEvent);

      // Only show prompt if supported and user hasn't dismissed it
      const dismissed = sessionStorage.getItem('wsb_pwa_prompt_dismissed');
      if (!isStandalone && !dismissed) {
        // Wait at least 3 seconds from page load
        setTimeout(() => {
          setShowPrompt(true);
        }, 3000);
      }
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setInstallSuccess(true);
      setShowPrompt(false);
      setDeferredPrompt(null);
      setTimeout(() => setInstallSuccess(false), 5000);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) {
      setShowPrompt(false);
      return;
    }

    try {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsInstalled(true);
        setShowPrompt(false);
        setDeferredPrompt(null);
      } else {
        setShowPrompt(false);
      }
    } catch {
      setShowPrompt(false);
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    sessionStorage.setItem('wsb_pwa_prompt_dismissed', 'true');
  };

  if (installSuccess) {
    return (
      <div className="fixed top-6 right-6 z-50 flex items-center gap-3 px-5 py-3 rounded-2xl bg-[#EDE6D2] border-2 border-[#C59B27] text-[#1F2421] shadow-[0_12px_40px_rgba(0,0,0,0.3)] animate-fadeIn">
        <CheckCircle className="w-6 h-6 text-emerald-600 shrink-0" />
        <div>
          <h4 className="font-cinzel font-black text-sm text-[#8E630D]">UYGULAMA YÜKLENDİ</h4>
          <p className="text-xs text-[#1F2421]/80">WSB Mescid TV artık ana ekranınızda hazır!</p>
        </div>
      </div>
    );
  }

  if (!showPrompt || isInstalled) return null;

  return (
    <div
      role="dialog"
      aria-label="PWA TV Yükleme"
      className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-2xl px-6 py-4 rounded-3xl bg-[#EDE6D2] text-[#1F2421] border-2 border-[#C59B27] shadow-[0_20px_60px_rgba(0,0,0,0.4)] backdrop-blur-md animate-fadeIn transition-all duration-300"
    >
      <div className="flex items-center justify-between gap-4">
        {/* Left Icon with subtle pulsing glow */}
        <div className="p-3 rounded-2xl bg-gradient-to-br from-[#C59B27] to-[#8E630D] text-white shadow-md shrink-0 flex items-center justify-center">
          <Tv className="w-8 h-8 text-amber-100" />
        </div>

        {/* Text Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-md bg-[#C59B27]/20 text-[#8E630D] font-mono text-[10px] font-black uppercase tracking-wider">
              SMART TV & FIRE TV
            </span>
            <Sparkles className="w-3.5 h-3.5 text-[#C59B27]" />
          </div>
          <h3 className="font-cinzel font-black text-base sm:text-lg text-[#1F2421] tracking-wide mt-0.5 truncate">
            Uygulamayı TV Ana Ekranına Ekle
          </h3>
          <p className="text-xs text-[#1F2421]/80 font-medium line-clamp-1 mt-0.5">
            Televizyonunuzun ana menüsüne bağımsız, 7/24 tam ekran uygulama olarak kurun.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={handleInstallClick}
            autoFocus
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#C59B27] to-[#8E630D] hover:brightness-110 active:scale-95 text-white font-cinzel font-black text-xs sm:text-sm shadow-md transition-all cursor-pointer focus:ring-4 focus:ring-[#C59B27]/50"
          >
            <Download className="w-4 h-4 text-amber-200" />
            <span>ŞİMDİ YÜKLE</span>
          </button>

          <button
            onClick={handleDismiss}
            className="p-2 rounded-xl bg-black/5 hover:bg-black/10 active:scale-90 text-[#1F2421]/60 hover:text-[#1F2421] transition-all cursor-pointer"
            title="Kapat"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
