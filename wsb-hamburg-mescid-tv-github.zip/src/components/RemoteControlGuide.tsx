import React, { useState } from 'react';
import { Tv, ChevronDown, ChevronUp, HelpCircle } from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../i18n/translations';

interface RemoteControlGuideProps {
  currentLanguage: Language;
}

export const RemoteControlGuide: React.FC<RemoteControlGuideProps> = ({ currentLanguage }) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const t = TRANSLATIONS[currentLanguage];

  return (
    <div className="hidden lg:flex fixed bottom-14 right-6 z-30 flex-col items-end">
      {isExpanded ? (
        <div className="w-80 p-4 rounded-2xl bg-black/90 border border-amber-400/50 shadow-2xl backdrop-blur-md text-xs text-emerald-100 flex flex-col gap-2.5 animate-fadeIn">
          <div className="flex items-center justify-between pb-2 border-b border-emerald-800">
            <div className="flex items-center gap-2">
              <Tv className="w-4 h-4 text-amber-400" />
              <span className="font-bold text-amber-300 font-cinzel">TV Kumandası Kılavuzu</span>
            </div>
            <button
              onClick={() => setIsExpanded(false)}
              className="text-emerald-400 hover:text-white"
            >
              <ChevronDown className="w-4 h-4" />
            </button>
          </div>

          <ul className="space-y-1.5 text-[11px]">
            <li className="flex items-center justify-between">
              <span className="text-emerald-300">Yön Tuşları (D-Pad):</span>
              <span className="px-1.5 py-0.5 rounded bg-emerald-950 font-mono text-amber-300">▲ ▼ ◄ ►</span>
            </li>
            <li className="flex items-center justify-between">
              <span className="text-emerald-300">Seç / Onayla:</span>
              <span className="px-1.5 py-0.5 rounded bg-emerald-950 font-mono text-amber-300">OK / Enter</span>
            </li>
            <li className="flex items-center justify-between">
              <span className="text-emerald-300">Yönetici Paneli (PIN):</span>
              <span className="px-1.5 py-0.5 rounded bg-emerald-950 font-mono text-amber-300">Menu / 'M'</span>
            </li>
            <li className="flex items-center justify-between">
              <span className="text-emerald-300">Geri / Kapat:</span>
              <span className="px-1.5 py-0.5 rounded bg-emerald-950 font-mono text-amber-300">Back / ESC</span>
            </li>
            <li className="flex items-center justify-between">
              <span className="text-emerald-300">Hızlı Dil (1-4):</span>
              <span className="px-1.5 py-0.5 rounded bg-emerald-950 font-mono text-amber-300">1:TR, 2:AR, 3:DE, 4:EN</span>
            </li>
          </ul>
        </div>
      ) : (
        <button
          onClick={() => setIsExpanded(true)}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/60 hover:bg-black/90 border border-emerald-700/60 text-emerald-300 hover:text-amber-300 text-[11px] font-semibold transition-all shadow-md focus:outline-none focus:ring-2 focus:ring-amber-400"
          title="TV Kumandası Kısayolları"
        >
          <Tv className="w-3.5 h-3.5 text-amber-400" />
          <span>Kumanda Kılavuzu</span>
          <ChevronUp className="w-3 h-3 text-emerald-400" />
        </button>
      )}
    </div>
  );
};
