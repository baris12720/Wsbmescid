import React from 'react';
import { Calendar, Moon, Sparkles } from 'lucide-react';
import { Language, MosqueSettings, PrayerTimes } from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { hijriService } from '../services/hijriService';

interface SpecialBannersProps {
  settings: MosqueSettings;
  timings: PrayerTimes | null;
  currentLanguage: Language;
  currentTime: Date;
}

export const SpecialBanners: React.FC<SpecialBannersProps> = ({
  settings,
  timings,
  currentLanguage,
  currentTime,
}) => {
  const t = TRANSLATIONS[currentLanguage];
  const dayOfWeek = currentTime.getDay(); // 5 = Friday, 4 = Thursday
  const isFriday = dayOfWeek === 5;
  const isThursdayEvening = dayOfWeek === 4 && currentTime.getHours() >= 17;

  // Hijri info
  const hijri = hijriService.getHijriDate(currentTime, settings.hijriDateAdjustment);
  const isRamadan = settings.ramadan.enabled || (settings.ramadan.autoDetect && hijri.isRamadan);
  const upcoming = hijriService.getUpcomingIslamicDay(currentTime, settings.hijriDateAdjustment);

  // If both Friday and Ramadan are not active and no upcoming event, return null
  const showFriday = settings.friday.enabled && (isFriday || isThursdayEvening);

  if (!showFriday && !isRamadan && !upcoming) {
    return null;
  }

  // Calculate Iftar remaining if in Ramadan and Maghrib is known
  let iftarRemainingFormatted = '';
  if (isRamadan && timings) {
    const [h, m] = timings.Maghrib.split(':').map((v) => parseInt(v, 10));
    const nowMins = currentTime.getHours() * 60 + currentTime.getMinutes();
    const maghribMins = h * 60 + m;
    let diff = maghribMins - nowMins;
    if (diff > 0) {
      const diffHours = Math.floor(diff / 60);
      const diffMins = diff % 60;
      iftarRemainingFormatted = `${diffHours ? `${diffHours} ${t.hours} ` : ''}${diffMins} ${t.minutes}`;
    }
  }

  return (
    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full shrink-0">
      {/* Friday Banner */}
      {showFriday && (
        <div className="flex-1 flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-3 sm:px-5 py-2 sm:py-2.5 rounded-xl bg-gradient-to-r from-emerald-900/85 via-teal-950/85 to-emerald-900/85 border border-emerald-500/50 shadow-md">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 shrink-0">
              <Calendar className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <span className="text-xs font-black text-amber-300 uppercase tracking-wider font-cinzel truncate block">
                {t.fridayPrayerTitle}
              </span>
              <p className="text-[11px] text-emerald-200/90 font-medium truncate">
                {settings.friday.notes[currentLanguage] || settings.friday.notes.tr}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs font-bold shrink-0">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/40 border border-emerald-700/40">
              <span className="text-emerald-400/80 text-[11px]">{t.khutbahTime}:</span>
              <span className="text-amber-300 font-mono text-xs">{settings.friday.firstKhutbahTime}</span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/40 border border-emerald-700/40">
              <span className="text-emerald-400/80 text-[11px]">{t.firstJummah}:</span>
              <span className="text-amber-300 font-mono text-xs">{settings.friday.firstPrayerTime}</span>
            </div>
            {settings.friday.secondPrayerTime && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/40 border border-emerald-700/40">
                <span className="text-emerald-400/80 text-[11px]">{t.secondJummah}:</span>
                <span className="text-amber-300 font-mono text-xs">{settings.friday.secondPrayerTime}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Ramadan Mode Banner */}
      {isRamadan && (
        <div className="flex-1 flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-3 sm:px-5 py-2 sm:py-2.5 rounded-xl bg-gradient-to-r from-amber-950/85 via-emerald-950/90 to-amber-950/85 border border-amber-500/50 shadow-md">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-1.5 rounded-lg bg-amber-400/20 text-amber-300 shrink-0">
              <Moon className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <span className="text-xs font-black text-amber-300 uppercase tracking-wider font-cinzel truncate block">
                {t.ramadanMode}
              </span>
              <p className="text-[11px] text-emerald-200 font-medium truncate">
                {settings.ramadan.customMessage[currentLanguage] || settings.ramadan.customMessage.tr}
              </p>
            </div>
          </div>

          {iftarRemainingFormatted && (
            <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-black/50 border border-amber-400/40 shrink-0">
              <span className="text-[11px] text-amber-300/90 font-medium">{t.untilIftar}:</span>
              <span className="text-xs sm:text-sm font-mono font-black text-amber-300">{iftarRemainingFormatted}</span>
            </div>
          )}
        </div>
      )}

      {/* Upcoming Islamic Day Notice */}
      {upcoming && !showFriday && !isRamadan && (
        <div className="flex-1 flex items-center justify-between px-3 sm:px-5 py-2 sm:py-2.5 rounded-xl bg-gradient-to-r from-teal-950/85 via-emerald-950/85 to-teal-950/85 border border-teal-500/40 shadow-md">
          <div className="flex items-center gap-2.5 min-w-0">
            <Sparkles className="w-4 h-4 text-amber-300 shrink-0" />
            <div className="min-w-0 truncate">
              <span className="text-xs font-bold text-amber-300 mr-1.5">
                {upcoming.dayInfo.title[currentLanguage] || upcoming.dayInfo.title.tr}
              </span>
              <span className="text-[11px] text-emerald-200 hidden sm:inline">
                — {upcoming.dayInfo.description[currentLanguage] || upcoming.dayInfo.description.tr}
              </span>
            </div>
          </div>
          <span className="px-2 py-0.5 rounded-md bg-amber-400/20 text-amber-300 text-[10px] sm:text-[11px] font-bold shrink-0">
            {upcoming.daysLeft === 0 ? 'Bugün' : `${upcoming.daysLeft} gün kaldı`}
          </span>
        </div>
      )}
    </div>
  );
};
