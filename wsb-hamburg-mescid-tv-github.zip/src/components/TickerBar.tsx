import React, { useState, useEffect } from 'react';
import { Bell } from 'lucide-react';
import { Announcement, Language } from '../types';
import { TRANSLATIONS } from '../i18n/translations';

interface TickerBarProps {
  announcements: Announcement[];
  currentLanguage: Language;
}

export const TickerBar: React.FC<TickerBarProps> = ({ announcements, currentLanguage }) => {
  const t = TRANSLATIONS[currentLanguage];
  const todayStr = new Date().toISOString().split('T')[0];

  // Filter active and unexpired announcements
  const activeList = announcements.filter((a) => {
    if (!a.active) return false;
    if (a.startDate && a.startDate > todayStr) return false;
    if (a.endDate && a.endDate < todayStr) return false;
    return true;
  });

  // Rotating state: 10 seconds per announcement with smooth fade transition
  const [currentIndex, setCurrentIndex] = useState(0);
  const [fadeState, setFadeState] = useState<'in' | 'out'>('in');

  useEffect(() => {
    if (activeList.length <= 1) return;

    const interval = setInterval(() => {
      // 1. Begin fade-out
      setFadeState('out');

      // 2. Change active announcement and fade back in
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % activeList.length);
        setFadeState('in');
      }, 400);
    }, 10000); // 10 seconds rotation

    return () => clearInterval(interval);
  }, [activeList.length]);

  if (activeList.length === 0) {
    return (
      <footer className="w-full h-[80px] min-h-[80px] max-h-[80px] px-8 flex items-center justify-between rounded-2xl bg-transparent border border-[#C59B27]/30 text-[#1F2421]/80 shrink-0 overflow-hidden box-border">
        <div className="flex items-center gap-4">
          <img src="/assets/logo/wsb-logo.png" alt="WSB" className="w-8 h-8 object-contain inline-block shrink-0" />
          <span className="font-cinzel text-[#8E630D] font-black text-[20px] tracking-wider">WSB HAMBURG MESCİDİ</span>
          <span className="text-[#8E630D]/50 font-bold text-[20px]">·</span>
          <span className="text-[#1F2421]/75 text-[17px] font-medium">Wilhelmsburger Sport- und Bildungszentrum e.V.</span>
        </div>
        <div className="font-arabic text-[#8E630D] text-[22px] font-bold shrink-0" dir="rtl">
          اللَّهُمَّ صَلِّ عَلَىٰ سَيِّدِنَا مُحَمَّدٍ
        </div>
      </footer>
    );
  }

  // Active announcement according to selected language
  const safeIndex = currentIndex % activeList.length;
  const currentAnn = activeList[safeIndex];
  const currentTitle = currentAnn ? (currentAnn.title[currentLanguage] || currentAnn.title.tr) : '';
  const currentContent = currentAnn ? (currentAnn.content[currentLanguage] || currentAnn.content.tr) : '';

  return (
    <footer className="w-full h-[80px] min-h-[80px] max-h-[80px] flex items-center rounded-2xl bg-transparent border border-[#C59B27]/30 overflow-hidden shrink-0 box-border">
      {/* Ticker Prefix Badge */}
      <div className="relative z-20 flex items-center gap-3 px-6 h-full bg-[#EDE6D2] border-r border-[#C59B27]/30 text-[#8E630D] font-black text-[18px] uppercase tracking-wider shrink-0 select-none">
        <Bell className="w-5 h-5 text-[#C59B27] animate-bounce shrink-0" />
        <span className="font-cinzel">{t.announcements}</span>
      </div>

      {/* Middle Rotating Announcement Area with 10s soft fade/slide */}
      <div className="flex-1 h-full min-w-0 flex items-center justify-between px-6 overflow-hidden">
        <div
          key={`${safeIndex}-${currentLanguage}`}
          className={`flex items-center gap-4 min-w-0 transition-all duration-400 ease-out transform ${
            fadeState === 'in' ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'
          }`}
          dir={currentLanguage === 'ar' ? 'rtl' : 'ltr'}
        >
          {currentTitle && (
            <span className="px-3.5 py-1 rounded-lg text-[16px] font-bold bg-[#EDE6D2] text-[#8E630D] border border-[#C59B27]/30 shrink-0">
              {currentTitle}
            </span>
          )}
          <span className="text-[22px] font-semibold text-[#1F2421] tracking-wide truncate">
            {currentContent}
          </span>
        </div>

        {/* Step Indicator Dots for Rotating Announcements */}
        {activeList.length > 1 && (
          <div className="flex items-center gap-2 shrink-0 pl-4">
            {activeList.map((_, idx) => (
              <span
                key={idx}
                className={`h-2 rounded-full transition-all duration-300 ${
                  idx === safeIndex
                    ? 'w-7 bg-[#8E630D]'
                    : 'w-2 bg-[#C59B27]/30'
                }`}
              />
            ))}
          </div>
        )}
      </div>

      {/* Subtle Right Brand Mark */}
      <div className="relative z-20 px-6 h-full flex items-center bg-[#EDE6D2] border-l border-[#C59B27]/30 text-[16px] font-bold text-[#8E630D] font-mono tracking-wider shrink-0 select-none">
        HAMBURG
      </div>
    </footer>
  );
};
