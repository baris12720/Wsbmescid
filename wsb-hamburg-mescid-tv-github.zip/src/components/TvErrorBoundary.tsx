import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  errorMessage: string;
  recoverySeconds: number;
}

export class TvErrorBoundary extends Component<Props, State> {
  private timer: any = null;

  public state: State = {
    hasError: false,
    errorMessage: '',
    recoverySeconds: 5,
  };

  public static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      errorMessage: error.message || 'Bilinmeyen bir hata oluştu',
      recoverySeconds: 5,
    };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('TV Error Boundary caught an exception:', error, errorInfo);

    // Auto-recover after 5 seconds to ensure TV screen doesn't stay dead
    this.timer = setInterval(() => {
      this.setState((prev) => {
        if (prev.recoverySeconds <= 1) {
          clearInterval(this.timer);
          window.location.reload();
          return { ...prev, recoverySeconds: 0 };
        }
        return { ...prev, recoverySeconds: prev.recoverySeconds - 1 };
      });
    }, 1000);
  }

  public componentWillUnmount() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="w-screen h-screen flex flex-col items-center justify-center bg-[#FAF9F5] text-[#232724] p-8 text-center select-none font-sans">
          <div className="max-w-md p-6 rounded-3xl bg-white border border-[#EADBBD] shadow-xl flex flex-col items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#F6ECD2] text-[#8E630D] flex items-center justify-center font-bold text-xl">
              WSB
            </div>
            <h2 className="text-lg font-black font-cinzel text-[#8E630D]">
              WSB Hamburg Mescid TV
            </h2>
            <p className="text-xs text-[#555E57] leading-relaxed">
              Ekran güvenli biçimde yeniden başlatılıyor. Otomatik toparlanma süresi:
            </p>
            <div className="px-4 py-2 rounded-xl bg-[#FAF2DE] border border-[#C59B27] font-mono font-black text-xl text-[#8E630D]">
              {this.state.recoverySeconds}s
            </div>
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 rounded-xl bg-[#8E630D] text-white text-xs font-bold shadow-md hover:bg-[#724e09] transition-all"
            >
              Hemen Yenile
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
