import { Language } from '../types';

export interface Translations {
  appName: string;
  subTitle: string;
  dailyPrayerTimes: string;
  nextPrayer: string;
  timeRemaining: string;
  nowInPrayer: string;
  hamburLocation: string;
  dailyVerse: string;
  dailyHadith: string;
  announcements: string;
  fridayPrayerTitle: string;
  khutbahTime: string;
  firstJummah: string;
  secondJummah: string;
  ramadanMode: string;
  iftarCountdown: string;
  sahurCountdown: string;
  untilIftar: string;
  untilSahur: string;
  online: string;
  offline: string;
  lastUpdated: string;
  screenWakeLockActive: string;
  screenWakeLockInactive: string;
  adminPanel: string;
  enterPin: string;
  pinPlaceholder: string;
  unlock: string;
  close: string;
  save: string;
  cancel: string;
  resetDefaults: string;
  exportSettings: string;
  importSettings: string;
  manualRefresh: string;
  testPrayerSequence: string;
  remoteGuideTitle: string;
  remoteGuideDesc: string;
  tablePrayer: string;
  tableAdhan: string;
  tableIqama: string;
  timeUntilPrayer: string;
  jummahPrayer: string;
  sunriseLabel: string;
  sunsetLabel: string;
  
  // Prayer names
  prayers: {
    fajr: string;
    sunrise: string;
    dhuhr: string;
    asr: string;
    maghrib: string;
    isha: string;
  };

  // Admin tabs
  tabs: {
    prayers: string;
    display: string;
    fridayRamadan: string;
    dailyContent: string;
    announcements: string;
    animations: string;
    backup: string;
    androidTv: string;
  };

  // Admin fields
  fields: {
    calculationMethod: string;
    asrMethod: string;
    minuteAdjustments: string;
    languageMode: string;
    fixedLanguage: string;
    autoRotate: string;
    rotationInterval: string;
    theme: string;
    enableAnimation: string;
    ayahDuration: string;
    hadithDuration: string;
    adminPin: string;
    fridayActive: string;
    ramadanActive: string;
    hijriAdjustment: string;
  };

  // Units
  hours: string;
  minutes: string;
  seconds: string;
}

export const TRANSLATIONS: Record<Language, Translations> = {
  tr: {
    appName: 'WSB MESCİD HAMBURG',
    subTitle: 'Wilhelmsburger Sport und Bildung e.V.',
    dailyPrayerTimes: 'GÜNLÜK NAMAZ VAKİTLERİ',
    nextPrayer: 'Sıradaki Vakit',
    timeRemaining: 'kaldı',
    nowInPrayer: 'VAKİT GİRDİ',
    hamburLocation: 'Hamburg, Almanya',
    dailyVerse: 'GÜNÜN ÂYET-İ KERÎMESİ',
    dailyHadith: 'GÜNÜN HADÎS-İ ŞERÎFİ',
    announcements: 'CAMİ DUYURULARI',
    fridayPrayerTitle: 'CUMA BİLGİLENDİRMESİ',
    khutbahTime: 'Hutbe',
    firstJummah: '1. Cuma',
    secondJummah: '2. Cuma',
    ramadanMode: 'RAMAZAN-I ŞERİF',
    iftarCountdown: 'İftara Kalan Süre',
    sahurCountdown: 'Sahura Kalan Süre',
    untilIftar: 'İftara',
    untilSahur: 'Sahura / İmsak',
    online: 'Çevrim içi',
    offline: 'Çevrim dışı (Kayıtlı Vakitler)',
    lastUpdated: 'Son Güncelleme',
    screenWakeLockActive: 'Ekran Koruyucu Devre Dışı (Aktif)',
    screenWakeLockInactive: 'Ekran Uyanık Tutulamadı',
    adminPanel: 'Yönetici Paneli',
    enterPin: '4 Haneli PIN Kodunu Giriniz',
    pinPlaceholder: 'PIN',
    unlock: 'Giriş Yap',
    close: 'Kapat',
    save: 'Kaydet',
    cancel: 'İptal',
    resetDefaults: 'Varsayılanlara Sıfırla',
    exportSettings: 'Ayarları Yedekle (JSON)',
    importSettings: 'Yedekten Geri Yükle',
    manualRefresh: 'Vakitleri Yenile',
    testPrayerSequence: 'Ezan Vakti Animasyonunu Test Et',
    remoteGuideTitle: 'TV Kumandası Kılavuzu',
    remoteGuideDesc: 'Kumanda yön tuşları (D-Pad) ile gezinin, Tamam (OK) ile seçin. Menü veya "M" tuşu ile yönetici panelini açabilirsiniz.',
    tablePrayer: 'VAKİT',
    tableAdhan: 'EZAN',
    tableIqama: 'İKAMET',
    timeUntilPrayer: 'VAKTİNE KALAN SÜRE',
    jummahPrayer: 'CUMA',
    sunriseLabel: 'GÜNEŞ',
    sunsetLabel: 'GÜNBATIMI',
    
    prayers: {
      fajr: 'İmsak',
      sunrise: 'Güneş',
      dhuhr: 'Öğle',
      asr: 'İkindi',
      maghrib: 'Akşam',
      isha: 'Yatsı',
    },

    tabs: {
      prayers: 'Vakit Ayarları',
      display: 'Dil & Görünüm',
      fridayRamadan: 'Cuma & Ramazan',
      dailyContent: 'Âyet & Hadis',
      announcements: 'Duyurular',
      animations: 'Animasyon & Ekran',
      backup: 'Yedekleme',
      androidTv: 'Android TV APK',
    },

    fields: {
      calculationMethod: 'Hesaplama Yöntemi',
      asrMethod: 'İkindi Vakti Hesabı',
      minuteAdjustments: 'Dakika İnce Ayarları (+ / -)',
      languageMode: 'Dil Gösterim Modu',
      fixedLanguage: 'Sabit Dil',
      autoRotate: 'Otomatik Dil Değişimi',
      rotationInterval: 'Değişim Süresi (Saniye)',
      theme: 'Renk Teması',
      enableAnimation: 'Namaz Vakti Otomatik Âyet/Hadis Sekansı',
      ayahDuration: 'Âyet Gösterim Süresi (sn)',
      hadithDuration: 'Hadis Gösterim Süresi (sn)',
      adminPin: 'Yönetici PIN Kodu',
      fridayActive: 'Cuma Bilgilendirme Kartını Göster',
      ramadanActive: 'Ramazan Modunu Etkinleştir',
      hijriAdjustment: 'Hicrî Tarih Düzeltmesi (Gün)',
    },

    hours: 'sa',
    minutes: 'dk',
    seconds: 'sn',
  },

  ar: {
    appName: 'مسجد فيلهلمسبورغ هامبورغ',
    subTitle: 'جمعية فيلهلمسبورغ للرياضة والتعليم · ألمانيا',
    dailyPrayerTimes: 'مواقيت الصلاة اليومية',
    nextPrayer: 'الصلاة القادمة',
    timeRemaining: 'متبقي',
    nowInPrayer: 'حان الآن وقت الصلاة',
    hamburLocation: 'هامبورغ، ألمانيا',
    dailyVerse: 'آية اليوم المباركة',
    dailyHadith: 'الحديث النبوي الشريف',
    announcements: 'إعلانات المسجد',
    fridayPrayerTitle: 'صلاة الجمعة المباركة',
    khutbahTime: 'الخطبة',
    firstJummah: 'الجمعة الأولى',
    secondJummah: 'الجمعة الثانية',
    ramadanMode: 'شهر رمضان المبارك',
    iftarCountdown: 'الوقت المتبقي حتى الإفطار',
    sahurCountdown: 'الوقت المتبقي حتى السحور',
    untilIftar: 'حتى الإفطار',
    untilSahur: 'حتى الإمساك',
    online: 'متصل بالإنترنت',
    offline: 'غير متصل (المواقيت المحفوظة)',
    lastUpdated: 'آخر تحديث',
    screenWakeLockActive: 'شاشة التلفاز نشطة دائماً',
    screenWakeLockInactive: 'تعذر تثبيت قفل الشاشة',
    adminPanel: 'لوحة تحكم الإدارة',
    enterPin: 'أدخل رمز الحماية (PIN)',
    pinPlaceholder: 'الرمز',
    unlock: 'دخول',
    close: 'إغلاق',
    save: 'حفظ التعديلات',
    cancel: 'إلغاء',
    resetDefaults: 'استعادة الضبط الافتراضي',
    exportSettings: 'نسخ احتياطي للإعدادات',
    importSettings: 'استعادة النسخة الاحتياطية',
    manualRefresh: 'تحديث المواقيت الآن',
    testPrayerSequence: 'تجربة انتقال وقت الصلاة',
    remoteGuideTitle: 'دليل استخدام جهاز التحكم (الريموت)',
    remoteGuideDesc: 'استخدم أسهم جهاز التحكم للتنقل وزر OK للاختيار. اضغط على زر Menu لفتح لوحة الإدارة.',
    tablePrayer: 'الصلاة',
    tableAdhan: 'الأذان',
    tableIqama: 'الإقامة',
    timeUntilPrayer: 'الوقت المتبقي حتى',
    jummahPrayer: 'الجمعة',
    sunriseLabel: 'الشروق',
    sunsetLabel: 'الغروب',

    prayers: {
      fajr: 'الفجر',
      sunrise: 'الشروق',
      dhuhr: 'الظهر',
      asr: 'العصر',
      maghrib: 'المغرب',
      isha: 'العشاء',
    },

    tabs: {
      prayers: 'المواقيت والحساب',
      display: 'اللغة والمظهر',
      fridayRamadan: 'الجمعة ورمضان',
      dailyContent: 'الآيات والأحاديث',
      announcements: 'الإعلانات',
      animations: 'الحركات والشاشة',
      backup: 'النسخ الاحتياطي',
      androidTv: 'تطبيق أندرويد TV',
    },

    fields: {
      calculationMethod: 'طريقة الحساب المعتمدة',
      asrMethod: 'مذهب حساب العصر',
      minuteAdjustments: 'تعديل الدقائق (+ / -)',
      languageMode: 'طريقة عرض اللغة',
      fixedLanguage: 'لغة ثابتة',
      autoRotate: 'تبديل اللغات تلقائياً',
      rotationInterval: 'فترة التبديل (بالثواني)',
      theme: 'سمة الألوان',
      enableAnimation: 'عرض الآية والحديث تلقائياً عند الأذان',
      ayahDuration: 'مدة عرض الآية (ثانية)',
      hadithDuration: 'مدة عرض الحديث (ثانية)',
      adminPin: 'رمز PIN للإدارة',
      fridayActive: 'تفعيل لوحة صلاة الجمعة',
      ramadanActive: 'تفعيل وضع رمضان',
      hijriAdjustment: 'تعديل التاريخ الهجري (بالأيام)',
    },

    hours: 'س',
    minutes: 'د',
    seconds: 'ث',
  },

  de: {
    appName: 'WSB MOSCHEE HAMBURG',
    subTitle: 'Wilhelmsburger Sport und Bildung e.V.',
    dailyPrayerTimes: 'TÄGLICHE GEBETSZEITEN',
    nextPrayer: 'Nächstes Gebet',
    timeRemaining: 'verbleibend',
    nowInPrayer: 'GEBETSZEIT ERREICHT',
    hamburLocation: 'Hamburg, Deutschland',
    dailyVerse: 'VERS DES TAGES',
    dailyHadith: 'HADITH DES TAGES',
    announcements: 'ANKÜNDIGUNGEN DER MOSCHEE',
    fridayPrayerTitle: 'FREITAGSGEBET (DUMA)',
    khutbahTime: 'Chutba',
    firstJummah: '1. Gebet',
    secondJummah: '2. Gebet',
    ramadanMode: 'DER HEILIGE MONAT RAMADAN',
    iftarCountdown: 'Verbleibende Zeit bis zum Iftar',
    sahurCountdown: 'Verbleibende Zeit bis zum Sahur',
    untilIftar: 'Bis zum Iftar',
    untilSahur: 'Bis zum Imsak',
    online: 'Online',
    offline: 'Offline (Gespeicherte Daten)',
    lastUpdated: 'Letzte Aktualisierung',
    screenWakeLockActive: 'Bildschirmruhezustand deaktiviert',
    screenWakeLockInactive: 'Bildschirmsperre nicht aktiv',
    adminPanel: 'Administrationsbereich',
    enterPin: '4-stelligen PIN-Code eingeben',
    pinPlaceholder: 'PIN',
    unlock: 'Anmelden',
    close: 'Schließen',
    save: 'Speichern',
    cancel: 'Abbrechen',
    resetDefaults: 'Auf Standard zurücksetzen',
    exportSettings: 'Einstellungen sichern (JSON)',
    importSettings: 'Sicherung wiederherstellen',
    manualRefresh: 'Zeiten jetzt aktualisieren',
    testPrayerSequence: 'Gebetszeit-Animation testen',
    remoteGuideTitle: 'TV-Fernbedienung Anleitung',
    remoteGuideDesc: 'Verwenden Sie die Pfeiltasten (D-Pad) und OK zur Navigation. Menü- oder M-Taste öffnet das Einstellungsmenü.',
    tablePrayer: 'GEBET',
    tableAdhan: 'ADHAN',
    tableIqama: 'IQAMA',
    timeUntilPrayer: 'ZEIT BIS ZUM',
    jummahPrayer: 'DUMA',
    sunriseLabel: 'AUFGANG',
    sunsetLabel: 'UNTERGANG',

    prayers: {
      fajr: 'Fadschr',
      sunrise: 'Sonnenaufgang',
      dhuhr: 'Dhuhr',
      asr: 'Asr',
      maghrib: 'Maghrib',
      isha: 'Ischaa',
    },

    tabs: {
      prayers: 'Gebetszeiten',
      display: 'Sprache & Design',
      fridayRamadan: 'Freitag & Ramadan',
      dailyContent: 'Verse & Hadithe',
      announcements: 'Mitteilungen',
      animations: 'Animation & Display',
      backup: 'Sicherung',
      androidTv: 'Android TV APK',
    },

    fields: {
      calculationMethod: 'Berechnungsmethode',
      asrMethod: 'Asr-Berechnung (Schafi/Hanafi)',
      minuteAdjustments: 'Minuten-Feinabstimmung (+ / -)',
      languageMode: 'Sprachanzeigemodus',
      fixedLanguage: 'Feste Sprache',
      autoRotate: 'Automatische Sprachrotation',
      rotationInterval: 'Rotationsintervall (Sekunden)',
      theme: 'Farbschema',
      enableAnimation: 'Automatische Vers/Hadith-Anzeige zum Gebet',
      ayahDuration: 'Vers-Anzeigedauer (Sek.)',
      hadithDuration: 'Hadith-Anzeigedauer (Sek.)',
      adminPin: 'Administrator-PIN',
      fridayActive: 'Freitagsgebet-Banner anzeigen',
      ramadanActive: 'Ramadan-Modus aktivieren',
      hijriAdjustment: 'Hidschri-Korrektur (Tage)',
    },

    hours: 'Std',
    minutes: 'Min',
    seconds: 'Sek',
  },

  en: {
    appName: 'WSB MOSQUE HAMBURG',
    subTitle: 'Wilhelmsburger Sport und Bildung e.V. · Germany',
    dailyPrayerTimes: 'DAILY PRAYER TIMES',
    nextPrayer: 'Next Prayer',
    timeRemaining: 'left',
    nowInPrayer: 'PRAYER TIME ENTERED',
    hamburLocation: 'Hamburg, Germany',
    dailyVerse: 'VERSE OF THE DAY',
    dailyHadith: 'HADITH OF THE DAY',
    announcements: 'MOSQUE ANNOUNCEMENTS',
    fridayPrayerTitle: 'FRIDAY PRAYER (JUMU’AH)',
    khutbahTime: 'Khutbah',
    firstJummah: '1st Jamah',
    secondJummah: '2nd Jamah',
    ramadanMode: 'BLESSED RAMADAN',
    iftarCountdown: 'Time Remaining Until Iftar',
    sahurCountdown: 'Time Remaining Until Sahur',
    untilIftar: 'Until Iftar',
    untilSahur: 'Until Fajr/Imsak',
    online: 'Online',
    offline: 'Offline (Stored Schedule)',
    lastUpdated: 'Last Updated',
    screenWakeLockActive: 'Screen Wake Lock Active (Continuous)',
    screenWakeLockInactive: 'Screen Wake Lock Unavailable',
    adminPanel: 'Admin Control Panel',
    enterPin: 'Enter 4-Digit Security PIN',
    pinPlaceholder: 'PIN',
    unlock: 'Unlock',
    close: 'Close',
    save: 'Save Changes',
    cancel: 'Cancel',
    resetDefaults: 'Reset to Factory Defaults',
    exportSettings: 'Export Settings (JSON)',
    importSettings: 'Import Backup',
    manualRefresh: 'Refresh Timings Now',
    testPrayerSequence: 'Test Prayer Time Sequence',
    remoteGuideTitle: 'TV Remote Navigation Guide',
    remoteGuideDesc: 'Use D-Pad arrows and OK to navigate. Press Menu button or key "M" to access the administration panel.',
    tablePrayer: 'PRAYER',
    tableAdhan: 'ADHAN',
    tableIqama: 'IQAMA',
    timeUntilPrayer: 'TIME UNTIL',
    jummahPrayer: 'JUMMAH',
    sunriseLabel: 'SUNRISE',
    sunsetLabel: 'SUNSET',

    prayers: {
      fajr: 'Fajr',
      sunrise: 'Sunrise',
      dhuhr: 'Dhuhr',
      asr: 'Asr',
      maghrib: 'Maghrib',
      isha: 'Isha',
    },

    tabs: {
      prayers: 'Prayer Timings',
      display: 'Language & Theme',
      fridayRamadan: 'Friday & Ramadan',
      dailyContent: 'Verses & Hadiths',
      announcements: 'Announcements',
      animations: 'Display & Animation',
      backup: 'Backup & Restore',
      androidTv: 'Android TV APK',
    },

    fields: {
      calculationMethod: 'Calculation Method',
      asrMethod: 'Asr Juristic Method',
      minuteAdjustments: 'Minute Adjustments (+ / -)',
      languageMode: 'Language Display Mode',
      fixedLanguage: 'Fixed Language',
      autoRotate: 'Automatic Language Rotation',
      rotationInterval: 'Rotation Interval (Seconds)',
      theme: 'Visual Theme',
      enableAnimation: 'Auto Verse/Hadith Sequence at Prayer Time',
      ayahDuration: 'Verse Display Duration (sec)',
      hadithDuration: 'Hadith Display Duration (sec)',
      adminPin: 'Admin Security PIN',
      fridayActive: 'Display Friday Prayer Card',
      ramadanActive: 'Enable Ramadan Display Mode',
      hijriAdjustment: 'Hijri Date Adjustment (Days)',
    },

    hours: 'h',
    minutes: 'm',
    seconds: 's',
  },
};
