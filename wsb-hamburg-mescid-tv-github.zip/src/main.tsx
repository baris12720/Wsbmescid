import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { TvErrorBoundary } from './components/TvErrorBoundary';
import './index.css';

// Register Service Worker for PWA 7/24 TV Kiosk Installability
if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    (window.location.hostname === 'appassets.androidplatform.net'
      ? Promise.reject(new Error('service worker skipped in APK'))
      : navigator.serviceWorker.register('/sw.js')).catch((err) => {
      console.warn('PWA Service Worker registration error:', err);
    });
  });
}

createRoot(document.getElementById('root')!).render(
  <TvErrorBoundary>
    <App />
  </TvErrorBoundary>
);


