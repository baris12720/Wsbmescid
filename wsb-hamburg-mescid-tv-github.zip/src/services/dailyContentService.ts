import { AyahItem, HadithItem, DailyPair, Language } from '../types';
import ayetlerRaw from '../data/ayetler.json';
import hadislerRaw from '../data/hadisler.json';

// Fixed anchor start date (Europe/Berlin timezone) for deterministic 200-day cycle
export const CONTENT_EPOCH_START = '2024-01-01';
export const TOTAL_DAILY_CONTENT_COUNT = 200;

export interface ContentValidationReport {
  isValid: boolean;
  ayahCount: number;
  hadithCount: number;
  uniqueAyahIds: number;
  uniqueHadithIds: number;
  allLanguagesValid: boolean;
  cycleTestPassed: boolean;
  errors: string[];
  verifiedAt: string;
}

class DailyContentService {
  private ayahs: AyahItem[] = [];
  private hadiths: HadithItem[] = [];
  private pairs: DailyPair[] = [];
  private validationReport: ContentValidationReport | null = null;

  constructor() {
    this.loadData();
    this.runValidationTests();
  }

  private loadData(): void {
    this.ayahs = (ayetlerRaw as unknown) as AyahItem[];
    this.hadiths = (hadislerRaw as unknown) as HadithItem[];

    // Pair each Ayah with its corresponding Hadith (1:1 up to 200)
    const count = Math.min(this.ayahs.length, this.hadiths.length);
    this.pairs = [];
    for (let i = 0; i < count; i++) {
      this.pairs.push({
        id: `pair-${i + 1}`,
        ayah: this.ayahs[i],
        hadith: this.hadiths[i],
      });
    }
  }

  /**
   * Run validation test suite covering all 200 ayahs & hadiths
   */
  public runValidationTests(): ContentValidationReport {
    const errors: string[] = [];

    // 1. Count checks
    if (this.ayahs.length !== TOTAL_DAILY_CONTENT_COUNT) {
      errors.push(`Ayet sayısı hatalı: Beklenen 200, bulunan ${this.ayahs.length}`);
    }
    if (this.hadiths.length !== TOTAL_DAILY_CONTENT_COUNT) {
      errors.push(`Hadis sayısı hatalı: Beklenen 200, bulunan ${this.hadiths.length}`);
    }

    // 2. Uniqueness & integrity checks for Ayahs
    const ayahIdSet = new Set<string>();
    const requiredLangs: Language[] = ['tr', 'ar', 'de', 'en'];

    this.ayahs.forEach((a, idx) => {
      if (ayahIdSet.has(a.id)) {
        errors.push(`Ayet ID tekrarı bulundu: ${a.id}`);
      }
      ayahIdSet.add(a.id);

      if (!a.arabic || a.arabic.trim() === '') {
        errors.push(`Ayet #${idx + 1} (${a.id}) Arapça metni boş!`);
      }
      if (!a.reference || a.reference.trim() === '') {
        errors.push(`Ayet #${idx + 1} (${a.id}) kaynak alanı boş!`);
      }

      requiredLangs.forEach((lang) => {
        if (!a.translations || !a.translations[lang] || a.translations[lang].trim() === '') {
          errors.push(`Ayet #${idx + 1} (${a.id}) ${lang.toUpperCase()} tercümesi eksik!`);
        }
        if (!a.surahName || !a.surahName[lang] || a.surahName[lang].trim() === '') {
          errors.push(`Ayet #${idx + 1} (${a.id}) ${lang.toUpperCase()} sure adı eksik!`);
        }
      });
    });

    // 3. Uniqueness & integrity checks for Hadiths
    const hadithIdSet = new Set<string>();
    this.hadiths.forEach((h, idx) => {
      if (hadithIdSet.has(h.id)) {
        errors.push(`Hadis ID tekrarı bulundu: ${h.id}`);
      }
      hadithIdSet.add(h.id);

      if (!h.arabic || h.arabic.trim() === '') {
        errors.push(`Hadis #${idx + 1} (${h.id}) Arapça metni boş!`);
      }
      if (!h.source || h.source.trim() === '') {
        errors.push(`Hadis #${idx + 1} (${h.id}) kaynak alanı boş!`);
      }

      requiredLangs.forEach((lang) => {
        if (!h.translations || !h.translations[lang] || h.translations[lang].trim() === '') {
          errors.push(`Hadis #${idx + 1} (${h.id}) ${lang.toUpperCase()} tercümesi eksik!`);
        }
      });
    });

    // 4. Deterministic cycle test (verifying 200-day wraparound)
    let cycleTestPassed = true;
    for (let testDay = 0; testDay <= 600; testDay++) {
      const idx = testDay % 200;
      if (idx < 0 || idx >= 200) {
        cycleTestPassed = false;
        errors.push(`Döngü testi hatası: Gün ${testDay} için geçersiz indeks ${idx}`);
        break;
      }
    }

    const isValid = errors.length === 0 && cycleTestPassed;

    this.validationReport = {
      isValid,
      ayahCount: this.ayahs.length,
      hadithCount: this.hadiths.length,
      uniqueAyahIds: ayahIdSet.size,
      uniqueHadithIds: hadithIdSet.size,
      allLanguagesValid: errors.filter((e) => e.includes('tercümesi')).length === 0,
      cycleTestPassed,
      errors,
      verifiedAt: new Date().toISOString(),
    };

    if (!isValid) {
      console.error('[WSB Content Validation] ERRORS FOUND:', errors);
    } else {
      console.log(`[WSB Content Validation] ✓ 200 Âyet & 200 Hadîs başarıyla doğrulandı. Döngü testi başarılı.`);
    }

    return this.validationReport;
  }

  /**
   * Deterministically calculate the day index (0 to 199) based on Hamburg local date (Europe/Berlin)
   */
  public getDayIndexForDate(date: Date = new Date()): number {
    // Format to YYYY-MM-DD in Europe/Berlin
    const berlinDateStr = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Europe/Berlin',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(date); // Output format: "YYYY-MM-DD"

    const epochDate = new Date(`${CONTENT_EPOCH_START}T00:00:00Z`);
    const targetDate = new Date(`${berlinDateStr}T00:00:00Z`);

    const diffMs = targetDate.getTime() - epochDate.getTime();
    const elapsedDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    // True mathematical modulo (guarantees 0 <= index < 200 even for negative offsets)
    const dayIndex = ((elapsedDays % TOTAL_DAILY_CONTENT_COUNT) + TOTAL_DAILY_CONTENT_COUNT) % TOTAL_DAILY_CONTENT_COUNT;
    return dayIndex;
  }

  /**
   * Returns today's verified pair for the current Hamburg date
   */
  public getTodayPair(date: Date = new Date()): DailyPair {
    const index = this.getDayIndexForDate(date);
    return this.pairs[index] || this.pairs[0];
  }

  /**
   * Returns the 1-based day number in the 200-day cycle (e.g. 1 to 200)
   */
  public getTodaySequenceNumber(date: Date = new Date()): number {
    return this.getDayIndexForDate(date) + 1;
  }

  /**
   * Get all 200 verified pairs
   */
  public getAllPairs(): DailyPair[] {
    return this.pairs;
  }

  /**
   * Get all 200 ayahs
   */
  public getAllAyahs(): AyahItem[] {
    return this.ayahs;
  }

  /**
   * Get all 200 hadiths
   */
  public getAllHadiths(): HadithItem[] {
    return this.hadiths;
  }

  /**
   * Get cached validation report
   */
  public getValidationReport(): ContentValidationReport {
    if (!this.validationReport) {
      return this.runValidationTests();
    }
    return this.validationReport;
  }
}

export const dailyContentService = new DailyContentService();
