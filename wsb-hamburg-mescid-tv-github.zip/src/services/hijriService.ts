import { Language, IslamicDay } from '../types';
import { ISLAMIC_DAYS_LIST } from '../constants/initialData';
import { officialHijriService } from './officialHijriService';

const HIJRI_MONTHS: Record<number, Record<Language, string>> = {
  1: { tr: 'Muharrem', ar: 'محرّم', de: 'Muharram', en: 'Muharram' },
  2: { tr: 'Safer', ar: 'صفر', de: 'Safar', en: 'Safar' },
  3: { tr: 'Rebiülevvel', ar: 'ربيع الأول', de: 'Rabi al-Awwal', en: 'Rabi’ al-Awwal' },
  4: { tr: 'Rebiülahir', ar: 'ربيع الثاني', de: 'Rabi al-Thani', en: 'Rabi’ al-Thani' },
  5: { tr: 'Cemaziyelevvel', ar: 'جمادى الأولى', de: 'Dschumada l-ula', en: 'Jumada al-Awwal' },
  6: { tr: 'Cemaziyelahir', ar: 'جمادى الآخرة', de: 'Dschumada l-achira', en: 'Jumada al-Thani' },
  7: { tr: 'Recep', ar: 'رجب', de: 'Radschab', en: 'Rajab' },
  8: { tr: 'Şaban', ar: 'شعبان', de: 'Schaban', en: 'Sha’ban' },
  9: { tr: 'Ramazan', ar: 'رمضان', de: 'Ramadan', en: 'Ramadan' },
  10: { tr: 'Şevval', ar: 'شوّال', de: 'Schawwal', en: 'Shawwal' },
  11: { tr: 'Zilkade', ar: 'ذو القعدة', de: 'Dhu l-Qada', en: 'Dhul-Qadah' },
  12: { tr: 'Zilhicce', ar: 'ذو الحجة', de: 'Dhu l-Hiddscha', en: 'Dhul-Hijjah' },
};

export const hijriService = {
  getHijriDate(date: Date = new Date(), adjustmentDays: number = 0): {
    day: number;
    month: number;
    year: number;
    monthName: Record<Language, string>;
    isRamadan: boolean;
  } {
    // Official (Diyanet) Hijri calendar from the internet / device storage overrides the manual adjustment
    adjustmentDays = officialHijriService.adjustmentFor(date, adjustmentDays);
    // Adjust target date by offset
    const adjustedDate = new Date(date);
    adjustedDate.setDate(adjustedDate.getDate() + adjustmentDays);

    try {
      // Use modern Intl API for Islamic Umalqura calendar
      const formatter = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', {
        day: 'numeric',
        month: 'numeric',
        year: 'numeric',
      });
      const parts = formatter.formatToParts(adjustedDate);
      let day = 1;
      let month = 1;
      let year = 1448;

      parts.forEach((p) => {
        if (p.type === 'day') day = parseInt(p.value, 10);
        if (p.type === 'month') month = parseInt(p.value, 10);
        if (p.type === 'year') year = parseInt(p.value, 10);
      });

      const monthName = HIJRI_MONTHS[month] || {
        tr: `Ay ${month}`,
        ar: `شهر ${month}`,
        de: `Monat ${month}`,
        en: `Month ${month}`,
      };

      return {
        day,
        month,
        year,
        monthName,
        isRamadan: month === 9,
      };
    } catch (e) {
      // Fallback approximation if Intl islamic calendar is not fully supported
      return {
        day: 14,
        month: 5,
        year: 1448,
        monthName: HIJRI_MONTHS[5],
        isRamadan: false,
      };
    }
  },

  formatHijriDate(date: Date, lang: Language, adjustmentDays: number = 0): string {
    const { day, month, year, monthName } = this.getHijriDate(date, adjustmentDays);
    const mName = monthName[lang] || monthName.tr;

    if (lang === 'ar') {
      // Arabic numerals format
      return `${day} ${mName} ${year} هـ`;
    }
    return `${day} ${mName} ${year} H.`;
  },

  getUpcomingIslamicDay(
    date: Date = new Date(),
    adjustmentDays: number = 0
  ): { dayInfo: IslamicDay; daysLeft: number } | null {
    const { day, month } = this.getHijriDate(date, adjustmentDays);

    for (const item of ISLAMIC_DAYS_LIST) {
      if (item.hijriMonth === month && item.hijriDay === day) {
        return { dayInfo: item, daysLeft: 0 };
      }
      if (item.hijriMonth === month && item.hijriDay > day && item.hijriDay - day <= 10) {
        return { dayInfo: item, daysLeft: item.hijriDay - day };
      }
    }
    return null;
  },
};
