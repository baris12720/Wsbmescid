import { Language, PrayerTimes } from '../types';
import { hijriService } from './hijriService';

export interface IslamicSpecialEvent {
  id: string;
  type: 'kandil' | 'eid' | 'ramadan' | 'three-months' | 'friday' | 'general';
  isToday: boolean;
  isTonight: boolean;
  daysRemaining: number;
  title: Record<Language, string>;
  subtitle: Record<Language, string>;
  badgeText: Record<Language, string>;
  celebrationGreeting: {
    heading: Record<Language, string>;
    message: Record<Language, string>;
    badge: Record<Language, string>;
  };
  hijriLabel: Record<Language, string>;
}

export interface IslamicCountdownItem {
  id: string;
  type: 'three-months' | 'kandil' | 'ramadan' | 'eid' | 'general';
  title: Record<Language, string>;
  shortName: Record<Language, string>;
  hijriLabel: Record<Language, string>;
  daysRemaining: number;
  orderIndex: number;
  description: Record<Language, string>;
}

export interface RamadanCountdownInfo {
  isRamadan: boolean;
  isFastingTime: boolean; // Daytime between Fajr and Maghrib
  phase: 'iftar' | 'sahur' | 'none';
  label: Record<Language, string>;
  targetTimeStr: string;
  hours: number;
  minutes: number;
  seconds: number;
  formattedCountdown: string;
}

// Fixed annual Islamic milestones in the Hijri calendar
export const ISLAMIC_ANNUAL_CALENDAR = [
  {
    id: 'three-months-start',
    type: 'three-months' as const,
    month: 7, // Rajab
    day: 1,
    title: {
      tr: 'Üç Ayların Başlangıcı (1 Recep)',
      ar: 'غرّة شهر رجب المبارك (بداية الأشهر الحرم)',
      de: 'Beginn der Drei Heiligen Monate (1. Radschab)',
      en: 'Beginning of the Three Holy Months (1st Rajab)',
    },
    shortName: {
      tr: 'Üç Ayların Başlangıcı',
      ar: 'بداية الأشهر الحرم',
      de: 'Beginn 3 Monate',
      en: 'Three Holy Months',
    },
    hijriLabel: {
      tr: '1 Recep',
      ar: '١ رجب',
      de: '1. Radschab',
      en: '1st Rajab',
    },
    subtitle: {
      tr: '“Allahım! Recep ve Şaban’ı bize mübarek kıl, bizi Ramazan’a ulaştır.”',
      ar: '«اللَّهُمَّ بَارِكْ لَنَا فِي رَجَبٍ وَشَعْبَانَ، وَبَلِّغْنَا رَمَضَانَ»',
      de: '„O Allah, segne uns in Radschab und Schaban und lass uns den Ramadan erreichen.“',
      en: '“O Allah, bless us in Rajab and Sha’ban, and allow us to reach Ramadan.”',
    },
    celebrationGreeting: {
      heading: {
        tr: 'Mübarek Üç Aylarınız Kutlu Olsun',
        ar: 'مبارك عليكم حلول الأشهر الحرم المباركة',
        de: 'Gesegnete Drei Heilige Monate',
        en: 'Blessed Three Sacred Months',
      },
      message: {
        tr: 'Recep, Şaban ve Ramazan-ı Şerif’in manevi iklimine adım attığımız bu kutlu gün tüm İslam alemine ve hanelerimize bereket getirsin.',
        ar: '«اللَّهُمَّ بَارِكْ لَنَا فِي رَجَبٍ وَشَعْبَانَ وَبَلِّغْنَا رَمَضَانَ» - تقبل الله طاعاتكم وصالح أعمالكم.',
        de: 'Willkommen in der gesegneten Zeit der geistigen Erneuerung und Vorbereitung auf den Ramadan.',
        en: 'May the season of mercy, forgiveness, and spiritual elevation bring peace to our hearts.',
      },
      badge: {
        tr: '✦ ÜÇ AYLAR BAŞLANGICI ✦',
        ar: '✦ الأشهر الحرم المباركة ✦',
        de: '✦ DREI HEILIGE MONATE ✦',
        en: '✦ THREE HOLY MONTHS ✦',
      },
    },
  },
  {
    id: 'miraj',
    type: 'kandil' as const,
    month: 7, // Rajab
    day: 27,
    title: {
      tr: 'Mîrâc Kandili (27 Recep)',
      ar: 'ذكرى الإسراء والمعراج المباركة',
      de: 'Isra und Miradsch (Himmelfahrt)',
      en: 'Al-Isra wal-Mi’raj (Night of Ascension)',
    },
    shortName: {
      tr: 'Mîrâc Kandili',
      ar: 'الإسراء والمعراج',
      de: 'Miradsch-Nacht',
      en: 'Laylat al-Miraj',
    },
    hijriLabel: {
      tr: '27 Recep',
      ar: '٢٧ رجب',
      de: '27. Radschab',
      en: '27th Rajab',
    },
    subtitle: {
      tr: 'Namazın farz kılındığı ve Peygamberimizin arşa yükseldiği mübarek gece.',
      ar: 'ليلة فرضت فيها الصلوات الخمس وعرج بالحبيب ﷺ إلى السموات العلى.',
      de: 'Die Nacht der Himmelfahrt und der Einsetzung des täglichen Gebets.',
      en: 'The night of ascension and the gift of the five daily prayers.',
    },
    celebrationGreeting: {
      heading: {
        tr: 'Mîrâc Kandiliniz Mübarek Olsun',
        ar: 'مبارك عليكم ليلة الإسراء والمعراج',
        de: 'Gesegnete Miradsch-Nacht',
        en: 'Blessed Laylat al-Miraj',
      },
      message: {
        tr: 'Müminin miracı olan namazın ve ilahi lütufların feyziyle dolu mübarek Mîrâc Kandilinizi tebrik ederiz.',
        ar: 'ليلة معجزة الإسراء والمعراج المباركة وهدية الصلوات الخمس؛ نسأل الله القبول والعفو والعافية.',
        de: 'Die heilige Nacht der Himmelfahrt und des Geschenks des Gebets; möge Allah unsere Bitten erhören.',
        en: 'Commemorating the miraculous journey and the gift of Salah; may Allah illuminate our hearts.',
      },
      badge: {
        tr: '✦ MÎRÂC KANDİLİ ✦',
        ar: '✦ ليلة الإسراء والمعراج ✦',
        de: '✦ MIRADSCH-NACHT ✦',
        en: '✦ NIGHT OF ASCENSION ✦',
      },
    },
  },
  {
    id: 'barat',
    type: 'kandil' as const,
    month: 8, // Sha'ban
    day: 15,
    title: {
      tr: 'Berâat Kandili (15 Şaban)',
      ar: 'ليلة النصف من شعبان (ليلة البراءة)',
      de: 'Lailat al-Bara’a (Nacht der Vergebung)',
      en: 'Laylat al-Bara’at (Night of Forgiveness)',
    },
    shortName: {
      tr: 'Berâat Kandili',
      ar: 'ليلة البراءة',
      de: 'Bara’a-Nacht',
      en: 'Laylat al-Bara’at',
    },
    hijriLabel: {
      tr: '15 Şaban',
      ar: '١٥ شعبان',
      de: '15. Schaban',
      en: '15th Sha’ban',
    },
    subtitle: {
      tr: 'Bağışlanma, af ve duaların kabul olduğu mübarek gece.',
      ar: 'ليلة المغفرة والرحمة وإجابة الدعاء من رب العالمين.',
      de: 'Die gesegnete Nacht der Vergebung und des Bittgebets.',
      en: 'The blessed night of forgiveness and answered prayers.',
    },
    celebrationGreeting: {
      heading: {
        tr: 'Berâat Kandiliniz Mübarek Olsun',
        ar: 'مبارك عليكم ليلة النصف من شعبان المباركة',
        de: 'Gesegnete Nacht der Vergebung',
        en: 'Blessed Laylat al-Bara’at',
      },
      message: {
        tr: 'Ramazan-ı Şerif’in müjdecisi Berâat gecesinde affa, mağfirete ve ilahi rahmete nail olmanızı dileriz.',
        ar: 'ليلة تنزل الرحمات ومغفرة الذنوب واستجابة الدعوات؛ تقبل الله منا ومنكم صالح الأعمال.',
        de: 'Eine Nacht des Verzeihens, der Erlösung von Sünden und der Vorbereitung auf den heiligen Ramadan.',
        en: 'A night of divine pardon, emancipation, and spiritual purification before Ramadan.',
      },
      badge: {
        tr: '✦ BERÂAT KANDİLİ ✦',
        ar: '✦ ليلة البراءة ✦',
        de: '✦ LAILAT AL-BARA’A ✦',
        en: '✦ NIGHT OF FORGIVENESS ✦',
      },
    },
  },
  {
    id: 'ramadan-start',
    type: 'ramadan' as const,
    month: 9, // Ramadan
    day: 1,
    title: {
      tr: 'Ramazan-ı Şerif Başlangıcı (1 Ramazan)',
      ar: 'أول أيام شهر رمضان المبارك',
      de: 'Beginn des heiligen Monats Ramadan',
      en: 'First Day of Holy Ramadan',
    },
    shortName: {
      tr: 'Ramazan Başlangıcı',
      ar: 'بداية شهر رمضان',
      de: 'Beginn Ramadan',
      en: 'Start of Ramadan',
    },
    hijriLabel: {
      tr: '1 Ramazan',
      ar: '١ رمضان',
      de: '1. Ramadan',
      en: '1st Ramadan',
    },
    subtitle: {
      tr: 'On bir ayın sultanı Ramazan-ı Şerifiniz mübarek olsun.',
      ar: 'شهر الصيام والقيام وتلاوة القرآن الكريم.',
      de: 'Der Monat des Fastens, der Besinnung und des Korans.',
      en: 'The sacred month of fasting, prayer, and the Quran.',
    },
    celebrationGreeting: {
      heading: {
        tr: 'Hoş Geldin Ya Şehr-i Ramazan',
        ar: 'أهلاً بشهر القرآن والرحمة والمغفرة',
        de: 'Willkommen gesegneter Ramadan',
        en: 'Welcome Holy Month of Ramadan',
      },
      message: {
        tr: 'On bir ayın sultanı mübarek Ramazan-ı Şerif hanelerimize bereket, kalplerimize huzur ve arınma getirsin.',
        ar: 'مبارك عليكم شهر رمضان المبارك، نسأل الله أن يتقبل صيامكم وقيامكم وصالح دعواتكم.',
        de: 'Möge dieser heilige Monat des Fastens und des Friedens Segen und Eintracht für alle Familien bringen.',
        en: 'May the blessed month of fasting, reflection, and charity bring light, peace, and acceptance.',
      },
      badge: {
        tr: '✦ RAMAZAN-I ŞERİF ✦',
        ar: '✦ رمضان كريم ✦',
        de: '✦ RAMADAN MUBARAK ✦',
        en: '✦ RAMADAN MUBARAK ✦',
      },
    },
  },
  {
    id: 'laylat-al-qadr',
    type: 'kandil' as const,
    month: 9, // Ramadan
    day: 27,
    title: {
      tr: 'Kadir Gecesi (27 Ramazan)',
      ar: 'ليلة القدر المباركة',
      de: 'Lailat al-Qadr (Nacht der Bestimmung)',
      en: 'Laylat al-Qadr (Night of Decree)',
    },
    shortName: {
      tr: 'Kadir Gecesi',
      ar: 'ليلة القدر',
      de: 'Lailat al-Qadr',
      en: 'Laylat al-Qadr',
    },
    hijriLabel: {
      tr: '27 Ramazan',
      ar: '٢٧ رمضان',
      de: '27. Ramadan',
      en: '27th Ramadan',
    },
    subtitle: {
      tr: 'Bin aydan daha hayırlı olan Kadir Geceniz mübarek olsun.',
      ar: 'ليلة مباركة هي خير من ألف شهر، تنزل الملائكة فيها والروح.',
      de: 'Eine gesegnete Nacht, die besser ist als tausend Monate.',
      en: 'A blessed night better than a thousand months.',
    },
    celebrationGreeting: {
      heading: {
        tr: 'Kadir Geceniz Mübarek Olsun',
        ar: 'مبارك عليكم ليلة القدر المباركة',
        de: 'Gesegnete Nacht der Bestimmung',
        en: 'Blessed Laylat al-Qadr',
      },
      message: {
        tr: '«Kadir Gecesi bin aydan hayırlıdır.» Bu mübarek gecede günahlarımızın affını ve dualarımızın kabulünü dileriz.',
        ar: '«لَيْلَةُ الْقَدْرِ خَيْرٌ مِنْ أَلْفِ شَهْرٍ» - نسأل الله العفو والعافية والعتق من النار.',
        de: 'Eine Nacht von unermesslichem Wert, besser als tausend Monate; möge Allah unsere Bitten erhören.',
        en: 'Better than a thousand months; may Allah forgive our sins and envelop us in His boundless mercy.',
      },
      badge: {
        tr: '✦ KADİR GECESİ ✦',
        ar: '✦ ليلة القدر خير من ألف شهر ✦',
        de: '✦ LAILAT AL-QADR ✦',
        en: '✦ NIGHT OF DECREE ✦',
      },
    },
  },
  {
    id: 'ramadan-eid',
    type: 'eid' as const,
    month: 10, // Shawwal
    day: 1,
    title: {
      tr: 'Ramazan Bayramı (1 Şevval)',
      ar: 'عيد الفطر المبارك',
      de: 'Fest des Fastenbrechens (Eid al-Fitr)',
      en: 'Eid al-Fitr (Festival of Breaking the Fast)',
    },
    shortName: {
      tr: 'Ramazan Bayramı',
      ar: 'عيد الفطر',
      de: 'Eid al-Fitr',
      en: 'Eid al-Fitr',
    },
    hijriLabel: {
      tr: '1 Şevval',
      ar: '١ شوّال',
      de: '1. Schawwal',
      en: '1st Shawwal',
    },
    subtitle: {
      tr: 'Mübarek Ramazan Bayramınız kutlu olsun; takabbelallahu minna ve minküm.',
      ar: 'تقبل الله منا ومنكم الصيام وصالح الأعمال، وكل عام وأنتم بخير.',
      de: 'Gesegnetes Fest des Fastenbrechens für alle Muslime.',
      en: 'May Allah accept our fasting and good deeds. Eid Mubarak!',
    },
    celebrationGreeting: {
      heading: {
        tr: 'Ramazan Bayramınız Mübarek Olsun',
        ar: 'عيد فطر مبارك وتقبل الله طاعاتكم',
        de: 'Gesegnetes Eid al-Fitr',
        en: 'Eid al-Fitr Mubarak',
      },
      message: {
        tr: 'Oruçlarımızın ve dualarımızın mükâfatı olan mübarek Ramazan Bayramınızı tebrik eder, sevdiklerinizle huzur dolu günler dileriz.',
        ar: '«تقبل الله منا ومنكم الصيام وصالح الأعمال» - أعاده الله علينا وعليكم باليمن والبركات.',
        de: 'Gesegnetes Fest des Fastenbrechens; Freude, Friede und Eintracht für alle Familien.',
        en: 'May Allah accept our fasting, charity, and worship; wishing you a joyful and peaceful Eid.',
      },
      badge: {
        tr: '✦ RAMAZAN BAYRAMI ✦',
        ar: '✦ عيد الفطر المبارك ✦',
        de: '✦ EID MUBARAK ✦',
        en: '✦ EID AL-FITR ✦',
      },
    },
  },
  {
    id: 'arafah',
    type: 'general' as const,
    month: 12, // Dhu al-Hijjah
    day: 9,
    title: {
      tr: 'Arefe Günü (9 Zilhicce)',
      ar: 'يوم عرفة المبارك',
      de: 'Tag von Arafah (9. Dhu l-Hiddscha)',
      en: 'Day of Arafah (9th Dhul-Hijjah)',
    },
    shortName: {
      tr: 'Arefe Günü',
      ar: 'يوم عرفة',
      de: 'Tag von Arafah',
      en: 'Day of Arafah',
    },
    hijriLabel: {
      tr: '9 Zilhicce',
      ar: '٩ ذو الحجة',
      de: '9. Dhu l-Hiddscha',
      en: '9th Dhul-Hijjah',
    },
    subtitle: {
      tr: 'Hacıların Arafat’ta vakfeye durduğu, dua ve istiğfar günü.',
      ar: 'أفضل أيام الدنيا وخير يوم طلعت عليه الشمس.',
      de: 'Der beste Tag für Gebet und Fürbitte, Tag des Stehens auf Arafat.',
      en: 'The greatest day of supplication and fasting for non-pilgrims.',
    },
    celebrationGreeting: {
      heading: {
        tr: 'Mübarek Arefe Gününüz Kutlu Olsun',
        ar: 'يوم عرفة المبارك، خير يوم طلعت عليه الشمس',
        de: 'Gesegneter Tag von Arafah',
        en: 'Blessed Day of Arafah',
      },
      message: {
        tr: 'Duaların geri çevrilmediği Arefe gününde oruçlarımızın, tövbelerimizin ve yakarışlarımızın kabulünü dileriz.',
        ar: 'خير الدعاء دعاء يوم عرفة، أكثروا من التهليل والتكبير والدعاء لأنفسكم ولأمة الإسلام.',
        de: 'Der segensreichste Tag des Jahres für Fürbitte, Vergebung und Aufrichtigkeit vor Allah.',
        en: 'The most virtuous day for supplication and repentance; may our prayers be answered.',
      },
      badge: {
        tr: '✦ AREFE GÜNÜ ✦',
        ar: '✦ يوم عرفة المبارك ✦',
        de: '✦ TAG VON ARAFAH ✦',
        en: '✦ DAY OF ARAFAH ✦',
      },
    },
  },
  {
    id: 'eid-al-adha',
    type: 'eid' as const,
    month: 12, // Dhu al-Hijjah
    day: 10,
    title: {
      tr: 'Kurban Bayramı (10 Zilhicce)',
      ar: 'عيد الأضحى المبارك',
      de: 'Opferfest (Eid al-Adha)',
      en: 'Eid al-Adha (Feast of Sacrifice)',
    },
    shortName: {
      tr: 'Kurban Bayramı',
      ar: 'عيد الأضحى',
      de: 'Eid al-Adha',
      en: 'Eid al-Adha',
    },
    hijriLabel: {
      tr: '10 Zilhicce',
      ar: '١٠ ذو الحجة',
      de: '10. Dhu l-Hiddscha',
      en: '10th Dhul-Hijjah',
    },
    subtitle: {
      tr: 'Mübarek Kurban Bayramınız kutlu olsun; kurbanlarınız makbul olsun.',
      ar: 'عيد أضحى مبارك، تقبل الله منا ومنكم الأضاحي وصالح الأعمال.',
      de: 'Gesegnetes Opferfest für alle Familien und Brüder und Schwestern.',
      en: 'Blessed Eid al-Adha; may Allah accept our sacrifices.',
    },
    celebrationGreeting: {
      heading: {
        tr: 'Kurban Bayramınız Mübarek Olsun',
        ar: 'عيد أضحى مبارك وكل عام وأنتم بخير',
        de: 'Gesegnetes Opferfest',
        en: 'Eid al-Adha Mubarak',
      },
      message: {
        tr: 'Kurban ibadetimizin takva ve kardeşliğe vesile olmasını diler, bayramınızı en kalbi duygularla kutlarız.',
        ar: '«لَنْ يَنَالَ اللَّهَ لُحُومُهَا وَلَا دِمَاؤُهَا وَلَٰكِنْ يَنَالُهُ التَّقْوَىٰ مِنْكُمْ» - تقبل الله أضاحيكم.',
        de: 'Möge Allah unsere Opfer, Gebete und Wohltaten in Gnade annehmen.',
        en: 'May our sacrifices and devotions be accepted; wishing peace and abundance to all.',
      },
      badge: {
        tr: '✦ KURBAN BAYRAMI ✦',
        ar: '✦ عيد الأضحى المبارك ✦',
        de: '✦ EID AL-ADHA ✦',
        en: '✦ EID AL-ADHA ✦',
      },
    },
  },
  {
    id: 'hijri-new-year',
    type: 'general' as const,
    month: 1, // Muharram
    day: 1,
    title: {
      tr: 'Hicrî Yılbaşı (1 Muharrem)',
      ar: 'رأس السنة الهجرية الجديدة',
      de: 'Islamisches Neujahr (1. Muharram)',
      en: 'Hijri New Year (1st Muharram)',
    },
    shortName: {
      tr: 'Hicrî Yılbaşı',
      ar: 'رأس السنة الهجرية',
      de: 'Hicri Neujahr',
      en: 'Hijri New Year',
    },
    hijriLabel: {
      tr: '1 Muharrem',
      ar: '١ محرم',
      de: '1. Muharram',
      en: '1st Muharram',
    },
    subtitle: {
      tr: 'Yeni Hicrî yılımız mübarek olsun, hayır ve huzur getirsin.',
      ar: 'عام هجري مبارك، أعاده الله عليكم بالخير والبركات.',
      de: 'Gesegnetes neues islamisches Jahr voller Frieden und Segen.',
      en: 'Blessed new Hijri year, wishing peace and abundance.',
    },
    celebrationGreeting: {
      heading: {
        tr: 'Hicrî Yeni Yılınız Mübarek Olsun',
        ar: 'كل عام وأنتم بخير بمناسبة العام الهجري الجديد',
        de: 'Gesegnetes neues Hijri-Jahr',
        en: 'Blessed New Hijri Year',
      },
      message: {
        tr: 'Yeni Hicrî senenin tüm İslam alemine ve insanlığa barış, huzur ve selamet getirmesini niyaz ederiz.',
        ar: 'نسأل الله تعالى أن يجعله عام خير ويُمن وسلام وأمان على سائر بلاد المسلمين.',
        de: 'Möge dieses neue islamische Jahr Frieden, Eintracht und Wohlstand für die gesamte Menschheit bringen.',
        en: 'May this new Hijri year bring peace, security, and tranquility to all humanity.',
      },
      badge: {
        tr: '✦ HİCRÎ YILBAŞI ✦',
        ar: '✦ رأس السنة الهجرية ✦',
        de: '✦ HIJRI NEUJAHR ✦',
        en: '✦ HIJRI NEW YEAR ✦',
      },
    },
  },
  {
    id: 'ashura',
    type: 'general' as const,
    month: 1, // Muharram
    day: 10,
    title: {
      tr: 'Aşûre Günü (10 Muharrem)',
      ar: 'يوم عاشوراء المبارك',
      de: 'Aschura-Tag (10. Muharram)',
      en: 'Day of Ashura (10th Muharram)',
    },
    shortName: {
      tr: 'Aşûre Günü',
      ar: 'يوم عاشوراء',
      de: 'Aschura-Tag',
      en: 'Day of Ashura',
    },
    hijriLabel: {
      tr: '10 Muharrem',
      ar: '١٠ محرم',
      de: '10. Muharram',
      en: '10th Muharram',
    },
    subtitle: {
      tr: 'Oruç ve paylaşma günü; Aşûre gününüz mübarek olsun.',
      ar: 'يوم الصيام والتقرب إلى الله تعالى بصالح الأعمال.',
      de: 'Ein Tag des Fastens und des Segens; gesegneter Aschura-Tag.',
      en: 'A blessed day of fasting and remembrance.',
    },
    celebrationGreeting: {
      heading: {
        tr: 'Mübarek Aşûre Gününüz Kutlu Olsun',
        ar: 'يوم عاشوراء مبارك ومتقبل',
        de: 'Gesegneter Aschura-Tag',
        en: 'Blessed Day of Ashura',
      },
      message: {
        tr: 'Peygamberlerimizin kurtuluş ve şükür günü olan Aşûre’nin birlik, kardeşlik ve bereket vesilesi olmasını dileriz.',
        ar: 'يوم نصر الله فيه نبيه موسى عليه السلام، ويستحب صيامه وشكر الله تعالى على نعمه العظيمة.',
        de: 'Ein Tag der Dankbarkeit, des Fastens und der geschwisterlichen Eintracht.',
        en: 'A day of fasting, thanksgiving, and unity in commemoration of divine deliverance.',
      },
      badge: {
        tr: '✦ AŞÛRE GÜNÜ ✦',
        ar: '✦ يوم عاشوراء ✦',
        de: '✦ ASCHURA-TAG ✦',
        en: '✦ DAY OF ASHURA ✦',
      },
    },
  },
  {
    id: 'mawlid',
    type: 'kandil' as const,
    month: 3, // Rabi' al-Awwal
    day: 12,
    title: {
      tr: 'Mevlid Kandili (12 Rebiülevvel)',
      ar: 'ذكرى المولد النبوي الشريف',
      de: 'Mawlid an-Nabi (Geburtstag des Propheten)',
      en: 'Mawlid an-Nabi (Prophet’s Birthday)',
    },
    shortName: {
      tr: 'Mevlid Kandili',
      ar: 'المولد النبوي',
      de: 'Mawlid an-Nabi',
      en: 'Mawlid Kandili',
    },
    hijriLabel: {
      tr: '12 Rebiülevvel',
      ar: '١٢ ربيع الأول',
      de: '12. Rabi al-Awwal',
      en: '12th Rabi’ al-Awwal',
    },
    subtitle: {
      tr: 'Âlemlere rahmet Peygamberimiz Hz. Muhammed (s.a.v.)’in dünyayı teşrifi.',
      ar: 'ذكرى ميلاد الحبيب المصطفى خاتم النبيين ﷺ.',
      de: 'Geburtstag unseres geliebten Propheten Muhammad ﷺ.',
      en: 'Commemorating the birth of the Messenger of Allah ﷺ.',
    },
    celebrationGreeting: {
      heading: {
        tr: 'Mevlid Kandiliniz Mübarek Olsun',
        ar: 'مبارك عليكم ذكرى المولد النبوي الشريف',
        de: 'Gesegnetes Mawlid-Fest',
        en: 'Blessed Mawlid an-Nabi',
      },
      message: {
        tr: 'Âlemlere rahmet olarak gönderilen Peygamber Efendimiz Hz. Muhammed’in (s.a.v.) teşrifi hanelerimize nur ve huzur getirsin.',
        ar: '«وَإِنَّكَ لَعَلَىٰ خُلُقٍ عَظِيمٍ» - الصلاة والسلام على الهادي البشير والسراج المنير سيدنا محمد ﷺ.',
        de: 'Möge das Licht und die Barmherzigkeit des Propheten Muhammad ﷺ unsere Herzen und Häuser erleuchten.',
        en: 'May peace and blessings be upon the Mercy to the Worlds, our Prophet Muhammad ﷺ.',
      },
      badge: {
        tr: '✦ MEVLİD KANDİLİ ✦',
        ar: '✦ المولد النبوي الشريف ✦',
        de: '✦ MAWLID AN-NABI ✦',
        en: '✦ PROPHET’S BIRTHDAY ✦',
      },
    },
  },
];

export const islamicDateService = {
  /**
   * Detect if current moment is an active sacred day or night (today or tonight).
   * Returns full celebration greeting in 4 languages.
   */
  getActiveSpecialDay(date: Date = new Date(), adjustmentDays: number = 0): IslamicSpecialEvent | null {
    const { day, month } = hijriService.getHijriDate(date, adjustmentDays);
    const dayOfWeek = date.getDay(); // 0 = Sun, 4 = Thu, 5 = Fri
    const currentHour = date.getHours();

    // Thursday evening (17:00+) and Friday night (<05:00)
    const isThursdayEvening = dayOfWeek === 4 && currentHour >= 17;
    const isFridayNight = dayOfWeek === 5 && currentHour < 5;
    const isFridayDay = dayOfWeek === 5 && currentHour >= 5 && currentHour < 18;

    // 1. REGAİB KANDİLİ: First Thursday evening / Friday of Rajab (Month 7)
    if (month === 7 && day <= 7 && (isThursdayEvening || (dayOfWeek === 5 && currentHour < 18))) {
      return {
        id: 'regaib-kandili',
        type: 'kandil',
        isToday: true,
        isTonight: isThursdayEvening || isFridayNight,
        daysRemaining: 0,
        title: {
          tr: 'Regaib Kandili (Üç Ayların İlk Kandili)',
          ar: 'ليلة الرغائب المباركة',
          de: 'Ragaib-Nacht (Beginn der Heiligen Drei Monate)',
          en: 'Laylat al-Raghaib (Blessed Night of Regaib)',
        },
        subtitle: {
          tr: 'Mübarek Regaib Kandiliniz kutlu olsun; dualarınız ve ibadetleriniz makbul olsun.',
          ar: 'ليلة مباركة في مطلع شهر رجب الأصم، تقبل الله صالح دعائكم وقيامكم.',
          de: 'Gesegnete Ragaib-Nacht; möge Allah Ihre Gebete und Reue annehmen.',
          en: 'Blessed Night of Raghaib; may Allah answer your sincere prayers.',
        },
        badgeText: {
          tr: '✦ REGAİB KANDİLİ ✦',
          ar: '✦ ليلة الرغائب المباركة ✦',
          de: '✦ RAGAIB-NACHT ✦',
          en: '✦ LAYLAT AL-RAGHAIB ✦',
        },
        celebrationGreeting: {
          heading: {
            tr: 'Regaib Kandiliniz Mübarek Olsun',
            ar: 'مبارك عليكم ليلة الرغائب الشريفة',
            de: 'Gesegnete Ragaib-Nacht',
            en: 'Blessed Laylat al-Raghaib',
          },
          message: {
            tr: 'Üç ayların ilk müjdecisi olan Regaib gecesinde açılan ellerin, edilen duaların ve kılınan namazların kabulünü niyaz ederiz.',
            ar: 'ليلة الرغائب والرجاء بمغفرة الرحمن في مستهل رجب؛ تقبل الله منا ومنكم صالح الطاعات.',
            de: 'Die erste heilige Nacht der Drei Monate; möge Allah unsere Sünden vergeben und Gebete annehmen.',
            en: 'The first blessed beacon of the Three Sacred Months; may our supplications and fasts be accepted.',
          },
          badge: {
            tr: '✦ KANDİLİNİZ MÜBAREK OLSUN ✦',
            ar: '✦ ليلة مباركة كريمة ✦',
            de: '✦ HEILIGE KANDIL-NACHT ✦',
            en: '✦ BLESSED KANDIL NIGHT ✦',
          },
        },
        hijriLabel: {
          tr: 'Recep İlk Cuma',
          ar: 'أول جمعة من رجب',
          de: '1. Freitag Radschab',
          en: '1st Friday Rajab',
        },
      };
    }

    // 2. Exact match with annual calendar today
    for (const ev of ISLAMIC_ANNUAL_CALENDAR) {
      if (ev.month === month && ev.day === day) {
        return {
          id: ev.id,
          type: ev.type,
          isToday: true,
          isTonight: currentHour >= 17,
          daysRemaining: 0,
          title: ev.title,
          subtitle: ev.subtitle,
          badgeText: ev.celebrationGreeting.badge,
          celebrationGreeting: ev.celebrationGreeting,
          hijriLabel: ev.hijriLabel,
        };
      }

      // Check if tonight is the eve of this event (e.g. day before after 17:00)
      if (ev.month === month && ev.day === day + 1 && currentHour >= 17) {
        return {
          id: `${ev.id}-eve`,
          type: ev.type,
          isToday: false,
          isTonight: true,
          daysRemaining: 0,
          title: {
            tr: `Bu Gece: ${ev.title.tr}`,
            ar: `هذه الليلة: ${ev.title.ar}`,
            de: `Heute Nacht: ${ev.title.de}`,
            en: `Tonight: ${ev.title.en}`,
          },
          subtitle: ev.subtitle,
          badgeText: {
            tr: 'BU GECE MÜBAREK',
            ar: 'هذه الليلة المباركة',
            de: 'HEUTE NACHT',
            en: 'TONIGHT',
          },
          celebrationGreeting: ev.celebrationGreeting,
          hijriLabel: ev.hijriLabel,
        };
      }
    }

    // 3. Friday Eve / Friday Day
    if (isThursdayEvening || isFridayNight) {
      return {
        id: 'friday-eve',
        type: 'friday',
        isToday: false,
        isTonight: true,
        daysRemaining: 0,
        title: {
          tr: 'Mübarek Cuma Gecesi',
          ar: 'ليلة الجمعة المباركة',
          de: 'Gesegnete Freitagsnacht',
          en: 'Blessed Friday Eve',
        },
        subtitle: {
          tr: 'Cuma geceniz mübarek olsun. Peygamberimize salavat getirmeyi unutmayınız.',
          ar: 'أكثروا من الصلاة والسلام على الحبيب المصطفى ﷺ في ليلة الجمعة.',
          de: 'Gesegnete Nacht vor dem Freitag. Sprechen Sie Segenswünsche auf den Propheten ﷺ.',
          en: 'Blessed Friday night. Remember to send blessings upon the Prophet ﷺ.',
        },
        badgeText: {
          tr: 'CUMA GECESİ',
          ar: 'ليلة الجمعة',
          de: 'FREITAGSNACHT',
          en: 'FRIDAY EVE',
        },
        celebrationGreeting: {
          heading: {
            tr: 'Mübarek Cuma Geceniz Hayırlı Olsun',
            ar: 'ليلة جمعة مباركة طيبة',
            de: 'Gesegnete Freitagsnacht',
            en: 'Blessed Friday Eve',
          },
          message: {
            tr: 'Haftanın en faziletli gecesinde Efendimiz’e (s.a.v.) salavat-ı şerife getirelim, dualarımızı artıralım.',
            ar: '«إِنَّ مِنْ أَفْضَلِ أَيَّامِكُمْ يَوْمَ الْجُمُعَةِ، فَأَكْثِرُوا عَلَيَّ مِنَ الصَّلَاةِ فِيهِ» ﷺ.',
            de: 'Sprechen Sie Segenswünsche auf den Gesandten Allahs ﷺ in dieser gesegneten Freitagsnacht.',
            en: 'Send abundant blessings and peace upon the Beloved Prophet Muhammad ﷺ tonight.',
          },
          badge: {
            tr: '✦ CUMA GECESİ ✦',
            ar: '✦ ليلة الجمعة ✦',
            de: '✦ FREITAGSNACHT ✦',
            en: '✦ FRIDAY EVE ✦',
          },
        },
        hijriLabel: {
          tr: 'Cuma Gecesi',
          ar: 'ليلة الجمعة',
          de: 'Freitagsnacht',
          en: 'Friday Eve',
        },
      };
    }

    if (isFridayDay) {
      return {
        id: 'friday-day',
        type: 'friday',
        isToday: true,
        isTonight: false,
        daysRemaining: 0,
        title: {
          tr: 'Hayırlı Cumalar (Mübarek Cuma Günü)',
          ar: 'جمعة مباركة طيبة',
          de: 'Gesegneter Freitag (Dschuma)',
          en: 'Blessed Friday (Jummah Mubarak)',
        },
        subtitle: {
          tr: 'Gününüz hayırlı, ibadet ve dualarınız makbul olsun.',
          ar: 'تقبل الله صلاتكم ودعائكم في هذا اليوم المبارك.',
          de: 'Möge Allah Ihr Freitagsgebet und Ihre Bittgebete annehmen.',
          en: 'May Allah accept your prayers and good deeds on this blessed day.',
        },
        badgeText: {
          tr: 'HAYIRLI CUMALAR',
          ar: 'جمعة مباركة',
          de: 'GESEGNETER FREITAG',
          en: 'JUMMAH MUBARAK',
        },
        celebrationGreeting: {
          heading: {
            tr: 'Hayırlı ve Bereketli Cumalar',
            ar: 'جمعة مباركة، تقبل الله منا ومنكم',
            de: 'Gesegneter Freitag (Dschuma Mubarak)',
            en: 'Blessed and Peaceful Jummah',
          },
          message: {
            tr: 'Cuma namazımızın, dualarımızın ve tövbelerimizin kabul olmasını Cenab-ı Hakk’tan niyaz ederiz.',
            ar: 'تقبل الله صلاتكم وركوعكم وسجودكم، وجعل جمعتكم نورا وبركة وتوفيقا.',
            de: 'Möge Allah unser Freitagsgebet und alle Fürbitten erhören und segnen.',
            en: 'May Allah accept our Friday prayers, purify our souls, and bestow His mercy upon us.',
          },
          badge: {
            tr: '✦ CUMANIZ MÜBAREK OLSUN ✦',
            ar: '✦ جمعة مباركة ✦',
            de: '✦ GESEGNETER FREITAG ✦',
            en: '✦ JUMMAH MUBARAK ✦',
          },
        },
        hijriLabel: {
          tr: 'Cuma Günü',
          ar: 'يوم الجمعة',
          de: 'Freitag',
          en: 'Friday',
        },
      };
    }

    return null;
  },

  /**
   * Chronological sequential countdown to upcoming holy milestones:
   * 1 Recep (Üç Aylar) -> Regaib Kandili -> Mirac -> Berat -> Ramazan -> Kadir -> Bayramlar...
   */
  getUpcomingMilestones(currentDate: Date = new Date(), adjustmentDays: number = 0): IslamicCountdownItem[] {
    const milestones: IslamicCountdownItem[] = [];
    const addedIds = new Set<string>();

    for (let d = 1; d <= 365; d++) {
      const probeDate = new Date(currentDate.getTime() + d * 86400000);
      const hijri = hijriService.getHijriDate(probeDate, adjustmentDays);
      const dayOfWeek = probeDate.getDay();

      // 1. Üç Ayların Başlangıcı (1 Recep)
      if (hijri.month === 7 && hijri.day === 1 && !addedIds.has('three-months-start')) {
        addedIds.add('three-months-start');
        milestones.push({
          id: 'three-months-start',
          type: 'three-months',
          title: {
            tr: 'Üç Ayların Başlangıcı (1 Recep)',
            ar: 'بداية الأشهر الحرم (١ رجب)',
            de: 'Beginn der Drei Heiligen Monate (1. Radschab)',
            en: 'Start of the Three Holy Months (1st Rajab)',
          },
          shortName: {
            tr: 'Üç Ayların Başlangıcı',
            ar: 'بداية الأشهر الحرم',
            de: 'Beginn 3 Monate',
            en: 'Three Holy Months',
          },
          hijriLabel: {
            tr: '1 Recep',
            ar: '١ رجب',
            de: '1. Radschab',
            en: '1st Rajab',
          },
          daysRemaining: d,
          orderIndex: milestones.length,
          description: {
            tr: 'Mübarek Recep, Şaban ve Ramazan mevsiminin başlangıcı.',
            ar: 'موسم الأشهر الحرم والنفحات الإيمانية المباركة.',
            de: 'Beginn der spirituellen Vorbereitung auf den Ramadan.',
            en: 'The arrival of the blessed season of Rajab, Sha’ban and Ramadan.',
          },
        });
      }

      // 2. Regaib Kandili (First Thursday night / Friday of Rajab)
      if (hijri.month === 7 && hijri.day <= 7 && (dayOfWeek === 4 || dayOfWeek === 5) && !addedIds.has('regaib')) {
        addedIds.add('regaib');
        milestones.push({
          id: 'regaib',
          type: 'kandil',
          title: {
            tr: 'Regaib Kandili (Üç Ayların İlk Kandili)',
            ar: 'ليلة الرغائب المباركة',
            de: 'Ragaib-Nacht',
            en: 'Laylat al-Raghaib',
          },
          shortName: {
            tr: 'Regaib Kandili',
            ar: 'ليلة الرغائب',
            de: 'Ragaib-Nacht',
            en: 'Laylat al-Raghaib',
          },
          hijriLabel: {
            tr: 'Recep İlk Cuma',
            ar: 'أول جمعة من رجب',
            de: '1. Freitag Radschab',
            en: '1st Friday Rajab',
          },
          daysRemaining: d,
          orderIndex: milestones.length,
          description: {
            tr: 'Duaların ve rağbetin Allah’a arz edildiği ilk kandil gecesi.',
            ar: 'ليلة مباركة في مطلع رجب للرجاء وإجابة الدعاء.',
            de: 'Die erste heilige Nacht der Drei Monate.',
            en: 'The first sacred night of the Three Holy Months.',
          },
        });
      }

      // 3. Mîrâc Kandili (27 Recep)
      if (hijri.month === 7 && hijri.day === 27 && !addedIds.has('miraj')) {
        addedIds.add('miraj');
        milestones.push({
          id: 'miraj',
          type: 'kandil',
          title: {
            tr: 'Mîrâc Kandili (27 Recep)',
            ar: 'ذكرى الإسراء والمعراج',
            de: 'Isra und Miradsch',
            en: 'Al-Isra wal-Mi’raj',
          },
          shortName: {
            tr: 'Mîrâc Kandili',
            ar: 'الإسراء والمعراج',
            de: 'Miradsch-Nacht',
            en: 'Laylat al-Miraj',
          },
          hijriLabel: {
            tr: '27 Recep',
            ar: '٢٧ رجب',
            de: '27. Radschab',
            en: '27th Rajab',
          },
          daysRemaining: d,
          orderIndex: milestones.length,
          description: {
            tr: 'Peygamberimizin arşa yükseldiği ve namazın hediye edildiği gece.',
            ar: 'ذكرى فرض الصلوات الخمس والإسراء بالحبيب ﷺ.',
            de: 'Nacht der Himmelfahrt und der fünf täglichen Gebete.',
            en: 'Night of ascension and the divine gift of five daily prayers.',
          },
        });
      }

      // 4. Berâat Kandili (15 Şaban)
      if (hijri.month === 8 && hijri.day === 15 && !addedIds.has('barat')) {
        addedIds.add('barat');
        milestones.push({
          id: 'barat',
          type: 'kandil',
          title: {
            tr: 'Berâat Kandili (15 Şaban)',
            ar: 'ليلة النصف من شعبان',
            de: 'Lailat al-Bara’a',
            en: 'Laylat al-Bara’at',
          },
          shortName: {
            tr: 'Berâat Kandili',
            ar: 'ليلة البراءة',
            de: 'Bara’a-Nacht',
            en: 'Laylat al-Bara’at',
          },
          hijriLabel: {
            tr: '15 Şaban',
            ar: '١٥ شعبان',
            de: '15. Schaban',
            en: '15th Sha’ban',
          },
          daysRemaining: d,
          orderIndex: milestones.length,
          description: {
            tr: 'Ramazan’ın müjdecisi, af ve mağfiret gecesi.',
            ar: 'ليلة المغفرة والرحمة وقبول التوبة.',
            de: 'Die Nacht der Vergebung vor dem Ramadan.',
            en: 'Night of salvation and divine mercy before Ramadan.',
          },
        });
      }

      // 5. Ramazan-ı Şerif Başlangıcı (1 Ramazan)
      if (hijri.month === 9 && hijri.day === 1 && !addedIds.has('ramadan-start')) {
        addedIds.add('ramadan-start');
        milestones.push({
          id: 'ramadan-start',
          type: 'ramadan',
          title: {
            tr: 'Ramazan-ı Şerif Başlangıcı (1 Ramazan)',
            ar: 'بداية شهر رمضان المبارك',
            de: 'Beginn des Monats Ramadan',
            en: 'Start of Holy Ramadan',
          },
          shortName: {
            tr: 'Ramazan Başlangıcı',
            ar: 'بداية رمضان',
            de: 'Beginn Ramadan',
            en: 'Start of Ramadan',
          },
          hijriLabel: {
            tr: '1 Ramazan',
            ar: '١ رمضان',
            de: '1. Ramadan',
            en: '1st Ramadan',
          },
          daysRemaining: d,
          orderIndex: milestones.length,
          description: {
            tr: 'On bir ayın sultanı; ilk teravih ve ilk sahur sevinci.',
            ar: 'أول أيام شهر الصيام وتلاوة القرآن الكريم.',
            de: 'Der Beginn des Fastens und der Andacht.',
            en: 'The beginning of the blessed month of fasting and Quran.',
          },
        });
      }

      // 6. Kadir Gecesi (27 Ramazan)
      if (hijri.month === 9 && hijri.day === 27 && !addedIds.has('laylat-al-qadr')) {
        addedIds.add('laylat-al-qadr');
        milestones.push({
          id: 'laylat-al-qadr',
          type: 'kandil',
          title: {
            tr: 'Kadir Gecesi (27 Ramazan)',
            ar: 'ليلة القدر المباركة',
            de: 'Lailat al-Qadr',
            en: 'Laylat al-Qadr',
          },
          shortName: {
            tr: 'Kadir Gecesi',
            ar: 'ليلة القدر',
            de: 'Lailat al-Qadr',
            en: 'Laylat al-Qadr',
          },
          hijriLabel: {
            tr: '27 Ramazan',
            ar: '٢٧ رمضان',
            de: '27. Ramadan',
            en: '27th Ramadan',
          },
          daysRemaining: d,
          orderIndex: milestones.length,
          description: {
            tr: 'Bin aydan daha hayırlı olan mübarek gece.',
            ar: 'ليلة القدر خير من ألف شهر.',
            de: 'Eine Nacht, besser als tausend Monate.',
            en: 'A night better than a thousand months.',
          },
        });
      }

      // 7. Ramazan Bayramı (1 Şevval)
      if (hijri.month === 10 && hijri.day === 1 && !addedIds.has('ramadan-eid')) {
        addedIds.add('ramadan-eid');
        milestones.push({
          id: 'ramadan-eid',
          type: 'eid',
          title: {
            tr: 'Ramazan Bayramı (1 Şevval)',
            ar: 'عيد الفطر المبارك',
            de: 'Eid al-Fitr (Fastenbrechen)',
            en: 'Eid al-Fitr',
          },
          shortName: {
            tr: 'Ramazan Bayramı',
            ar: 'عيد الفطر',
            de: 'Eid al-Fitr',
            en: 'Eid al-Fitr',
          },
          hijriLabel: {
            tr: '1 Şevval',
            ar: '١ شوّال',
            de: '1. Schawwal',
            en: '1st Shawwal',
          },
          daysRemaining: d,
          orderIndex: milestones.length,
          description: {
            tr: 'Oruç ibadetinin bayram sevinci.',
            ar: 'يوم الجائزة والفرح بصيام رمضان.',
            de: 'Fest des Fastenbrechens.',
            en: 'Celebration of breaking the fast.',
          },
        });
      }

      // 8. Arefe Günü (9 Zilhicce)
      if (hijri.month === 12 && hijri.day === 9 && !addedIds.has('arafah')) {
        addedIds.add('arafah');
        milestones.push({
          id: 'arafah',
          type: 'general',
          title: {
            tr: 'Arefe Günü (9 Zilhicce)',
            ar: 'يوم عرفة المبارك',
            de: 'Tag von Arafah',
            en: 'Day of Arafah',
          },
          shortName: {
            tr: 'Arefe Günü',
            ar: 'يوم عرفة',
            de: 'Tag von Arafah',
            en: 'Day of Arafah',
          },
          hijriLabel: {
            tr: '9 Zilhicce',
            ar: '٩ ذو الحجة',
            de: '9. Dhu l-Hiddscha',
            en: '9th Dhul-Hijjah',
          },
          daysRemaining: d,
          orderIndex: milestones.length,
          description: {
            tr: 'Hacıların vakfeye durduğu en faziletli dua günü.',
            ar: 'أفضل أيام الدنيا وخير يوم طلعت عليه الشمس.',
            de: 'Der Tag des Stehens auf Arafat.',
            en: 'The blessed day of supplication on Mount Arafat.',
          },
        });
      }

      // 9. Kurban Bayramı (10 Zilhicce)
      if (hijri.month === 12 && hijri.day === 10 && !addedIds.has('eid-al-adha')) {
        addedIds.add('eid-al-adha');
        milestones.push({
          id: 'eid-al-adha',
          type: 'eid',
          title: {
            tr: 'Kurban Bayramı (10 Zilhicce)',
            ar: 'عيد الأضحى المبارك',
            de: 'Opferfest (Eid al-Adha)',
            en: 'Eid al-Adha',
          },
          shortName: {
            tr: 'Kurban Bayramı',
            ar: 'عيد الأضحى',
            de: 'Opferfest',
            en: 'Eid al-Adha',
          },
          hijriLabel: {
            tr: '10 Zilhicce',
            ar: '١٠ ذو الحجة',
            de: '10. Dhu l-Hiddscha',
            en: '10th Dhul-Hijjah',
          },
          daysRemaining: d,
          orderIndex: milestones.length,
          description: {
            tr: 'Kurban ibadeti, kardeşlik ve paylaşma günleri.',
            ar: 'عيد التضحية والفداء والتقرب إلى الله بالأضاحي.',
            de: 'Das große islamische Opferfest.',
            en: 'The sacred festival of sacrifice and sharing.',
          },
        });
      }

      // 10. Hicri Yılbaşı (1 Muharrem)
      if (hijri.month === 1 && hijri.day === 1 && !addedIds.has('hijri-new-year')) {
        addedIds.add('hijri-new-year');
        milestones.push({
          id: 'hijri-new-year',
          type: 'general',
          title: {
            tr: 'Hicrî Yılbaşı (1 Muharrem)',
            ar: 'رأس السنة الهجرية',
            de: 'Islamisches Neujahr',
            en: 'Hijri New Year',
          },
          shortName: {
            tr: 'Hicrî Yılbaşı',
            ar: 'رأس السنة الهجرية',
            de: 'Hicri Neujahr',
            en: 'Hijri New Year',
          },
          hijriLabel: {
            tr: '1 Muharrem',
            ar: '١ محرم',
            de: '1. Muharram',
            en: '1st Muharram',
          },
          daysRemaining: d,
          orderIndex: milestones.length,
          description: {
            tr: 'Hicret ile başlayan yeni İslam yılı.',
            ar: 'ذكرى الهجرة النبوية المباركة وبداية العام الجديد.',
            de: 'Beginn des neuen Hijri-Kalenderjahres.',
            en: 'Commemorating the Prophetic Hijra and the new year.',
          },
        });
      }

      // 11. Aşûre Günü (10 Muharrem)
      if (hijri.month === 1 && hijri.day === 10 && !addedIds.has('ashura')) {
        addedIds.add('ashura');
        milestones.push({
          id: 'ashura',
          type: 'general',
          title: {
            tr: 'Aşûre Günü (10 Muharrem)',
            ar: 'يوم عاشوراء المبارك',
            de: 'Aschura-Tag',
            en: 'Day of Ashura',
          },
          shortName: {
            tr: 'Aşûre Günü',
            ar: 'يوم عاشوراء',
            de: 'Aschura-Tag',
            en: 'Day of Ashura',
          },
          hijriLabel: {
            tr: '10 Muharrem',
            ar: '١٠ محرم',
            de: '10. Muharram',
            en: '10th Muharram',
          },
          daysRemaining: d,
          orderIndex: milestones.length,
          description: {
            tr: 'Sünnet orucu, ikram ve kardeşlik günü.',
            ar: 'صيام شكر لله تعالى على نجاة موسى عليه السلام.',
            de: 'Tag des Fastens und der Dankbarkeit.',
            en: 'Day of fasting and commemoration of divine deliverance.',
          },
        });
      }

      // 12. Mevlid Kandili (12 Rebiülevvel)
      if (hijri.month === 3 && hijri.day === 12 && !addedIds.has('mawlid')) {
        addedIds.add('mawlid');
        milestones.push({
          id: 'mawlid',
          type: 'kandil',
          title: {
            tr: 'Mevlid Kandili (12 Rebiülevvel)',
            ar: 'المولد النبوي الشريف',
            de: 'Mawlid an-Nabi',
            en: 'Mawlid an-Nabi',
          },
          shortName: {
            tr: 'Mevlid Kandili',
            ar: 'المولد النبوي',
            de: 'Mawlid-Fest',
            en: 'Mawlid Kandili',
          },
          hijriLabel: {
            tr: '12 Rebiülevvel',
            ar: '١٢ ربيع الأول',
            de: '12. Rabi al-Awwal',
            en: '12th Rabi’ al-Awwal',
          },
          daysRemaining: d,
          orderIndex: milestones.length,
          description: {
            tr: 'Peygamber Efendimiz’in (s.a.v.) dünyayı teşrifi.',
            ar: 'ذكرى مولد سيد الخلق وخاتم الأنبياء ﷺ.',
            de: 'Geburtstag des Propheten Muhammad ﷺ.',
            en: 'Commemorating the birth of the Messenger of Allah ﷺ.',
          },
        });
      }
    }

    return milestones;
  },

  /**
   * Real-time countdown for Ramadan (İftar and Sahur / İmsak).
   */
  getRamadanCountdown(
    currentTime: Date = new Date(),
    timings: PrayerTimes | null,
    adjustmentDays: number = 0,
    forceRamadan: boolean = false
  ): RamadanCountdownInfo {
    const hijri = hijriService.getHijriDate(currentTime, adjustmentDays);
    const isRamadan = forceRamadan || hijri.month === 9;

    if (!isRamadan || !timings) {
      return {
        isRamadan: false,
        isFastingTime: false,
        phase: 'none',
        label: {
          tr: 'İftara Kalan Süre',
          ar: 'الوقت المتبقي حتى الإفطار',
          de: 'Zeit bis zum Iftar',
          en: 'Time Until Iftar',
        },
        targetTimeStr: '--:--',
        hours: 0,
        minutes: 0,
        seconds: 0,
        formattedCountdown: '--:--:--',
      };
    }

    const currentMins = currentTime.getHours() * 60 + currentTime.getMinutes();
    const currentSecs = currentMins * 60 + currentTime.getSeconds();

    const [fajrH, fajrM] = (timings.Fajr || '05:00').split(':').map((v) => parseInt(v, 10));
    const fajrTotalSecs = (fajrH * 60 + fajrM) * 60;

    const [maghribH, maghribM] = (timings.Maghrib || '18:00').split(':').map((v) => parseInt(v, 10));
    const maghribTotalSecs = (maghribH * 60 + maghribM) * 60;

    let targetSecs = 0;
    let phase: 'iftar' | 'sahur' = 'iftar';
    let targetTimeStr = '';

    if (currentSecs >= fajrTotalSecs && currentSecs < maghribTotalSecs) {
      // Daytime fasting window -> countdown to Maghrib (İftar)
      phase = 'iftar';
      targetSecs = maghribTotalSecs;
      targetTimeStr = timings.Maghrib;
    } else {
      // Nighttime -> countdown to Fajr (Sahur / İmsak)
      phase = 'sahur';
      targetTimeStr = timings.Fajr;
      if (currentSecs >= maghribTotalSecs) {
        // Evening: next Fajr is tomorrow
        targetSecs = fajrTotalSecs + 24 * 3600;
      } else {
        // Before dawn: Fajr is today
        targetSecs = fajrTotalSecs;
      }
    }

    let diffSecs = Math.max(0, targetSecs - currentSecs);
    const hours = Math.floor(diffSecs / 3600);
    diffSecs %= 3600;
    const minutes = Math.floor(diffSecs / 60);
    const seconds = diffSecs % 60;

    const formattedCountdown = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

    const label: Record<Language, string> =
      phase === 'iftar'
        ? {
            tr: 'İftara Kalan Süre (Oruç Açma)',
            ar: 'الوقت المتبقي حتى موعد الإفطار',
            de: 'Verbleibende Zeit bis zum Iftar',
            en: 'Time Remaining Until Iftar',
          }
        : {
            tr: 'Sahur / İmsak’a Kalan Süre',
            ar: 'الوقت المتبقي حتى الإمساك / السحور',
            de: 'Zeit bis zum Sahur / Imsak',
            en: 'Time Until Sahur / Imsak',
          };

    return {
      isRamadan: true,
      isFastingTime: phase === 'iftar',
      phase,
      label,
      targetTimeStr,
      hours,
      minutes,
      seconds,
      formattedCountdown,
    };
  },
};

export default islamicDateService;
