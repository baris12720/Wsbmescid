import { PrayerTimes, MosqueSettings } from '../types';

/**
 * Offline prayer-time calculator (no internet needed).
 * Standard astronomical algorithm (PrayTimes style) with Diyanet angles
 * (Fajr 18°, Isha 17°) and Diyanet "temkin" minute tuning.
 * Verified against AlAdhan/Diyanet values for Hamburg (28.10.2026): all six times within 0-2 min.
 * Used as the last-resort fallback when the AlAdhan API is unreachable and no cached data exists.
 */
export function calculateLocalPrayerTimes(date: Date, settings?: Partial<MosqueSettings>): PrayerTimes {
  const lat = typeof settings?.latitude === 'number' ? settings.latitude : 53.5511;
  const lon = typeof settings?.longitude === 'number' ? settings.longitude : 9.9937;
  const tz = settings?.timezone || 'Europe/Berlin';
  const asrF = settings?.asrMethod === 'Hanafi' ? 2 : 1;
  const fajrA = 18;
  const ishaA = 17;
  const tune: Record<string, number> = { Fajr: 0, Sunrise: -7, Dhuhr: 5, Asr: 6, Maghrib: 7, Isha: 0 };

  const Y = date.getFullYear();
  const M = date.getMonth() + 1;
  const D = date.getDate();
  const R = Math.PI / 180;
  const sin = (d: number) => Math.sin(d * R);
  const cos = (d: number) => Math.cos(d * R);
  const tan = (d: number) => Math.tan(d * R);
  const asin = (x: number) => Math.asin(x) / R;
  const acos = (x: number) => Math.acos(x) / R;
  const atan2 = (y: number, x: number) => Math.atan2(y, x) / R;
  const acot = (x: number) => Math.atan(1 / x) / R;
  const fix = (a: number, b: number) => {
    const r = a - b * Math.floor(a / b);
    return r < 0 ? r + b : r;
  };

  // UTC offset (incl. daylight saving) of the target time zone on this calendar date
  const h = parseInt(
    new Intl.DateTimeFormat('en-US', { timeZone: tz, hour12: false, hour: 'numeric' }).format(
      new Date(Date.UTC(Y, M - 1, D, 12))
    ),
    10
  ) % 24;
  const off = h - 12;

  const yy = M <= 2 ? Y - 1 : Y;
  const mm = M <= 2 ? M + 12 : M;
  const A = Math.floor(yy / 100);
  const B = 2 - A + Math.floor(A / 4);
  const jd0 = Math.floor(365.25 * (yy + 4716)) + Math.floor(30.6001 * (mm + 1)) + D + B - 1524.5;
  const jd = jd0 - lon / (15 * 24);

  const sunPos = (j: number) => {
    const d = j - 2451545.0;
    const g = fix(357.529 + 0.98560028 * d, 360);
    const q = fix(280.459 + 0.98564736 * d, 360);
    const L = fix(q + 1.915 * sin(g) + 0.02 * sin(2 * g), 360);
    const e = 23.439 - 0.00000036 * d;
    const ra = fix(atan2(cos(e) * sin(L), cos(L)) / 15, 24);
    return { decl: asin(sin(e) * sin(L)), eqt: q / 15 - ra };
  };
  const mid = (t: number) => fix(12 - sunPos(jd + t).eqt, 24);
  const ang = (a: number, t: number, ccw: boolean) => {
    const d = sunPos(jd + t).decl;
    const v = (-sin(a) - sin(d) * sin(lat)) / (cos(d) * cos(lat));
    if (v > 1 || v < -1) return NaN;
    return (1 / 15) * acos(v) * (ccw ? -1 : 1);
  };
  const asr = (f: number, t: number) => {
    const d = sunPos(jd + t).decl;
    return (1 / 15) * acos((sin(acot(f + tan(Math.abs(lat - d)))) - sin(d) * sin(lat)) / (cos(d) * cos(lat)));
  };

  let t = { f: 5, s: 6, d: 12, a: 13, m: 18, i: 18 };
  for (let k = 0; k < 2; k++) {
    const dh = mid(t.d / 24);
    t = {
      f: dh + ang(fajrA, t.f / 24, true),
      s: dh + ang(0.833, t.s / 24, true),
      d: dh,
      a: dh + asr(asrF, t.a / 24),
      m: dh + ang(0.833, t.m / 24, false),
      i: dh + ang(ishaA, t.i / 24, false),
    };
  }
  const res: Record<string, number> = { Fajr: t.f, Sunrise: t.s, Dhuhr: t.d, Asr: t.a, Maghrib: t.m, Isha: t.i };

  // High-latitude handling (angle-based night portion) when twilight never reaches the angle
  const night = fix(res.Sunrise - res.Maghrib, 24);
  const fp = res.Sunrise - (fajrA / 60) * night;
  const ip = res.Maghrib + (ishaA / 60) * night;
  if (isNaN(res.Fajr) || fix(res.Sunrise - res.Fajr, 24) > (fajrA / 60) * night) res.Fajr = fp;
  if (isNaN(res.Isha) || fix(res.Isha - res.Maghrib, 24) > (ishaA / 60) * night) res.Isha = ip;

  const out: Record<string, string> = {};
  Object.keys(res).forEach((name) => {
    const local = res[name] + off - lon / 15;
    let mins = Math.round(fix(local, 24) * 60 + (tune[name] || 0));
    mins = ((mins % 1440) + 1440) % 1440;
    out[name] = `${String(Math.floor(mins / 60)).padStart(2, '0')}:${String(mins % 60).padStart(2, '0')}`;
  });
  return out as unknown as PrayerTimes;
}
