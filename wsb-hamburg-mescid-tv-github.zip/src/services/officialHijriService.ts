// @ts-nocheck
/* Official Hijri calendar (Diyanet) refreshed from the internet; keeps working from device storage offline. */
(function () {
  if (typeof window === 'undefined' || window.__wsbAdjFor) return;
  var KEY = 'wsb_hijri_official_v1';
  var ORDER = [0, -1, 1, -2, 2, -3, 3];
  var store = {};
  try { store = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { store = {}; }
  var memo = {};
  var tail = null; // { t: time of last cached day, adj: its adjustment }
  var fmt = null;
  try { fmt = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', { day: 'numeric', month: 'numeric', year: 'numeric' }); } catch (e) { fmt = null; }
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function mkey(y, m) { return y + '-' + pad(m); }
  function daysIn(y, m) { return new Date(y, m, 0).getDate(); }
  function uaq(d) {
    if (!fmt) return null;
    var r = { d: 1, m: 1, y: 1448 };
    fmt.formatToParts(d).forEach(function (p) {
      if (p.type === 'day') r.d = parseInt(p.value, 10);
      if (p.type === 'month') r.m = parseInt(p.value, 10);
      if (p.type === 'year') r.y = parseInt(p.value, 10);
    });
    return r;
  }
  function officialRow(y, m, d) {
    var mo = store[mkey(y, m)];
    return (mo && mo.days && mo.days[d]) || null;
  }
  // number of days to add to the civil date so Umm al-Qura (built into the browser) shows the official Hijri day
  function solve(y, m, d, row) {
    for (var i = 0; i < ORDER.length; i++) {
      var c = new Date(y, m - 1, d + ORDER[i], 12);
      var u = uaq(c);
      if (u && u.d === row[0] && u.m === row[1]) return ORDER[i];
    }
    return null;
  }
  function computeTail() {
    tail = null;
    var keys = Object.keys(store).sort();
    for (var k = keys.length - 1; k >= 0; k--) {
      var mo = store[keys[k]];
      if (!mo || !mo.days) continue;
      var y = parseInt(keys[k].slice(0, 4), 10), m = parseInt(keys[k].slice(5), 10);
      for (var d = daysIn(y, m); d >= 1; d--) {
        if (mo.days[d]) {
          var a = solve(y, m, d, mo.days[d]);
          if (a !== null) tail = { t: new Date(y, m - 1, d, 23, 59).getTime(), adj: a };
          return;
        }
      }
    }
  }
  function adjFor(date, manual) {
    try {
      var y = date.getFullYear(), m = date.getMonth() + 1, d = date.getDate();
      var k = y * 10000 + m * 100 + d;
      if (memo[k] !== undefined) return memo[k];
      var row = officialRow(y, m, d);
      if (row) {
        var a = solve(y, m, d, row);
        if (a !== null) { memo[k] = a; return a; }
      }
      if (tail && date.getTime() > tail.t) return tail.adj;
      return manual;
    } catch (e) { return manual; }
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(store)); } catch (e) {} }
  async function fetchMonth(y, m) {
    var ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var to = setTimeout(function () { if (ctl) ctl.abort(); }, 20000);
    try {
      var r = await fetch('https://api.aladhan.com/v1/gToHCalendar/' + m + '/' + y + '?calendarMethod=DIYANET', ctl ? { signal: ctl.signal } : {});
      if (!r.ok) return false;
      var j = await r.json();
      var n = daysIn(y, m);
      if (!j || j.code !== 200 || !Array.isArray(j.data) || j.data.length !== n) return false;
      var days = {}, ok = true;
      j.data.forEach(function (it, idx) {
        var h = it && it.hijri;
        if (!h || !h.month) { ok = false; return; }
        var hd = parseInt(h.day, 10), hm = parseInt(h.month.number, 10), hy = parseInt(h.year, 10);
        if (!(hd >= 1 && hd <= 30 && hm >= 1 && hm <= 12 && hy > 1400 && hy < 1700)) { ok = false; return; }
        days[idx + 1] = [hd, hm, hy];
      });
      if (!ok) return false;
      for (var d = 1; d <= n; d++) {
        // every day must be within 3 days of Umm al-Qura, otherwise the answer looks wrong
        if (solve(y, m, d, days[d]) === null) return false;
        if (d < n) {
          var a = days[d], b = days[d + 1];
          var cont = (b[0] === a[0] + 1 && b[1] === a[1]) || (b[0] === 1 && b[1] === (a[1] % 12) + 1);
          if (!cont) return false;
        }
      }
      store[mkey(y, m)] = { ts: Date.now(), days: days };
      save();
      memo = {};
      return true;
    } catch (e) { return false; } finally { clearTimeout(to); }
  }
  async function refresh() {
    if (window.__wsbHijriBusy) return;
    window.__wsbHijriBusy = true;
    try {
      var now = new Date();
      for (var i = 0; i < 4; i++) {
        var y = now.getFullYear(), m = now.getMonth() + 1 + i;
        if (m > 12) { m -= 12; y += 1; }
        var cur = store[mkey(y, m)];
        if (cur && Date.now() - cur.ts < (i === 0 ? 1 : 3) * 86400000) continue;
        await fetchMonth(y, m);
      }
      var cut = mkey(now.getFullYear(), now.getMonth() + 1 - 2 > 0 ? now.getMonth() + 1 - 2 : 1);
      Object.keys(store).forEach(function (k) { if (k < cut && now.getMonth() >= 2) delete store[k]; });
      save();
      computeTail();
    } catch (e) {} finally { window.__wsbHijriBusy = false; }
  }
  computeTail();
  window.__wsbAdjFor = adjFor;
  window.__wsbHijriRefresh = refresh;
  window.__wsbHijriStore = function () { return store; };
  setTimeout(refresh, 8000);
  setInterval(refresh, 6 * 3600 * 1000);
  if (window.addEventListener) window.addEventListener('online', function () { setTimeout(refresh, 3000); });
})();

export const officialHijriService = {
  adjustmentFor(date: Date, manualAdjustment: number): number {
    return typeof window !== 'undefined' && (window as any).__wsbAdjFor ? (window as any).__wsbAdjFor(date, manualAdjustment) : manualAdjustment;
  },
};
