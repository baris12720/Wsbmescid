import { PrayerTimes, MosqueSettings } from '../types';
import { storageService } from './storageService';
import { calculateLocalPrayerTimes } from './localPrayerCalc';

// Fallback Hamburg baseline timings in case of zero internet on initial launch
const HAMBURG_OFFLINE_BASELINES: Record<number, PrayerTimes> = {
  // Approximate month-based baseline times for Hamburg (Europe/Berlin)
  0: { Fajr: '06:15', Sunrise: '08:35', Dhuhr: '12:30', Asr: '14:20', Maghrib: '16:30', Isha: '18:35' }, // Jan
  1: { Fajr: '05:40', Sunrise: '07:45', Dhuhr: '12:35', Asr: '15:10', Maghrib: '17:30', Isha: '19:25' }, // Feb
  2: { Fajr: '04:45', Sunrise: '06:40', Dhuhr: '12:30', Asr: '15:55', Maghrib: '18:25', Isha: '20:10' }, // Mar
  3: { Fajr: '04:30', Sunrise: '06:15', Dhuhr: '13:20', Asr: '17:15', Maghrib: '20:25', Isha: '22:05' }, // Apr (DST)
  4: { Fajr: '03:15', Sunrise: '05:15', Dhuhr: '13:18', Asr: '17:35', Maghrib: '21:20', Isha: '23:10' }, // May
  5: { Fajr: '02:45', Sunrise: '04:50', Dhuhr: '13:22', Asr: '17:50', Maghrib: '21:55', Isha: '23:50' }, // Jun
  6: { Fajr: '03:00', Sunrise: '05:10', Dhuhr: '13:25', Asr: '17:45', Maghrib: '21:45', Isha: '23:35' }, // Jul
  7: { Fajr: '03:50', Sunrise: '05:55', Dhuhr: '13:22', Asr: '17:20', Maghrib: '20:50', Isha: '22:40' }, // Aug
  8: { Fajr: '04:55', Sunrise: '06:50', Dhuhr: '13:15', Asr: '16:40', Maghrib: '19:40', Isha: '21:25' }, // Sep
  9: { Fajr: '05:55', Sunrise: '07:45', Dhuhr: '13:08', Asr: '15:50', Maghrib: '18:30', Isha: '20:10' }, // Oct
  10: { Fajr: '05:40', Sunrise: '07:40', Dhuhr: '12:10', Asr: '14:15', Maghrib: '16:40', Isha: '18:30' }, // Nov (Winter time)
  11: { Fajr: '06:10', Sunrise: '08:30', Dhuhr: '12:20', Asr: '13:55', Maghrib: '16:05', Isha: '18:15' }, // Dec
};

export const PRAYER_KEYS: (keyof PrayerTimes)[] = [
  'Fajr',
  'Sunrise',
  'Dhuhr',
  'Asr',
  'Maghrib',
  'Isha',
];

/**
 * Adjusts HH:MM time by offset in minutes
 */
export function applyMinuteOffset(timeStr: string, offsetMinutes: number): string {
  if (!timeStr || !timeStr.includes(':')) return timeStr;
  const parts = timeStr.trim().split(':');
  let h = parseInt(parts[0], 10);
  let m = parseInt(parts[1], 10);

  if (isNaN(h) || isNaN(m)) return timeStr;

  let totalMinutes = h * 60 + m + offsetMinutes;
  // Handle wrapping around 24 hours
  totalMinutes = (totalMinutes % 1440 + 1440) % 1440;

  const newH = Math.floor(totalMinutes / 60);
  const newM = totalMinutes % 60;

  return `${String(newH).padStart(2, '0')}:${String(newM).padStart(2, '0')}`;
}

export const prayerTimeService = {
  async fetchPrayerTimes(settings: MosqueSettings): Promise<{
    timings: PrayerTimes;
    isOnline: boolean;
    date: string;
  }> {
    const today = new Date();
    const y = today.getFullYear();
    const m = String(today.getMonth() + 1).padStart(2, '0');
    const d = String(today.getDate()).padStart(2, '0');
    const dateStr = `${y}-${m}-${d}`;
    const school = settings.asrMethod === 'Hanafi' ? 1 : 0;
    const method = settings.calculationMethod || 13; // 13: Diyanet

    // Query exact date (DD-MM-YYYY) for Hamburg
    const url = `https://api.aladhan.com/v1/timingsByCity/${d}-${m}-${y}?city=${encodeURIComponent(
      settings.city
    )}&country=${encodeURIComponent(settings.country)}&method=${method}&school=${school}`;

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);

      const res = await fetch(url, {
        cache: 'no-store',
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (!res.ok) throw new Error(`AlAdhan HTTP status ${res.status}`);

      const data = await res.json();
      if (data && data.code === 200 && data.data && data.data.timings) {
        const raw = data.data.timings;
        const adjustedTimings: PrayerTimes = {
          Fajr: applyMinuteOffset(raw.Fajr?.slice(0, 5) || '05:30', settings.minuteOffsets.Fajr),
          Sunrise: applyMinuteOffset(raw.Sunrise?.slice(0, 5) || '07:15', settings.minuteOffsets.Sunrise),
          Dhuhr: applyMinuteOffset(raw.Dhuhr?.slice(0, 5) || '12:30', settings.minuteOffsets.Dhuhr),
          Asr: applyMinuteOffset(raw.Asr?.slice(0, 5) || '15:45', settings.minuteOffsets.Asr),
          Maghrib: applyMinuteOffset(raw.Maghrib?.slice(0, 5) || '18:15', settings.minuteOffsets.Maghrib),
          Isha: applyMinuteOffset(raw.Isha?.slice(0, 5) || '19:45', settings.minuteOffsets.Isha),
        };

        // Cache today's timings
        storageService.saveCachedTimings(dateStr, adjustedTimings as any, method);

        // Pre-fetch whole month in background for offline resilience
        this.prefetchMonthlyCalendar(settings, y, parseInt(m, 10));

        return {
          timings: adjustedTimings,
          isOnline: true,
          date: dateStr,
        };
      }
      throw new Error('AlAdhan invalid payload');
    } catch (err) {
      console.warn('Network prayer fetch failed, using offline cache/fallbacks', err);

      // 1. Tier 1: Check monthly calendar cache for today's date
      const monthDayRaw = storageService.getMonthlyDayTimings(y, parseInt(m, 10), parseInt(d, 10));
      if (monthDayRaw) {
        const adjustedFromMonth: PrayerTimes = {
          Fajr: applyMinuteOffset((monthDayRaw.Fajr || '05:30').slice(0, 5), settings.minuteOffsets.Fajr),
          Sunrise: applyMinuteOffset((monthDayRaw.Sunrise || '07:15').slice(0, 5), settings.minuteOffsets.Sunrise),
          Dhuhr: applyMinuteOffset((monthDayRaw.Dhuhr || '12:30').slice(0, 5), settings.minuteOffsets.Dhuhr),
          Asr: applyMinuteOffset((monthDayRaw.Asr || '15:45').slice(0, 5), settings.minuteOffsets.Asr),
          Maghrib: applyMinuteOffset((monthDayRaw.Maghrib || '18:15').slice(0, 5), settings.minuteOffsets.Maghrib),
          Isha: applyMinuteOffset((monthDayRaw.Isha || '19:45').slice(0, 5), settings.minuteOffsets.Isha),
        };
        return {
          timings: adjustedFromMonth,
          isOnline: false,
          date: dateStr,
        };
      }

      // 2. Tier 2: Check last cached single-day timings in localStorage
      const cached = storageService.getCachedTimings();
      if (cached && cached.timings && cached.date === dateStr) {
        const adjustedCached: PrayerTimes = {
          Fajr: applyMinuteOffset((cached.timings.Fajr || '05:30').slice(0, 5), settings.minuteOffsets.Fajr),
          Sunrise: applyMinuteOffset((cached.timings.Sunrise || '07:15').slice(0, 5), settings.minuteOffsets.Sunrise),
          Dhuhr: applyMinuteOffset((cached.timings.Dhuhr || '12:30').slice(0, 5), settings.minuteOffsets.Dhuhr),
          Asr: applyMinuteOffset((cached.timings.Asr || '15:45').slice(0, 5), settings.minuteOffsets.Asr),
          Maghrib: applyMinuteOffset((cached.timings.Maghrib || '18:15').slice(0, 5), settings.minuteOffsets.Maghrib),
          Isha: applyMinuteOffset((cached.timings.Isha || '19:45').slice(0, 5), settings.minuteOffsets.Isha),
        };
        return {
          timings: adjustedCached,
          isOnline: false,
          date: cached.date || dateStr,
        };
      }

      // 3. Tier 3: Final fallback: Hamburg baseline for current month
      const month = today.getMonth();
      // Offline astronomical calculation (Diyanet angles) – falls back to the rough monthly table only if it fails
      let base: PrayerTimes = HAMBURG_OFFLINE_BASELINES[month] || HAMBURG_OFFLINE_BASELINES[9];
      try {
        base = calculateLocalPrayerTimes(today, settings);
      } catch {
        /* keep monthly baseline */
      }
      const finalTimings: PrayerTimes = {
        Fajr: applyMinuteOffset(base.Fajr, settings.minuteOffsets.Fajr),
        Sunrise: applyMinuteOffset(base.Sunrise, settings.minuteOffsets.Sunrise),
        Dhuhr: applyMinuteOffset(base.Dhuhr, settings.minuteOffsets.Dhuhr),
        Asr: applyMinuteOffset(base.Asr, settings.minuteOffsets.Asr),
        Maghrib: applyMinuteOffset(base.Maghrib, settings.minuteOffsets.Maghrib),
        Isha: applyMinuteOffset(base.Isha, settings.minuteOffsets.Isha),
      };

      return {
        timings: finalTimings,
        isOnline: false,
        date: dateStr,
      };
    }
  },

  /**
   * Downloads the monthly calendar (current month + the next two) from AlAdhan and keeps it in the
   * device storage so the correct times are available for ~2-3 months even without internet.
   * Throttled: current month is refreshed at most every 2 days, future months every 7 days.
   */
  async prefetchMonthlyCalendar(settings: MosqueSettings, year: number, month: number): Promise<void> {
    if ((window as any).__wsbPrefetching) return;
    (window as any).__wsbPrefetching = true;
    try {
      const school = settings.asrMethod === 'Hanafi' ? 1 : 0;
      const method = settings.calculationMethod || 13;
      const sig = `${settings.city}|${settings.country}|${method}|${school}`;
      try {
        if (localStorage.getItem('wsb_calendar_sig') !== sig) {
          Object.keys(localStorage)
            .filter((k) => k.startsWith('wsb_calendar_'))
            .forEach((k) => localStorage.removeItem(k));
          localStorage.setItem('wsb_calendar_sig', sig);
        }
      } catch {
        /* storage unavailable */
      }
      for (let step = 0; step < 3; step++) {
        let m = month + step;
        let y = year;
        if (m > 12) {
          m -= 12;
          y += 1;
        }
        const tsKey = `wsb_calendar_ts_${y}_${m}`;
        let savedAt = 0;
        try {
          savedAt = parseInt(localStorage.getItem(tsKey) || '0', 10) || 0;
        } catch {
          /* ignore */
        }
        const maxAgeDays = step === 0 ? 2 : 7;
        if (storageService.getMonthlyDayTimings(y, m, 15) && Date.now() - savedAt < maxAgeDays * 86400000) continue;

        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 20000);
        try {
          const calUrl = `https://api.aladhan.com/v1/calendarByCity/${y}/${m}?city=${encodeURIComponent(
            settings.city
          )}&country=${encodeURIComponent(settings.country)}&method=${method}&school=${school}`;
          const res = await fetch(calUrl, { signal: controller.signal });
          if (!res.ok) continue;
          const data = await res.json();
          if (data && data.code === 200 && Array.isArray(data.data) && data.data.length >= 28) {
            const daysMap: Record<number, Record<string, string>> = {};
            data.data.forEach((item: any, idx: number) => {
              if (item && item.timings) daysMap[idx + 1] = item.timings;
            });
            storageService.saveMonthlyCalendar(y, m, daysMap);
            try {
              localStorage.setItem(tsKey, String(Date.now()));
            } catch {
              /* ignore */
            }
          }
        } catch {
          /* network error: try again on the next cycle */
        } finally {
          clearTimeout(timer);
        }
      }
    } catch {
      /* never affect the live display */
    } finally {
      (window as any).__wsbPrefetching = false;
    }
  },

  calculateNextPrayer(
    timings: PrayerTimes,
    now: Date = new Date()
  ): {
    key: keyof PrayerTimes;
    time: string;
    remainingMinutes: number;
    remainingSeconds: number;
    totalSpanMinutes: number;
    progressPercentage: number;
  } {
    const currentSeconds = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();

    // Map prayer keys into seconds of the day
    const prayersInOrder: (keyof PrayerTimes)[] = ['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

    const parsedPrayers = prayersInOrder.map((key) => {
      const timeStr = timings[key];
      const [h, m] = timeStr.split(':').map((v) => parseInt(v, 10));
      const seconds = h * 3600 + m * 60;
      return { key, timeStr, seconds };
    });

    // Find the next prayer
    let nextIndex = parsedPrayers.findIndex((p) => p.seconds > currentSeconds);
    let prevIndex: number;
    let secondsDiff: number;

    if (nextIndex === -1) {
      // All prayers passed for today -> Next is tomorrow's Fajr
      nextIndex = 0;
      prevIndex = parsedPrayers.length - 1; // Isha
      const tomorrowFajrSeconds = parsedPrayers[0].seconds + 86400;
      secondsDiff = tomorrowFajrSeconds - currentSeconds;
    } else {
      prevIndex = nextIndex === 0 ? parsedPrayers.length - 1 : nextIndex - 1;
      secondsDiff = parsedPrayers[nextIndex].seconds - currentSeconds;
    }

    const nextPrayer = parsedPrayers[nextIndex];
    const prevPrayer = parsedPrayers[prevIndex];

    // Calculate progress between prev and next prayer
    let totalSpanSeconds = nextPrayer.seconds - prevPrayer.seconds;
    if (totalSpanSeconds <= 0) totalSpanSeconds += 86400;

    let elapsedSeconds = currentSeconds - prevPrayer.seconds;
    if (elapsedSeconds < 0) elapsedSeconds += 86400;

    const progressPercentage = Math.min(
      100,
      Math.max(0, Math.round((elapsedSeconds / totalSpanSeconds) * 100))
    );

    return {
      key: nextPrayer.key,
      time: nextPrayer.timeStr,
      remainingMinutes: Math.floor(secondsDiff / 60),
      remainingSeconds: secondsDiff % 60,
      totalSpanMinutes: Math.floor(totalSpanSeconds / 60),
      progressPercentage,
    };
  },

  calculateActivePrayer(timings: PrayerTimes, now: Date = new Date()): keyof PrayerTimes | null {
    const nowMinutes = now.getHours() * 60 + now.getMinutes();

    // Active prayer window: within 25 minutes after prayer entrance (except sunrise which is just sunrise)
    const prayersToCheck: (keyof PrayerTimes)[] = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

    for (const key of prayersToCheck) {
      const [h, m] = timings[key].split(':').map((v) => parseInt(v, 10));
      const prayerMinutes = h * 60 + m;
      if (nowMinutes >= prayerMinutes && nowMinutes < prayerMinutes + 25) {
        return key;
      }
    }
    return null;
  },
};
