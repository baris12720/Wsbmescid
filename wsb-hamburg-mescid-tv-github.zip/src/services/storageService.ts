import { MosqueSettings, DailyPair, Announcement } from '../types';
import { DEFAULT_SETTINGS, INITIAL_ANNOUNCEMENTS } from '../constants/initialData';
import { dailyContentService } from './dailyContentService';

const SETTINGS_KEY = 'wsb_mosque_settings_v2';
const PAIRS_KEY = 'wsb_daily_pairs_v3';
const ANNOUNCEMENTS_KEY = 'wsb_announcements_v3';
const TIMINGS_CACHE_KEY = 'wsb_cached_timings_v2';

export const storageService = {
  getSettings(): MosqueSettings {
    try {
      const data = localStorage.getItem(SETTINGS_KEY);
      if (!data) return DEFAULT_SETTINGS;
      const parsed = JSON.parse(data);
      if (!parsed.theme || parsed.theme === 'emerald') {
        parsed.theme = 'ivory';
      }
      if (!parsed.iqamaOffsets) {
        parsed.iqamaOffsets = DEFAULT_SETTINGS.iqamaOffsets;
      }
      return { ...DEFAULT_SETTINGS, ...parsed };
    } catch (e) {
      console.error('Failed to load settings from storage', e);
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings(settings: MosqueSettings): void {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save settings', e);
    }
  },

  getDailyPairs(): DailyPair[] {
    try {
      const data = localStorage.getItem(PAIRS_KEY);
      const default200Pairs = dailyContentService.getAllPairs();
      if (!data) return default200Pairs;
      const parsed = JSON.parse(data);
      return Array.isArray(parsed) && parsed.length >= 200 ? parsed : default200Pairs;
    } catch (e) {
      console.error('Failed to load daily pairs', e);
      return dailyContentService.getAllPairs();
    }
  },

  saveDailyPairs(pairs: DailyPair[]): void {
    try {
      localStorage.setItem(PAIRS_KEY, JSON.stringify(pairs));
    } catch (e) {
      console.error('Failed to save daily pairs', e);
    }
  },

  getAnnouncements(): Announcement[] {
    try {
      const data = localStorage.getItem(ANNOUNCEMENTS_KEY);
      if (!data) return INITIAL_ANNOUNCEMENTS;
      const parsed = JSON.parse(data);
      return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_ANNOUNCEMENTS;
    } catch (e) {
      console.error('Failed to load announcements', e);
      return INITIAL_ANNOUNCEMENTS;
    }
  },

  saveAnnouncements(announcements: Announcement[]): void {
    try {
      localStorage.setItem(ANNOUNCEMENTS_KEY, JSON.stringify(announcements));
    } catch (e) {
      console.error('Failed to save announcements', e);
    }
  },

  getCachedTimings(): { date: string; timings: Record<string, string>; method: number } | null {
    try {
      const data = localStorage.getItem(TIMINGS_CACHE_KEY);
      if (!data) return null;
      return JSON.parse(data);
    } catch (e) {
      return null;
    }
  },

  saveCachedTimings(date: string, timings: Record<string, string>, method: number): void {
    try {
      localStorage.setItem(
        TIMINGS_CACHE_KEY,
        JSON.stringify({ date, timings, method, timestamp: new Date().toISOString() })
      );
    } catch (e) {
      console.error('Failed to cache timings', e);
    }
  },

  saveMonthlyCalendar(year: number, month: number, daysMap: Record<number, Record<string, string>>): void {
    try {
      localStorage.setItem(`wsb_calendar_${year}_${month}`, JSON.stringify(daysMap));
    } catch (e) {
      console.error('Failed to cache monthly calendar', e);
    }
  },

  getMonthlyDayTimings(year: number, month: number, day: number): Record<string, string> | null {
    try {
      const data = localStorage.getItem(`wsb_calendar_${year}_${month}`);
      if (!data) return null;
      const parsed = JSON.parse(data);
      return parsed[day] || null;
    } catch (e) {
      return null;
    }
  },

  exportFullBackup(): string {
    const backup = {
      version: '2.0',
      exportedAt: new Date().toISOString(),
      settings: this.getSettings(),
      dailyPairs: this.getDailyPairs(),
      announcements: this.getAnnouncements(),
    };
    return JSON.stringify(backup, null, 2);
  },

  importFullBackup(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed.settings) this.saveSettings(parsed.settings);
      if (parsed.dailyPairs) this.saveDailyPairs(parsed.dailyPairs);
      if (parsed.announcements) this.saveAnnouncements(parsed.announcements);
      return true;
    } catch (e) {
      console.error('Invalid backup JSON', e);
      return false;
    }
  },

  resetToDefaults(): void {
    try {
      localStorage.removeItem(SETTINGS_KEY);
      localStorage.removeItem(PAIRS_KEY);
      localStorage.removeItem(ANNOUNCEMENTS_KEY);
    } catch (e) {
      console.error('Error clearing localStorage', e);
    }
  },
};
