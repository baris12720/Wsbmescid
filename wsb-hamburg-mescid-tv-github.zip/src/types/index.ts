export type Language = 'tr' | 'ar' | 'de' | 'en';

export interface PrayerTimes {
  Fajr: string;
  Sunrise: string;
  Dhuhr: string;
  Asr: string;
  Maghrib: string;
  Isha: string;
}

export interface PrayerMinuteOffsets {
  Fajr: number;
  Sunrise: number;
  Dhuhr: number;
  Asr: number;
  Maghrib: number;
  Isha: number;
}

export interface AyahItem {
  id: string;
  arabic: string;
  translations: Record<Language, string>;
  surahName: Record<Language, string>;
  surahNumber?: number;
  ayahNumber: number;
  reference: string;
}

export interface HadithItem {
  id: string;
  arabic: string;
  translations: Record<Language, string>;
  source: string;
  hadithNumber?: string;
  narrator?: Record<Language, string>;
  bookName?: string;
  notes?: string | Record<Language, string>;
}

export interface DailyPair {
  id: string;
  ayah: AyahItem;
  hadith: HadithItem;
}

export interface Announcement {
  id: string;
  title: Record<Language, string>;
  content: Record<Language, string>;
  startDate: string; // YYYY-MM-DD
  endDate: string;   // YYYY-MM-DD
  priority: 'normal' | 'urgent';
  displayType: 'ticker' | 'fullscreen' | 'both';
  active: boolean;
  durationSeconds: number;
}

export interface FridaySettings {
  enabled: boolean;
  firstKhutbahTime: string;
  firstPrayerTime: string;
  secondKhutbahTime?: string;
  secondPrayerTime?: string;
  notes: Record<Language, string>;
}

export interface RamadanSettings {
  enabled: boolean;
  autoDetect: boolean;
  showIftarCountdown: boolean;
  showSahurAlert: boolean;
  customMessage: Record<Language, string>;
}

export interface IslamicDay {
  id: string;
  title: Record<Language, string>;
  hijriDay: number;
  hijriMonth: number;
  hijriMonthName: Record<Language, string>;
  description: Record<Language, string>;
}

export interface IqamaOffsets {
  Fajr: number;
  Dhuhr: number;
  Asr: number;
  Maghrib: number;
  Isha: number;
}

export interface MosqueSettings {
  mosqueName: string;
  mosqueSubName: string;
  city: string;
  country: string;
  latitude: number;
  longitude: number;
  timezone: string;
  calculationMethod: number; // 13 = Diyanet İşleri Başkanlığı, 3 = Muslim World League, etc.
  asrMethod: 'Standard' | 'Hanafi';
  minuteOffsets: PrayerMinuteOffsets;
  iqamaOffsets?: IqamaOffsets;
  
  // Language settings
  defaultLanguage: Language;
  autoRotateLanguages: boolean;
  rotationIntervalSeconds: number;

  // Prayer Sequence Animation
  enablePrayerSequence: boolean;
  ayahDisplaySeconds: number;
  hadithDisplaySeconds: number;

  // Pin & Security
  adminPin: string;

  // Theme & Layout
  theme: 'ivory' | 'emerald' | 'midnight' | 'sapphire' | 'high-contrast';
  brightness: 'normal' | 'soft' | 'dim';

  // Friday & Ramadan
  friday: FridaySettings;
  ramadan: RamadanSettings;
  
  // Hijri adjustment (+- days)
  hijriDateAdjustment: number;
}

export interface AppState {
  currentLanguage: Language;
  timings: PrayerTimes | null;
  activePrayer: keyof PrayerTimes | null;
  nextPrayer: {
    key: keyof PrayerTimes;
    name: string;
    time: string;
    remainingMinutes: number;
    remainingSeconds: number;
  } | null;
  currentTime: Date;
  hijriDateFormatted: string;
  isOnline: boolean;
  lastUpdated: string | null;
  settings: MosqueSettings;
}
